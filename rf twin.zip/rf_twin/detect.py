"""
rf_twin/detect.py — DETECT MODE
================================
"Here is an SDR recording and my measured noise floor — find the actual
interference events."

Usage:
  # Real recording:
  python detect.py --iq recording.dat --fs 2e6 --fc 1701.3e6 --noise-dbm -100

  # LARGE files — always limit to a chunk first:
  python detect.py --iq big.dat --fs 2e6 --max-seconds 30
  python detect.py --iq big.dat --fs 2e6 --skip-seconds 60 --max-seconds 30

  # Synthesized test (no hardware):
  python detect.py --simulate

  # Single detector:
  python detect.py --iq rec.dat --fs 2e6 --detector spectral_anomaly

  # All four detectors side by side:
  python detect.py --simulate --compare
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from twin.io.common import load_config, COLORS
from twin.sdr import realism as sdr
from twin.detectors import algorithms as algo
from twin.plots import figures as figs


def make_test_signal(cfg):
    sim = cfg["simulation"]
    fs = sim["sample_rate_hz"]
    dur = sim["duration_s"]
    sdr_cfg = sim["sdr"]
    imp = sdr.SDRImpairments(
        adc_bits=sdr_cfg["adc_bits"], p1db_backoff_db=sdr_cfg["p1db_backoff_db"],
        lo_freq_offset_hz=sdr_cfg["lo_freq_offset_hz"],
        lo_phase_noise_dbc=sdr_cfg["lo_phase_noise_dbc"],
        dc_offset=sdr_cfg["dc_offset"], enable_clipping=sdr_cfg["enable_clipping"],
        enable_compression=sdr_cfg["enable_compression"],
        enable_lo_effects=sdr_cfg["enable_lo_effects"],
        enable_dc_offset=sdr_cfg["enable_dc_offset"],
        enable_spurs=sdr_cfg["enable_spurs"], enable_images=sdr_cfg["enable_images"],
        spurs_hz=(fs/16,))
    signals = [
        sdr.SignalSpec(kind="qpsk", snr_db=10, freq_offset_hz=-fs*0.15,
                       symbol_rate_hz=fs/20, t_start_s=dur*0.15, t_end_s=dur*0.55),
        sdr.SignalSpec(kind="cw", snr_db=14, freq_offset_hz=fs*0.22,
                       t_start_s=dur*0.4, t_end_s=dur*0.8),
        sdr.SignalSpec(kind="pulsed", snr_db=16, freq_offset_hz=fs*0.05,
                       pulse_period_s=0.02, pulse_width_s=0.002),
    ]
    iq = sdr.synthesize(dur, fs, signals, imp, seed=sim["seed"])
    return iq, fs


def load_iq_chunk(path: str, fs: float,
                  skip_s: float = 0.0,
                  max_s: float | None = None,
                  dtype: str = "int16") -> np.ndarray:
    """Load only the samples we need, not the whole file.

    skip_s  : skip this many seconds from the start
    max_s   : read at most this many seconds
    dtype   : 'int16' (default), 'float32', or 'uint8' (RTL-SDR)

    If the dtype is wrong for your file, the waveform will look like
    pure noise and the power level will be nonsensical. If that happens,
    try --dtype float32.
    """
    bytes_per_sample = {"int16": 2, "float32": 4, "uint8": 1}[dtype]
    # Each complex sample = 2 values (I + Q)
    values_per_sample = 2
    skip_values = int(skip_s * fs) * values_per_sample
    max_values  = (int(max_s  * fs) * values_per_sample) if max_s else -1

    raw = np.fromfile(path, dtype=np.dtype(dtype),
                      count=max_values if max_values > 0 else -1,
                      offset=skip_values * bytes_per_sample)

    if dtype == "int16":
        iq = (raw[0::2].astype(np.float32) +
              1j * raw[1::2].astype(np.float32))
    elif dtype == "float32":
        iq = raw[0::2] + 1j * raw[1::2]
    elif dtype == "uint8":
        # RTL-SDR: center at 127.5
        f = raw.astype(np.float32) - 127.5
        iq = f[0::2] + 1j * f[1::2]
    return iq.astype(np.complex64)


def estimate_file_info(path: str, dtype: str = "int16") -> dict:
    """Print what we know about the file before committing to load it."""
    bytes_per_value = {"int16": 2, "float32": 4, "uint8": 1}[dtype]
    size = Path(path).stat().st_size
    n_values = size // bytes_per_value
    n_samples = n_values // 2   # I+Q pairs
    return {"size_mb": size / 1e6, "n_samples": n_samples,
            "bytes_per_value": bytes_per_value}


def main():
    ap = argparse.ArgumentParser(description="DETECT mode — find interference in IQ.")
    ap.add_argument("--config",      default=str(Path(__file__).parent/"configs"/"config.yaml"))
    ap.add_argument("--iq",          default=None,  help="path to IQ recording file")
    ap.add_argument("--fs",          type=float,    default=None, help="sample rate (Hz)")
    ap.add_argument("--fc",          type=float,    default=0.0,  help="center frequency (Hz)")
    ap.add_argument("--dtype",       default="int16",
                    choices=["int16", "float32", "uint8"],
                    help="file sample format (int16=default, float32=GNU Radio/SoapySDR, uint8=RTL-SDR)")
    ap.add_argument("--max-seconds", type=float,    default=None, metavar="SEC",
                    help="RECOMMENDED for large files: only process the first N seconds. "
                         "Start with 30. A 2-minute file at 2MHz is several GB in RAM.")
    ap.add_argument("--skip-seconds",type=float,    default=0.0,  metavar="SEC",
                    help="skip the first N seconds (e.g. skip a quiet baseline segment)")
    ap.add_argument("--noise-dbm",   type=float,    default=None,
                    help="measured noise floor (dBm) — optional but improves thresholds")
    ap.add_argument("--detector",    default=None,
                    help="cfar_energy | spectral_anomaly | spectral_kurtosis | cyclostationary")
    ap.add_argument("--pfa",         type=float,    default=None)
    ap.add_argument("--simulate",    action="store_true",
                    help="use a synthesized test recording (no file needed)")
    ap.add_argument("--compare",     action="store_true",
                    help="run all detectors and compare")
    ap.add_argument("--baseline-iq", default=None,
                    help="quiet-sky recording to learn the baseline PSD from")
    ap.add_argument("--info",        action="store_true",
                    help="just print file size / estimated duration and exit (safe, loads nothing)")
    ap.add_argument("--out",         default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.pfa is not None: cfg["detection"]["default_pfa"] = args.pfa
    if args.out is not None: cfg["output"]["dir"] = args.out
    out_dir = Path(cfg["output"]["dir"]); out_dir.mkdir(parents=True, exist_ok=True)

    # --info mode: just inspect the file, load nothing
    if args.info and args.iq:
        info = estimate_file_info(args.iq, args.dtype)
        fs = args.fs or cfg["simulation"]["sample_rate_hz"]
        dur = info["n_samples"] / fs
        print(f"\nFile:     {args.iq}")
        print(f"Size:     {info['size_mb']:.1f} MB")
        print(f"Samples:  {info['n_samples']:,}  (as {args.dtype})")
        print(f"Duration: {dur:.1f}s  @ {fs/1e6:.3f} MHz sample rate")
        print(f"RAM to load whole file: ~{info['n_samples']*8/1e9:.2f} GB (as complex64)")
        print(f"\nRecommended: --max-seconds 30  (uses ~{30*fs*8/1e9*1000:.0f} MB)")
        return

    print("=" * 70)
    print("RF INTERFERENCE DIGITAL TWIN  —  DETECT MODE")
    print("=" * 70)

    # ── Load IQ ─────────────────────────────────────────────────────────────
    if args.simulate or not args.iq:
        print("Source:   synthesized test recording")
        iq, fs = make_test_signal(cfg)
        fc = 0.0
    else:
        fs = args.fs or cfg["simulation"]["sample_rate_hz"]
        fc = args.fc

        # Warn if loading a large chunk
        info = estimate_file_info(args.iq, args.dtype)
        dur_full = info["n_samples"] / fs
        dur_load = min(args.max_seconds, dur_full) if args.max_seconds else dur_full
        ram_gb = dur_load * fs * 8 / 1e9
        if ram_gb > 1.0 and not args.max_seconds:
            print(f"\n  WARNING: loading {dur_full:.0f}s @ {fs/1e6:.1f}MHz"
                  f" will use ~{ram_gb:.1f} GB RAM.")
            print(  "  Add --max-seconds 30 to load only a safe chunk.")
            print(  "  Continuing anyway...\n")
        elif args.max_seconds:
            print(f"Source:   {args.iq}  [{info['size_mb']:.0f} MB total, "
                  f"loading {dur_load:.0f}s chunk{f' from {args.skip_seconds:.0f}s' if args.skip_seconds else ''}]")
        else:
            print(f"Source:   {args.iq}  [{info['size_mb']:.0f} MB]")

        iq = load_iq_chunk(args.iq, fs,
                           skip_s=args.skip_seconds,
                           max_s=args.max_seconds,
                           dtype=args.dtype)

    print(f"Loaded:   {len(iq):,} samples  @ {fs/1e6:.3f} MHz  "
          f"fc={fc/1e6:.4f} MHz  ({len(iq)/fs:.2f}s)")
    ram_actual = iq.nbytes / 1e9
    print(f"RAM used: {ram_actual*1000:.0f} MB for this chunk")

    # ── Noise baseline ───────────────────────────────────────────────────────
    noise_power = float(np.median(np.abs(iq)**2))
    if args.noise_dbm is not None:
        print(f"Baseline: measured {args.noise_dbm:.1f} dBm  "
              f"(estimated power {10*np.log10(noise_power):.1f} dB from recording)")
    else:
        print(f"Baseline: estimated from recording  "
              f"(median power {10*np.log10(noise_power):.1f} dB)")

    # ── Optional baseline PSD from a quiet-sky recording ─────────────────────
    baseline_psd = None
    if args.baseline_iq:
        print(f"Learning baseline PSD from {args.baseline_iq} ...")
        biq = load_iq_chunk(args.baseline_iq, fs,
                            max_s=min(30.0, args.max_seconds or 30.0),
                            dtype=args.dtype)
        nfft = 1024
        nchunks = len(biq) // nfft
        win = np.hanning(nfft)
        psd = np.zeros(nfft)
        for k in range(nchunks):
            psd += np.abs(np.fft.fftshift(np.fft.fft(biq[k*nfft:(k+1)*nfft]*win)))**2
        baseline_psd = psd / max(1, nchunks)

    print("=" * 70)

    pfa = cfg["detection"]["default_pfa"]
    det_name = args.detector or cfg["detection"]["detector"]

    # ── Run detectors ────────────────────────────────────────────────────────
    if args.compare:
        print("\nRunning ALL detectors for comparison...\n")
        results = algo.compare_detectors(iq, fs, center_freq_hz=fc,
                                         noise_power=noise_power,
                                         baseline_psd=baseline_psd)
        all_dets = []
        for name, r in results.items():
            print(f"  {name:22s}: {len(r.detections)} detection(s)")
            for d in r.detections[:5]:
                f = f"{d.freq_hz/1e6:.4f}MHz" if d.freq_hz else "wideband"
                print(f"       t={d.t_start_s:.2f}-{d.t_end_s:.2f}s  {f}  "
                      f"SNR={d.snr_db:.1f}dB  conf={d.confidence:.2f}")
            all_dets.extend([_det_dict(d) for d in r.detections])
        if cfg["output"]["save_plots"]:
            figs.plot_detector_comparison(results, out_dir/"detector_comparison.png",
                                          title="Detector comparison")
            union = [d for r in results.values() for d in r.detections]
            figs.plot_spectrogram_with_detections(iq, fs, fc, union,
                out_dir/"detect_spectrogram.png",
                title=f"All detectors ({len(union)} detections)")
            figs.plot_psd(iq, fs, fc, out_dir/"detect_psd.png",
                          baseline_psd=baseline_psd, title="PSD with baseline")
        summary_dets = all_dets
    else:
        print(f"\nDetector: {det_name}  (PFA={pfa:.0e})\n")
        if det_name == "cfar_energy":
            r = algo.cfar_energy(iq, fs, pfa=pfa, center_freq_hz=fc, noise_power=noise_power)
        elif det_name == "spectral_anomaly":
            r = algo.spectral_anomaly(iq, fs, center_freq_hz=fc, baseline_psd=baseline_psd)
        elif det_name == "spectral_kurtosis":
            r = algo.spectral_kurtosis(iq, fs, center_freq_hz=fc)
        elif det_name == "cyclostationary":
            r = algo.cyclostationary(iq, fs, center_freq_hz=fc)
        else:
            print(f"[!] unknown detector '{det_name}'"); sys.exit(1)

        print(f"  {len(r.detections)} interference event(s) detected:")
        for d in r.detections:
            f = f"{d.freq_hz/1e6:.4f}MHz" if d.freq_hz else "wideband"
            cc = COLORS["HIGH"] if d.snr_db > 10 else COLORS["MEDIUM"]
            print(f"  {cc}[DETECT]{COLORS['RESET']}  t={d.t_start_s:.2f}-{d.t_end_s:.2f}s  "
                  f"{f}  SNR={d.snr_db:.1f}dB  conf={d.confidence:.2f}")
        if cfg["output"]["save_plots"]:
            figs.plot_spectrogram_with_detections(iq, fs, fc, r.detections,
                out_dir/"detect_spectrogram.png",
                title=f"{det_name} ({len(r.detections)} detections)")
            figs.plot_psd(iq, fs, fc, out_dir/"detect_psd.png",
                          baseline_psd=baseline_psd, title="PSD with baseline")
        summary_dets = [_det_dict(d) for d in r.detections]

    if cfg["output"]["save_json"]:
        (out_dir/"detect_summary.json").write_text(json.dumps({
            "mode": "detect", "fs_hz": fs, "fc_hz": fc, "n_samples": len(iq),
            "duration_s": len(iq)/fs,
            "skip_seconds": args.skip_seconds if args.iq else 0,
            "max_seconds": args.max_seconds,
            "dtype": args.dtype if args.iq else "simulated",
            "pfa": pfa, "detections": summary_dets}, indent=2, default=str))
        print(f"\n[saved] {out_dir/'detect_summary.json'}")

    print(f"\n[done] \u2192 {out_dir.resolve()}")


def _det_dict(d):
    return {"detector": d.detector, "t_start_s": d.t_start_s, "t_end_s": d.t_end_s,
            "freq_hz": d.freq_hz, "bandwidth_hz": d.bandwidth_hz,
            "snr_db": d.snr_db, "power_db": d.power_db, "confidence": d.confidence}


if __name__ == "__main__":
    main()
