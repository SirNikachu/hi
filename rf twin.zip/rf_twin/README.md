# RF Interference Digital Twin

A fully modular digital twin for **predicting** and **detecting** satellite RF
interference at a ground station. Built for the MITRE Bedford use case: an
antenna records RF continuously, satellite passes can corrupt that data, and
nobody finds out until months later. This tool predicts when interference will
happen (so operators get warned in advance) and detects it in real recordings
against a measured noise baseline.

## Two modes

### PREDICT — "When will satellites interfere, how badly, and what detection performance can I expect?"
```bash
python predict.py                       # next 24h, all satellites
python predict.py --sat METOP-C         # one satellite
python predict.py --next 48             # 48-hour window
python predict.py --pfa 0.001           # tighter false-alarm budget
python predict.py --baseline -110       # override measured noise floor (dBm)
python predict.py --no-plots            # fast summary only
python predict.py --refresh-tle         # force fresh TLE from Celestrak
```

### DETECT — "Here is an SDR recording and my measured noise floor — find the actual interference."
```bash
# Real recording (int16 interleaved IQ):
python detect.py --iq rec.iq --fs 2e6 --fc 1701.3e6 --noise-dbm -100

# Synthesized test signal (no hardware needed):
python detect.py --simulate

# Pick a detector:
python detect.py --iq rec.iq --fs 2e6 --detector spectral_kurtosis

# Compare ALL detectors side by side:
python detect.py --simulate --compare

# Learn the baseline from a quiet-sky recording:
python detect.py --iq rec.iq --fs 2e6 --baseline-iq quiet.iq
```

## Setup

```bash
pip install numpy scipy matplotlib sgp4 pyyaml
python examples/run_tests.py     # verify everything works (12/12 should pass)
```

## The 7 modules (from the project design)

| # | Module | File | What it does |
|---|--------|------|--------------|
| 1 | Orbit / pass prediction | `twin/core/propagator.py` | TLE fetch, SGP4, **TEME→ECEF** transform, pass finding |
| 2 | Geometry & kinematics | `twin/core/propagator.py` | az/el/range, range-rate, Doppler time series |
| 3 | RF prop & link budget | `twin/core/link_budget.py` | FSPL, atmospheric loss, RX power, C/N0, SNR, G/T |
| 4 | Interference & noise modeling | `twin/core/link_budget.py` + `twin/detectors/predictive.py` | deviation above baseline, rule-based / link-budget / HMM |
| 5 | Detection & decision theory | `twin/detectors/theory.py` + `algorithms.py` | Pd/PFA, ROC family, 4 signal detectors, Monte Carlo |
| 6 | Outage & throughput | `twin/core/link_budget.py` | usable seconds, delivered MB, outage intervals |
| 7 | Reporting & visualization | `twin/plots/figures.py` | dashboards, ROC family, spectrograms with detections |

## The detectors (researched and implemented)

**Signal-processing detectors** (run on real IQ recordings):

| Detector | Best for | Notes |
|----------|----------|-------|
| **CFAR energy** | General-purpose "anything above the floor" | Optimal for unknown signals; adapts to drifting noise. **The recommended default.** |
| **Spectral anomaly** | When you have a measured baseline PSD | The field workflow: measure quiet sky, watch for change. Localizes in frequency. |
| **Spectral kurtosis** | Separating man-made (structured) from natural noise | Keys on statistics not level; great for bursty/pulsed RFI and narrowband carriers. |
| **Cyclostationary** | Known modulation types below the noise floor | Most powerful but needs a cyclic-frequency guess and is compute-heavy. |

**Prediction-side detectors** (run on the link budget, no IQ needed):

| Detector | What it does |
|----------|--------------|
| **Rule-based overlap** | Flags when satellite is above the horizon AND its band overlaps the antenna's band |
| **Link-budget-based** | Flags when predicted RX power exceeds baseline + margin (the core method) |
| **Hidden Markov Model** | Smooths noisy per-sample decisions into coherent interference intervals via Viterbi |

### Which detector is best?
For the interference problem (unknown signal, "anything above the noise floor"),
**CFAR energy is the right default** — it's the optimal detector when you don't
know the signal structure, it's fast, and it adapts to a drifting noise floor.
Use **spectral anomaly** when you have a measured quiet-sky baseline (the field
case), **spectral kurtosis** to catch bursty/pulsed RFI that energy detection
might average out, and **cyclostationary** when you need to detect a known
modulation below the noise floor. The `--compare` mode runs all four so you can
see which fires on a given recording.

## The Pd vs PFA system

The operator chooses their false-alarm budget (PFA); the system computes the
detection threshold and reports the resulting probability of detection (Pd).
The **ROC family** plot shows the full tradeoff across multiple SNRs — this is
the tunable Pd-vs-PFA system the project calls for. The detection theory is
validated by Monte Carlo simulation (the empirical ROC overlays the analytic
one exactly).

Key sensitivity result: with N integration samples you get ~5·log₁₀(N) dB of
processing gain. At N=1024 the detector reliably catches signals down to about
−8 dB per-window SNR at PFA=10⁻³, Pd=0.9.

## SDR & antenna realism

The signal simulator (`twin/sdr/realism.py`) produces IQ with the impairments a
real SDR introduces, so a detector that works here works on real hardware:
gain compression/saturation, ADC quantization + clipping, LO frequency offset +
phase noise, DC offset spike, spurs, and finite image rejection. Signal types:
CW, BPSK, QPSK, pulsed, chirp, noise. Antenna realism (gain pattern, sidelobes,
pointing/tracking loss, polarization mismatch) is applied through the link
budget.

## Output

**PREDICT** writes per pass: a 6-panel dashboard, link-budget plot, sky path,
Doppler plot, per-second CSV, plus a shared ROC-family plot and
detection-performance plot, and `predict_summary.json`. Plus a color-coded
terminal warning summary:
```
[MEDIUM]  METOP-C   rise 02:01 UTC  max el 52.3°  peak dev +12.5 dB  Pd=100%
```

**DETECT** writes: a spectrogram with detection boxes overlaid, a PSD (with
baseline overlay if provided), an optional detector-comparison plot, and
`detect_summary.json` listing every detected event with time, frequency, SNR,
and confidence.

## Configuration

Everything is in `configs/config.yaml`: site, satellites, receiver hardware,
**noise baseline**, detection (PFA, N, risk thresholds, ROC SNR list, default
detector), prediction window, and the SDR simulation parameters.

**The single most important parameter** is `noise_baseline.floor_dbm`. It is the
big antenna's quiet-sky noise floor, currently set to an assumed −100 dBm. Once
you measure the real floor with the SDR kit, set the value and change
`source: measured`. Everything downstream — risk levels, deviations, Pd/PFA —
recalculates automatically.

## Where AI/ML fits (from the notes' question)

AI/ML is **not** appropriate for the orbital mechanics or link budget — those
are deterministic physics, and a learned model would only add error. Where ML
*is* valuable:
- **Learned noise-floor model**: instead of a single baseline number, train on
  historical quiet-sky recordings to model the noise floor's distribution across
  frequency, time of day, and weather — giving a smarter, adaptive baseline.
- **IQ anomaly detection**: an autoencoder or isolation forest trained on
  spectral features from healthy recordings can flag interference (and hardware
  problems) that fixed-threshold detectors miss, without needing to know the
  signal type in advance.
This would slot in as a fifth detector in `twin/detectors/`, consuming the same
IQ and emitting the same `Detection` objects as the others.

## Validation

Validated against a real recorded METOP-C L-band pass over Bedford
(2025-04-19): predicted peak C/N0 = 88–89.5 dB-Hz vs measured 89.6 dB-Hz, and
G/T = 8.27 dB/K matching the recorded data exactly. The TEME→ECEF coordinate fix
gives <1° pointing error across the pass. Run `python examples/run_tests.py` to
confirm all 12 module tests pass.

## Project structure

```
rf_twin/
  predict.py                  PREDICT mode entry point
  detect.py                   DETECT mode entry point
  configs/config.yaml         all configuration
  twin/
    core/
      propagator.py           Modules 1-2: orbit + geometry (TEME->ECEF fix)
      link_budget.py          Modules 3,4,6: link budget, interference, throughput
    detectors/
      theory.py               Module 5: Pd/PFA, ROC families, Monte Carlo
      algorithms.py           4 signal detectors (CFAR, anomaly, kurtosis, cyclo)
      predictive.py           rule-based, link-budget, HMM detectors
    sdr/
      realism.py              IQ synthesis + SDR impairments
    plots/
      figures.py              Module 7: all visualization
    io/
      common.py               config loading, risk scoring
  examples/
    run_tests.py              12-test self-check (run this first)
  cache/tle/                  auto-populated TLE cache
  outputs/                    generated per run
```
