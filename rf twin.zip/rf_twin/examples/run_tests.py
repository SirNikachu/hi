"""
rf_twin/examples/run_tests.py
==============================
Comprehensive self-test for the digital twin. Exercises every module and
prints PASS/FAIL for each. Run this to verify the whole system works:

    python examples/run_tests.py

No network or real hardware needed — uses the validated cached TLE and
synthesized signals.
"""
from __future__ import annotations
import sys, traceback
from pathlib import Path
from datetime import datetime, timezone
import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

PASS = "\033[92mPASS\033[0m"
FAIL = "\033[91mFAIL\033[0m"
results = []


def check(name, fn):
    try:
        fn()
        results.append((name, True, ""))
        print(f"  [{PASS}] {name}")
    except Exception as e:
        results.append((name, False, str(e)))
        print(f"  [{FAIL}] {name}: {e}")
        traceback.print_exc()


# ── Module 5: detection theory ───────────────────────────────────────────────
def test_theory():
    from twin.detectors import theory as t
    # PFA round-trip
    g = t.threshold_for_pfa(0.01, 1024)
    assert abs(t.pfa_for_threshold(g, 1024) - 0.01) < 1e-3, "PFA round-trip"
    # Pd increases with SNR
    pds = [t.pd_for_pfa(0.01, s, 32) for s in [-10, -5, 0, 5]]
    assert all(pds[i] <= pds[i+1] for i in range(len(pds)-1)), "Pd monotonic in SNR"
    # ROC family
    fam = t.roc_family([-6, 0, 6], 32)
    assert len(fam) == 3, "ROC family count"
    # AUC sane
    pfa, pd = t.roc_curve(6, 32)
    assert 0.9 < t.auc(pfa, pd) <= 1.0, "AUC in range"
    # min detectable SNR decreases with N
    s1 = t.min_detectable_snr_db(1e-3, 0.9, 64)
    s2 = t.min_detectable_snr_db(1e-3, 0.9, 4096)
    assert s2 < s1, "min SNR improves with integration"


def test_monte_carlo():
    from twin.detectors import theory as t
    pfa, emp, ana = t.monte_carlo_roc(3.0, 256, n_trials=3000)
    # empirical and analytic should be close
    err = np.mean(np.abs(emp - ana))
    assert err < 0.1, f"MC vs analytic mean err {err:.3f}"


# ── Detectors on IQ ──────────────────────────────────────────────────────────
def test_cfar():
    from twin.detectors import algorithms as a
    from twin.sdr import realism as sdr
    fs = 1e6
    sig = [sdr.SignalSpec(kind="cw", snr_db=15, freq_offset_hz=0,
                          t_start_s=0.5, t_end_s=1.0)]
    iq = sdr.synthesize(1.5, fs, sig, sdr.SDRImpairments(enable_compression=False), seed=0)
    r = a.cfar_energy(iq, fs, noise_power=1.0)
    assert len(r.detections) >= 1, "CFAR finds the carrier"
    d = max(r.detections, key=lambda x: x.snr_db)
    assert 0.3 < d.t_start_s < 0.7, f"CFAR timing {d.t_start_s}"


def test_spectral_anomaly():
    from twin.detectors import algorithms as a
    from twin.sdr import realism as sdr
    fs = 1e6
    sig = [sdr.SignalSpec(kind="cw", snr_db=20, freq_offset_hz=200_000)]
    iq = sdr.synthesize(1.0, fs, sig, sdr.SDRImpairments(enable_compression=False), seed=0)
    r = a.spectral_anomaly(iq, fs)
    assert len(r.detections) >= 1, "spectral anomaly finds carrier"
    d = max(r.detections, key=lambda x: x.snr_db)
    assert abs(d.freq_hz - 200_000) < 20_000, f"freq localization {d.freq_hz}"


def test_kurtosis():
    from twin.detectors import algorithms as a
    from twin.sdr import realism as sdr
    fs = 1e6
    # Pulsed signal -> high kurtosis
    sig = [sdr.SignalSpec(kind="pulsed", snr_db=15, freq_offset_hz=100_000,
                          pulse_period_s=0.02, pulse_width_s=0.001)]
    iq = sdr.synthesize(1.0, fs, sig, sdr.SDRImpairments(enable_compression=False), seed=0)
    r = a.spectral_kurtosis(iq, fs, sk_threshold=1.0)
    assert len(r.detections) >= 1, "kurtosis finds pulsed signal"


def test_compare():
    from twin.detectors import algorithms as a
    from twin.sdr import realism as sdr
    fs = 1e6
    sig = [sdr.SignalSpec(kind="qpsk", snr_db=12, symbol_rate_hz=50000)]
    iq = sdr.synthesize(1.0, fs, sig, seed=0)
    res = a.compare_detectors(iq, fs, noise_power=1.0)
    assert set(res.keys()) == {"cfar_energy", "spectral_anomaly",
                               "spectral_kurtosis", "cyclostationary"}, "all detectors run"


# ── Predictive detectors ─────────────────────────────────────────────────────
def test_predictive():
    from twin.detectors import predictive as p
    n = 300
    t = np.arange(n, dtype=float)
    el = 15 + 35*np.sin(np.pi*t/n)
    dev = -5 + 25*np.sin(np.pi*t/n)
    track = {"t_s": t, "el_deg": el}
    lb = {"deviation_db": dev}
    nc = {"margin_db": 6.0}
    rt = {"low_db": 3, "medium_db": 10, "high_db": 20}
    # rule-based
    sc = {"frequency_hz": 1701.3e6, "bandwidth_hz": 3e6}
    r = p.rule_based_overlap(track, sc, (1700e6, 1702e6))
    assert r["band_overlap"], "band overlap detected"
    # link-budget
    r = p.link_budget_detection(track, lb, nc, rt)
    assert r["peak_deviation_db"] > 15, "peak deviation"
    # HMM
    r = p.hmm_interference(track, lb, nc)
    assert len(r["intervals"]) >= 1, "HMM finds interval"
    assert r["fraction_interfered"] > 0, "HMM fraction"


# ── Module 1-2: propagation ──────────────────────────────────────────────────
def test_propagation():
    from twin.core.propagator import _parse_tle, propagate_passes
    tle_text = ("METOP-C\n"
                "1 43689U 18087A   25109.19020060  .00000246  00000+0  13219-3 0  9999\n"
                "2 43689  98.6777 170.1931 0000320  15.7345 344.3842 14.21515771334594")
    tle = _parse_tle(tle_text)
    assert tle is not None, "TLE parse"
    start = datetime(2025, 4, 19, 0, 0, tzinfo=timezone.utc)
    end = datetime(2025, 4, 20, 0, 0, tzinfo=timezone.utc)
    passes = propagate_passes(tle, 42.50518, -71.23530, 68.0, start, end,
                              mask_deg=10.0, freq_hz=1701.3e6)
    assert len(passes) == 4, f"expected 4 passes, got {len(passes)}"
    # peak elevation of best pass
    max_el = max(p.info.max_elevation_deg for p in passes)
    assert 55 < max_el < 65, f"peak elevation {max_el}"
    # Doppler sane (~36 kHz)
    best = max(passes, key=lambda p: p.info.max_elevation_deg)
    dopp = np.max(np.abs(best.track["doppler_hz"]))
    assert 30e3 < dopp < 42e3, f"Doppler {dopp/1e3:.1f} kHz"


# ── Module 3-4: link budget ──────────────────────────────────────────────────
def test_link_budget():
    from twin.core.propagator import _parse_tle, propagate_passes
    from twin.core.link_budget import compute_link_budget
    from twin.io.common import load_config
    cfg = load_config(str(Path(__file__).parent.parent/"configs"/"config.yaml"))
    tle_text = ("METOP-C\n"
                "1 43689U 18087A   25109.19020060  .00000246  00000+0  13219-3 0  9999\n"
                "2 43689  98.6777 170.1931 0000320  15.7345 344.3842 14.21515771334594")
    tle = _parse_tle(tle_text)
    start = datetime(2025, 4, 19, 0, 0, tzinfo=timezone.utc)
    end = datetime(2025, 4, 20, 0, 0, tzinfo=timezone.utc)
    passes = propagate_passes(tle, 42.50518, -71.23530, 68.0, start, end,
                              mask_deg=10.0, freq_hz=1701.3e6)
    best = max(passes, key=lambda p: p.info.max_elevation_deg)
    lb = compute_link_budget(best.track, cfg["satellites"][0], cfg["receiver"],
                             cfg["noise_baseline"])
    # Validated: G/T = 8.27, peak C/N0 ~88-90
    assert abs(lb["g_over_t_db"] - 8.27) < 0.2, f"G/T {lb['g_over_t_db']}"
    assert 86 < lb["cn0_dbhz"].max() < 91, f"peak C/N0 {lb['cn0_dbhz'].max()}"


# ── Module 6: throughput ─────────────────────────────────────────────────────
def test_throughput():
    from twin.core.link_budget import estimate_outages_throughput
    n = 300
    t = np.arange(n, dtype=float)
    track = {"t_s": t}
    lb = {"cn0_dbhz": 40 + 20*np.sin(np.pi*t/n), "snr_db": 5 + 15*np.sin(np.pi*t/n)}
    sc = {"bandwidth_hz": 3e6}
    r = estimate_outages_throughput(track, lb, sc, 35.0)
    assert r["delivered_megabytes"] > 0, "throughput positive"
    assert r["usable_seconds"] <= r["total_seconds"], "usable <= total"


# ── SDR realism ──────────────────────────────────────────────────────────────
def test_sdr():
    from twin.sdr import realism as sdr
    fs = 1e6
    for kind in ["cw", "bpsk", "qpsk", "pulsed", "chirp", "noise"]:
        sig = [sdr.SignalSpec(kind=kind, snr_db=10)]
        iq = sdr.synthesize(0.5, fs, sig, seed=0)
        assert len(iq) == int(0.5*fs), f"{kind} length"
        assert iq.dtype == np.complex64, f"{kind} dtype"
    # int16 round trip
    iq = sdr.synthesize(0.1, fs, [sdr.SignalSpec(kind="cw")], seed=0)
    i16 = sdr.to_int16_interleaved(iq)
    iq2 = sdr.from_int16_interleaved(i16)
    assert len(iq2) == len(iq), "int16 round-trip length"


# ── Plots ────────────────────────────────────────────────────────────────────
def test_plots():
    from twin.plots import figures as f
    import tempfile
    d = Path(tempfile.mkdtemp())
    p = f.plot_roc_family([-6, 0, 6], 32, d/"roc.png", operating_pfa=0.01)
    assert p.exists() and p.stat().st_size > 1000, "ROC family plot"
    p = f.plot_detection_performance([-6, 0, 6], [16, 256], d/"perf.png")
    assert p.exists(), "detection performance plot"


if __name__ == "__main__":
    print("=" * 60)
    print("RF DIGITAL TWIN — SELF TEST")
    print("=" * 60)
    print("\nModule 5 — Detection theory")
    check("threshold/PFA/Pd math", test_theory)
    check("Monte Carlo validates analytic ROC", test_monte_carlo)
    print("\nDetectors on IQ")
    check("CFAR energy detector", test_cfar)
    check("Spectral anomaly detector", test_spectral_anomaly)
    check("Spectral kurtosis detector", test_kurtosis)
    check("Detector comparison (all 4)", test_compare)
    print("\nPredictive detectors")
    check("Rule-based / link-budget / HMM", test_predictive)
    print("\nModules 1-2 — Orbit & geometry")
    check("SGP4 propagation + TEME->ECEF", test_propagation)
    print("\nModules 3-4 — Link budget & interference")
    check("Link budget (validated numbers)", test_link_budget)
    print("\nModule 6 — Throughput & outage")
    check("Throughput estimation", test_throughput)
    print("\nSDR realism")
    check("Signal synthesis + impairments", test_sdr)
    print("\nModule 7 — Visualization")
    check("Plot generation", test_plots)

    n_pass = sum(1 for _, ok, _ in results if ok)
    n_total = len(results)
    print("\n" + "=" * 60)
    color = "\033[92m" if n_pass == n_total else "\033[91m"
    print(f"{color}{n_pass}/{n_total} tests passed\033[0m")
    print("=" * 60)
    sys.exit(0 if n_pass == n_total else 1)
