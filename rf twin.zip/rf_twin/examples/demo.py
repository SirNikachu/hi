"""
rf_twin/examples/demo.py
=========================
Generates a full showcase of the digital twin's outputs into ./demo_output/:
  - ROC family (the tunable Pd vs PFA curves)
  - Detection performance (Pd vs SNR, sensitivity vs integration)
  - A predicted pass dashboard (using the validated METOP-C pass)
  - A detect-mode spectrogram with detections + detector comparison

Run:  python examples/demo.py
This uses the cached TLE + synthesized signals, so no network/hardware needed.
"""
from __future__ import annotations
import sys
from pathlib import Path
from datetime import datetime, timezone
import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from twin.io.common import load_config, risk_level
from twin.core.propagator import _parse_tle, propagate_passes
from twin.core.link_budget import compute_link_budget, estimate_outages_throughput
from twin.detectors import theory
from twin.sdr import realism as sdr
from twin.detectors import algorithms as algo
from twin.plots import figures as figs

HERE = Path(__file__).parent
ROOT = HERE.parent
OUT = HERE / "demo_output"
OUT.mkdir(exist_ok=True)

cfg = load_config(str(ROOT / "configs" / "config.yaml"))

print("=" * 60)
print("RF DIGITAL TWIN — DEMO SHOWCASE")
print("=" * 60)

# ── 1. ROC family (PREDICT detection theory) ─────────────────────────────────
print("\n[1/5] ROC family (tunable Pd vs PFA)...")
figs.plot_roc_family(cfg["detection"]["roc_snr_list_db"],
                     cfg["detection"]["roc_n_for_family"],
                     OUT / "1_roc_family.png",
                     operating_pfa=cfg["detection"]["default_pfa"],
                     monte_carlo_snr=0.0,
                     title_extra=f"  [N={cfg['detection']['roc_n_for_family']} window]")

# ── 2. Detection performance ─────────────────────────────────────────────────
print("[2/5] Detection performance (Pd vs SNR, sensitivity vs N)...")
figs.plot_detection_performance(cfg["detection"]["roc_snr_list_db"],
                                [16, 64, 256, 1024],
                                OUT / "2_detection_performance.png",
                                pfa=cfg["detection"]["default_pfa"])

# ── 3. Predicted pass dashboard (validated METOP-C pass) ─────────────────────
print("[3/5] Predicted pass dashboard (validated METOP-C)...")
tle = _parse_tle((ROOT / "cache" / "tle" / "43689.tle").read_text())
site = cfg["site"]
passes = propagate_passes(tle, site["lat_deg"], site["lon_deg"], site["alt_m"],
                          datetime(2025, 4, 19, 0, 0, tzinfo=timezone.utc),
                          datetime(2025, 4, 20, 0, 0, tzinfo=timezone.utc),
                          mask_deg=10.0, freq_hz=cfg["satellites"][0]["frequency_hz"])
best = max(passes, key=lambda p: p.info.max_elevation_deg)
lb = compute_link_budget(best.track, cfg["satellites"][0], cfg["receiver"],
                         cfg["noise_baseline"],
                         pointing_error_deg=cfg["receiver"]["pointing_error_deg"])
dev = float(np.max(lb["deviation_db"]))
snr = float(np.max(lb["snr_db"]))
risk = {"risk_level": risk_level(dev, cfg), "peak_deviation_db": dev,
        "peak_snr_db": snr, "pfa": cfg["detection"]["default_pfa"],
        "pd_at_pfa": theory.pd_for_pfa(cfg["detection"]["default_pfa"], snr,
                                       cfg["detection"]["n_samples"])}
figs.plot_pass_dashboard(best.track, lb, risk, "METOP-C", best.info.pass_index,
                         cfg, OUT / "3_pass_dashboard.png")
tput = estimate_outages_throughput(best.track, lb, cfg["satellites"][0],
                                   cfg["prediction"]["cn0_threshold_dbhz"])
print(f"      Pass: max el {best.info.max_elevation_deg:.1f}°, "
      f"peak dev {dev:.1f} dB, risk {risk['risk_level']}, "
      f"delivered {tput['delivered_megabytes']:.0f} MB")

# ── 4 & 5. Detect mode: spectrogram + detector comparison ────────────────────
print("[4/5] Detect-mode spectrogram with detections...")
fs = 1e6
signals = [
    sdr.SignalSpec(kind="qpsk", snr_db=10, freq_offset_hz=-150_000,
                   symbol_rate_hz=50_000, t_start_s=0.7, t_end_s=2.7),
    sdr.SignalSpec(kind="cw", snr_db=14, freq_offset_hz=220_000,
                   t_start_s=2.0, t_end_s=4.0),
    sdr.SignalSpec(kind="pulsed", snr_db=16, freq_offset_hz=50_000,
                   pulse_period_s=0.02, pulse_width_s=0.002),
]
iq = sdr.synthesize(5.0, fs, signals, sdr.SDRImpairments(spurs_hz=(60_000,)), seed=1)
results = algo.compare_detectors(iq, fs, noise_power=1.0)
union = [d for r in results.values() for d in r.detections]
figs.plot_spectrogram_with_detections(iq, fs, 0.0, union,
                                       OUT / "4_detect_spectrogram.png",
                                       title="Detect mode: all detectors")
print(f"      {len(union)} total detections across all detectors")

print("[5/5] Detector comparison...")
figs.plot_detector_comparison(results, OUT / "5_detector_comparison.png",
                              title="Detector comparison on realistic IQ")

print(f"\n[done] All demo outputs → {OUT.resolve()}")
for f in sorted(OUT.iterdir()):
    print(f"  {f.name}  ({f.stat().st_size // 1024} KB)")
