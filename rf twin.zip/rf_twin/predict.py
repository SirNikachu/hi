"""
rf_twin/predict.py — PREDICT MODE
==================================
"When will satellites interfere, how badly, and what detection performance
can I expect?"

Runs the full prediction pipeline for every configured satellite:
  Module 1  orbit/pass prediction        (TLE + SGP4 + TEME->ECEF)
  Module 2  geometry & kinematics        (az/el/range/Doppler/range-rate)
  Module 3  RF prop & link budget        (FSPL/atmos/RX power/C-N0/SNR)
  Module 4  interference & noise modeling (deviation above baseline)
  Module 5  detection & decision theory   (Pd/PFA, ROC family, min SNR)
  Module 6  outage & throughput           (usable seconds, delivered MB)
  Module 7  reporting & visualization     (plots, CSV, JSON, terminal summary)

Usage:
  python predict.py
  python predict.py --next 48 --sat METOP-C
  python predict.py --pfa 0.001 --baseline -110
  python predict.py --no-plots
  python predict.py --refresh-tle
"""
from __future__ import annotations
import argparse, json, sys, csv
from datetime import datetime, timezone, timedelta
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from twin.io.common import load_config, risk_level, COLORS
from twin.core.propagator import get_tle, propagate_passes
from twin.core.link_budget import compute_link_budget, estimate_outages_throughput
from twin.detectors import theory
from twin.detectors.predictive import (rule_based_overlap, link_budget_detection,
                                       hmm_interference)
from twin.plots import figures as figs


def pass_risk(track, lb, cfg):
    """Compute risk + Pd/PFA summary for a pass."""
    dev = np.asarray(lb["deviation_db"])
    snr = np.asarray(lb["snr_db"])
    peak_dev = float(np.max(dev))
    peak_snr = float(np.max(snr))
    n = cfg["detection"]["n_samples"]
    pfa = cfg["detection"]["default_pfa"]
    # per-window SNR for detection: use a single short window at the SNR peak
    n_roc = cfg["detection"]["roc_n_for_family"]
    pd = theory.pd_for_pfa(pfa, peak_snr, n)
    return {
        "peak_deviation_db": peak_dev,
        "peak_snr_db": peak_snr,
        "risk_level": risk_level(peak_dev, cfg),
        "pfa": pfa,
        "pd_at_pfa": pd,
        "min_detectable_snr_db": theory.min_detectable_snr_db(pfa, 0.9, n),
    }


def run_pass(pp, sat_cfg, cfg, out_dir, do_plots):
    idx = pp.info.pass_index
    track = pp.track
    info = pp.info
    print(f"\n  Pass {idx}: rise {info.rise_utc:%H:%M:%S}  "
          f"culm {info.culmination_utc:%H:%M:%S}  set {info.set_utc:%H:%M:%S}  "
          f"max el {info.max_elevation_deg:.1f}°  dur {info.duration_s:.0f}s")

    lb = compute_link_budget(
        track, sat_cfg, cfg["receiver"], cfg["noise_baseline"],
        pointing_error_deg=cfg["receiver"].get("pointing_error_deg", 0.0),
        polarization_loss_db=cfg["receiver"].get("polarization_loss_db", 0.5))

    risk = pass_risk(track, lb, cfg)
    rc = COLORS.get(risk["risk_level"], ""); rst = COLORS["RESET"]
    print(f"    {rc}[{risk['risk_level']} RISK]{rst}  peak dev "
          f"{risk['peak_deviation_db']:+.1f} dB  |  peak SNR {risk['peak_snr_db']:.1f} dB  |  "
          f"Pd={risk['pd_at_pfa']*100:.0f}% @ PFA={risk['pfa']:.0e}")

    # Module 6: outage & throughput
    tput = estimate_outages_throughput(track, lb, sat_cfg,
                                       cfg["prediction"]["cn0_threshold_dbhz"])
    print(f"    usable {tput['usable_seconds']:.0f}/{tput['total_seconds']:.0f}s  "
          f"peak {tput['peak_capacity_mbps']:.1f} Mbps  "
          f"delivered {tput['delivered_megabytes']:.0f} MB  "
          f"outages {tput['outage_count']}")

    # Predictive detectors
    band = (cfg["antenna_band"]["f_low_hz"], cfg["antenna_band"]["f_high_hz"])
    overlap = rule_based_overlap(track, sat_cfg, band,
                                 cfg["prediction"]["elevation_mask_deg"])
    lbdet = link_budget_detection(track, lb, cfg["noise_baseline"],
                                  cfg["detection"]["risk_thresholds"])
    hmm = hmm_interference(track, lb, cfg["noise_baseline"])

    # CSV
    if cfg["output"]["save_csv"]:
        _write_csv(out_dir / f"pass_{idx}_track.csv", track, lb)

    plots = []
    if do_plots and cfg["output"]["save_plots"]:
        print("    plots...", end=" ", flush=True)
        plots.append(figs.plot_pass_dashboard(track, lb, risk, sat_cfg["name"],
                                              idx, cfg, out_dir / f"pass_{idx}_dashboard.png"))
        plots.append(figs.plot_link_budget(track, lb, sat_cfg, cfg, idx,
                                           out_dir / f"pass_{idx}_link_budget.png"))
        plots.append(figs.plot_skypath(track, sat_cfg, idx,
                                       out_dir / f"pass_{idx}_skypath.png"))
        plots.append(figs.plot_doppler(track, sat_cfg, idx,
                                       out_dir / f"pass_{idx}_doppler.png"))
        print(f"done ({len(plots)})")

    return {
        "pass_index": idx, "satellite": sat_cfg["name"],
        "frequency_mhz": sat_cfg["frequency_hz"] / 1e6,
        "rise_utc": info.rise_utc.isoformat(),
        "culmination_utc": info.culmination_utc.isoformat(),
        "set_utc": info.set_utc.isoformat(),
        "max_elevation_deg": info.max_elevation_deg,
        "duration_s": info.duration_s,
        "risk": risk, "throughput": tput,
        "band_overlap": overlap["band_overlap"],
        "hmm_fraction_interfered": hmm["fraction_interfered"],
        "interference_intervals": [
            {"start_s": iv.t_start_s, "end_s": iv.t_end_s, "state": iv.state,
             "peak_dev_db": iv.peak_deviation_db} for iv in hmm["intervals"]],
    }


def _write_csv(path, track, lb):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["t_s","az_deg","el_deg","range_km","range_rate_mps",
                    "doppler_hz","fspl_db","atmos_db","rx_power_dbw",
                    "cn0_dbhz","snr_db","deviation_db"])
        t = track["t_s"]
        for i in range(len(t)):
            w.writerow([f"{t[i]:.1f}", f"{track['az_deg'][i]:.3f}",
                        f"{track['el_deg'][i]:.3f}", f"{track['range_m'][i]/1000:.2f}",
                        f"{track['range_rate_mps'][i]:.2f}", f"{track['doppler_hz'][i]:.1f}",
                        f"{lb['fspl_db'][i]:.3f}", f"{lb['atmos_db'][i]:.4f}",
                        f"{lb['rx_power_dbw'][i]:.3f}", f"{lb['cn0_dbhz'][i]:.3f}",
                        f"{lb['snr_db'][i]:.3f}", f"{lb['deviation_db'][i]:.3f}"])


def main():
    ap = argparse.ArgumentParser(description="PREDICT mode — forecast interference.")
    ap.add_argument("--config", default=str(Path(__file__).parent/"configs"/"config.yaml"))
    ap.add_argument("--next", dest="next_hours", type=float, default=None)
    ap.add_argument("--sat", default=None)
    ap.add_argument("--pfa", type=float, default=None)
    ap.add_argument("--baseline", type=float, default=None)
    ap.add_argument("--mask", type=float, default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--no-plots", action="store_true")
    ap.add_argument("--refresh-tle", action="store_true")
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.pfa is not None: cfg["detection"]["default_pfa"] = args.pfa
    if args.baseline is not None:
        cfg["noise_baseline"]["floor_dbm"] = args.baseline
        cfg["noise_baseline"]["source"] = "cli_override"
    if args.mask is not None: cfg["prediction"]["elevation_mask_deg"] = args.mask
    if args.out is not None: cfg["output"]["dir"] = args.out

    now = datetime.now(timezone.utc)
    window_h = args.next_hours or cfg["prediction"]["window_hours"]
    end = now + timedelta(hours=window_h)
    site = cfg["site"]
    out_dir = Path(cfg["output"]["dir"]); out_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("RF INTERFERENCE DIGITAL TWIN  —  PREDICT MODE")
    print("=" * 70)
    print(f"Site:     {site['name']} ({site['lat_deg']:.4f}, {site['lon_deg']:.4f}, {site['alt_m']:.0f}m)")
    print(f"Window:   {now:%Y-%m-%d %H:%M} → {end:%H:%M} UTC ({window_h:.0f}h)")
    print(f"Baseline: {cfg['noise_baseline']['floor_dbm']:.1f} dBm "
          f"[{cfg['noise_baseline']['source']}]  margin {cfg['noise_baseline']['margin_db']:.0f} dB")
    print(f"PFA:      {cfg['detection']['default_pfa']:.0e}   "
          f"N={cfg['detection']['n_samples']}   mask {cfg['prediction']['elevation_mask_deg']:.0f}°")
    print("=" * 70)

    sats = cfg["satellites"]
    if args.sat:
        q = args.sat.strip().lower()
        sats = [s for s in sats if q in s["name"].lower() or str(s["norad_id"]) == q]
        if not sats:
            print(f"[!] no satellite matches '{args.sat}'"); sys.exit(1)

    all_results = []
    for sat_cfg in sats:
        print(f"\n{'─'*70}\nSATELLITE: {sat_cfg['name']} (NORAD {sat_cfg['norad_id']}) "
              f"@ {sat_cfg['frequency_hz']/1e6:.4f} MHz\n{'─'*70}")
        try:
            tle = get_tle(sat_cfg["norad_id"],
                          max_age_hours=cfg["prediction"]["tle_max_age_hours"],
                          force=args.refresh_tle)
            passes = propagate_passes(tle, site["lat_deg"], site["lon_deg"], site["alt_m"],
                                      now, end, mask_deg=cfg["prediction"]["elevation_mask_deg"],
                                      freq_hz=sat_cfg["frequency_hz"])
            if not passes:
                print(f"  no passes above {cfg['prediction']['elevation_mask_deg']:.0f}° in window"); continue
            print(f"  found {len(passes)} pass(es)")
            sat_out = out_dir / sat_cfg["name"].replace("/", "_").replace(" ", "_")
            sat_out.mkdir(exist_ok=True)
            for pp in passes:
                all_results.append(run_pass(pp, sat_cfg, cfg, sat_out, not args.no_plots))
        except Exception as e:
            print(f"  [ERROR] {e}"); import traceback; traceback.print_exc()

    # ROC family + detection performance (once, shared)
    if not args.no_plots and all_results:
        print(f"\n  generating ROC family + detection performance...")
        figs.plot_roc_family(cfg["detection"]["roc_snr_list_db"],
                             cfg["detection"]["roc_n_for_family"],
                             out_dir / "roc_family.png",
                             operating_pfa=cfg["detection"]["default_pfa"],
                             monte_carlo_snr=0.0,
                             title_extra=f"  [N={cfg['detection']['roc_n_for_family']} window]")
        figs.plot_detection_performance(cfg["detection"]["roc_snr_list_db"],
                                        [16, 64, 256, 1024],
                                        out_dir / "detection_performance.png",
                                        pfa=cfg["detection"]["default_pfa"])

    # Warning summary
    print(f"\n{'='*70}\nINTERFERENCE WARNING SUMMARY\n{'='*70}")
    risky = [r for r in all_results if r["risk"]["risk_level"] != "NONE"]
    if not risky:
        print("  no interference-risk passes in this window")
    else:
        for r in sorted(risky, key=lambda x: x["rise_utc"]):
            rl = r["risk"]["risk_level"]; rc = COLORS.get(rl, ""); rst = COLORS["RESET"]
            print(f"  {rc}[{rl:6s}]{rst}  {r['satellite']:<16}  rise {r['rise_utc'][11:19]} UTC  "
                  f"max el {r['max_elevation_deg']:5.1f}°  peak dev {r['risk']['peak_deviation_db']:+5.1f} dB  "
                  f"Pd={r['risk']['pd_at_pfa']*100:.0f}%")

    if cfg["output"]["save_json"]:
        summary = {"run_utc": now.isoformat(), "mode": "predict",
                   "window_hours": window_h, "site": site,
                   "noise_baseline": cfg["noise_baseline"],
                   "detection_config": cfg["detection"], "passes": all_results}
        (out_dir / "predict_summary.json").write_text(json.dumps(summary, indent=2, default=str))
        print(f"\n[saved] {out_dir/'predict_summary.json'}")

    print(f"\n[done] {len(all_results)} pass(es) → {out_dir.resolve()}")


if __name__ == "__main__":
    main()
