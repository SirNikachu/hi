"""twin/sdr/realism.py
=====================
SDR & signal realism (Module: SDR realism + antenna realism from notes).

Synthesizes realistic IQ recordings for testing the detectors, including the
hardware impairments a real SDR introduces. This is what makes the synthetic
data actually useful: a detector that works here will work on real hardware
because the same artifacts are present.

Signal types:
  - cw          : continuous carrier (beacon, unmodulated)
  - bpsk/qpsk   : phase-modulated data (realistic satellite downlink)
  - pulsed      : bursty interference (radar-like, triggers spectral kurtosis)
  - chirp       : swept-frequency interference
  - noise       : noise-only (for false-alarm testing)

SDR impairments (each toggentable):
  - thermal noise floor (always)
  - Doppler shift + drift over the pass
  - gain compression / saturation (1 dB compression point)
  - ADC quantization + clipping
  - LO phase noise + frequency offset
  - spurs (discrete spurious tones) and images
  - DC offset spike at the tuner center

Antenna realism is applied via the link budget (gain pattern, pointing loss),
which sets the SNR that scales the signal amplitude here.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np


@dataclass
class SDRImpairments:
    """Toggleable SDR hardware impairments."""
    adc_bits: int = 12                 # ADC resolution (sets quantization floor)
    adc_clip_level: float = 1.0        # clipping threshold (fraction of full scale)
    enable_clipping: bool = True
    p1db_backoff_db: float = 6.0       # backoff from 1-dB compression point
    enable_compression: bool = True
    lo_freq_offset_hz: float = 500.0   # LO frequency error
    lo_phase_noise_dbc: float = -80.0  # phase noise level (dBc/Hz)
    enable_lo_effects: bool = True
    dc_offset: float = 0.02            # DC spike amplitude (fraction)
    enable_dc_offset: bool = True
    spurs_hz: tuple = ()               # discrete spur frequencies (baseband)
    spur_level_db: float = -40.0       # spur level relative to full scale
    enable_spurs: bool = True
    image_rejection_db: float = 40.0   # image suppression (finite -> small image)
    enable_images: bool = False


@dataclass
class SignalSpec:
    """A signal to inject into the recording."""
    kind: str = "cw"                   # cw|bpsk|qpsk|pulsed|chirp|noise
    snr_db: float = 10.0               # SNR relative to noise floor
    freq_offset_hz: float = 0.0        # offset from tuner center
    doppler_hz: float = 0.0            # Doppler at t=0
    doppler_rate_hz_s: float = 0.0     # Doppler drift (linear)
    t_start_s: float = 0.0             # signal turn-on time
    t_end_s: float | None = None       # signal turn-off (None = whole record)
    symbol_rate_hz: float = 50_000.0   # for modulated signals
    pulse_period_s: float = 0.01       # for pulsed
    pulse_width_s: float = 0.001       # for pulsed
    chirp_bw_hz: float = 100_000.0     # for chirp


NOISE_RMS = 1.0   # noise floor RMS (normalized); signal scaled relative to this


def _make_signal(spec: SignalSpec, n: int, fs: float, rng) -> np.ndarray:
    t = np.arange(n) / fs
    amp = NOISE_RMS * 10 ** (spec.snr_db / 20)
    # instantaneous phase from offset + Doppler + drift
    f_inst = spec.freq_offset_hz + spec.doppler_hz + spec.doppler_rate_hz_s * t
    phase = 2 * np.pi * np.cumsum(f_inst) / fs

    if spec.kind == "cw":
        sig = amp * np.exp(1j * phase)
    elif spec.kind in ("bpsk", "qpsk"):
        sps = max(1, int(fs / spec.symbol_rate_hz))
        n_sym = n // sps + 1
        if spec.kind == "bpsk":
            syms = rng.choice([1, -1], n_sym)
        else:
            syms = rng.choice([1+1j, 1-1j, -1+1j, -1-1j], n_sym) / np.sqrt(2)
        baseband = np.repeat(syms, sps)[:n]
        sig = amp * baseband * np.exp(1j * phase)
    elif spec.kind == "pulsed":
        env = np.zeros(n)
        period = max(1, int(spec.pulse_period_s * fs))
        width = max(1, int(spec.pulse_width_s * fs))
        for start in range(0, n, period):
            env[start:start+width] = 1.0
        sig = amp * env * np.exp(1j * phase)
    elif spec.kind == "chirp":
        k = spec.chirp_bw_hz / (n / fs)
        chirp_phase = 2 * np.pi * (0.5 * k * t**2)
        sig = amp * np.exp(1j * (phase + chirp_phase))
    elif spec.kind == "noise":
        sig = np.zeros(n, dtype=complex)
    else:
        raise ValueError(f"unknown signal kind: {spec.kind}")

    # gate on/off
    mask = (t >= spec.t_start_s)
    if spec.t_end_s is not None:
        mask &= (t <= spec.t_end_s)
    sig = sig * mask
    return sig


def synthesize(duration_s: float, fs: float, signals: list[SignalSpec],
               impairments: SDRImpairments | None = None,
               seed: int = 0) -> np.ndarray:
    """Generate a realistic IQ recording: noise + injected signals + SDR
    impairments. Returns complex64 IQ at sample rate fs."""
    rng = np.random.default_rng(seed)
    n = int(duration_s * fs)
    imp = impairments or SDRImpairments()

    # 1) thermal noise floor
    iq = (rng.standard_normal(n) + 1j*rng.standard_normal(n)) * (NOISE_RMS/np.sqrt(2))

    # 2) inject signals
    for s in signals:
        iq = iq + _make_signal(s, n, fs, rng)

    # 3) LO effects: frequency offset + phase noise
    if imp.enable_lo_effects:
        t = np.arange(n) / fs
        iq = iq * np.exp(1j * 2*np.pi*imp.lo_freq_offset_hz*t)
        pn_std = 10 ** (imp.lo_phase_noise_dbc / 20) * np.sqrt(fs/2)
        phase_noise = np.cumsum(rng.standard_normal(n)) * pn_std / fs
        iq = iq * np.exp(1j * phase_noise)

    # 4) spurs
    if imp.enable_spurs and imp.spurs_hz:
        t = np.arange(n) / fs
        spur_amp = 10 ** (imp.spur_level_db / 20)
        for f in imp.spurs_hz:
            iq = iq + spur_amp * np.exp(1j*2*np.pi*f*t)

    # 5) gain compression (soft saturation via tanh)
    if imp.enable_compression:
        sat = NOISE_RMS * 10 ** ((imp.p1db_backoff_db + 10) / 20)
        mag = np.abs(iq)
        compressed = sat * np.tanh(mag / sat)
        iq = compressed * np.exp(1j * np.angle(iq))

    # 6) DC offset spike
    if imp.enable_dc_offset:
        iq = iq + imp.dc_offset * NOISE_RMS

    # 7) image (finite rejection)
    if imp.enable_images:
        img_amp = 10 ** (-imp.image_rejection_db / 20)
        iq = iq + img_amp * np.conj(iq)

    # 8) ADC quantization + clipping
    if imp.enable_clipping:
        full_scale = NOISE_RMS * 10 ** ((imp.p1db_backoff_db + 12) / 20)
        clip = imp.adc_clip_level * full_scale
        iq_i = np.clip(iq.real, -clip, clip)
        iq_q = np.clip(iq.imag, -clip, clip)
        levels = 2 ** imp.adc_bits
        step = 2 * clip / levels
        iq_i = np.round(iq_i / step) * step
        iq_q = np.round(iq_q / step) * step
        iq = iq_i + 1j*iq_q

    return iq.astype(np.complex64)


def to_int16_interleaved(iq: np.ndarray, scale: float | None = None) -> np.ndarray:
    """Pack complex IQ to int16 interleaved (real recording format)."""
    if scale is None:
        peak = np.max(np.abs(iq)) + 1e-12
        scale = 30000.0 / peak
    i16 = np.empty(2 * len(iq), dtype=np.int16)
    i16[0::2] = np.clip(iq.real * scale, -32767, 32767).astype(np.int16)
    i16[1::2] = np.clip(iq.imag * scale, -32767, 32767).astype(np.int16)
    return i16


def from_int16_interleaved(path_or_array, count: int = -1) -> np.ndarray:
    """Read int16 interleaved IQ (real recording format) to complex64."""
    if isinstance(path_or_array, (str, bytes)):
        arr = np.fromfile(path_or_array, dtype=np.int16, count=count*2 if count > 0 else -1)
    else:
        arr = np.asarray(path_or_array, dtype=np.int16)
    return (arr[0::2].astype(np.float32) + 1j*arr[1::2].astype(np.float32))
