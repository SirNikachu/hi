"""twin/plots/figures.py
========================
All visualization (Module 7: reporting & visualization).

Two plot groups:
  PREDICT plots  -- pass geometry, link budget, Doppler, sky path, ROC family,
                    detection-performance prediction, interference timeline.
  DETECT plots   -- spectrogram with detections overlaid, detector comparison,
                    CFAR timeline, spectral kurtosis, ROC (empirical vs analytic).
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

from twin.detectors import theory


def _save(fig, path, dpi=120):
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    return Path(path)


# ════════════════════════════════════════════════════════════════════════════
# ROC FAMILY  (the curve the project actually wanted)
# ════════════════════════════════════════════════════════════════════════════

def plot_roc_family(snr_list, n_samples, out_path, *, operating_pfa=None,
                    title_extra="", log_x=True, monte_carlo_snr=None):
    """Family of ROC curves at multiple SNRs -- the classic detection plot.
    Optionally overlays a Monte Carlo validation at one SNR and marks the
    operator's chosen PFA operating line."""
    fig, ax = plt.subplots(figsize=(9, 7))
    colors = plt.cm.viridis(np.linspace(0, 0.9, len(snr_list)))
    for snr, c in zip(snr_list, colors):
        pfa, pd = theory.roc_curve(snr, n_samples)
        a = theory.auc(pfa, pd)
        ax.plot(pfa, pd, lw=2, color=c, label=f"SNR={snr:+.0f} dB (AUC={a:.3f})")

    if monte_carlo_snr is not None:
        pfa_mc, pd_emp, pd_ana = theory.monte_carlo_roc(monte_carlo_snr, n_samples,
                                                        n_trials=8000)
        ax.plot(pfa_mc, pd_emp, "o", ms=4, color="red", alpha=0.6,
                label=f"Monte Carlo (SNR={monte_carlo_snr:+.0f} dB)")

    if operating_pfa is not None:
        ax.axvline(operating_pfa, color="crimson", ls="--", lw=1.2,
                   label=f"Operating PFA = {operating_pfa:.0e}")

    if log_x:
        ax.set_xscale("log"); ax.set_xlim(1e-6, 1)
    else:
        ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    ax.set_xlabel("Probability of False Alarm (PFA)")
    ax.set_ylabel("Probability of Detection (Pd)")
    ax.set_title(f"ROC Family — Energy Detector (N={n_samples} samples){title_extra}")
    ax.grid(alpha=0.3, which="both"); ax.legend(loc="lower right", fontsize=8)
    return _save(fig, out_path)


def plot_detection_performance(snr_list, n_list, out_path, *, pfa=1e-3):
    """Detection-performance prediction: Pd vs SNR for several integration
    lengths, plus min-detectable-SNR markers. Answers 'how weak a signal can
    I catch, and how long must I integrate?'"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    snr_grid = np.linspace(-15, 15, 200)
    colors = plt.cm.plasma(np.linspace(0, 0.85, len(n_list)))
    for n, c in zip(n_list, colors):
        pd = [theory.pd_for_pfa(pfa, s, n) for s in snr_grid]
        ax1.plot(snr_grid, pd, lw=2, color=c, label=f"N={n}")
        smin = theory.min_detectable_snr_db(pfa, 0.9, n)
        ax1.axvline(smin, color=c, ls=":", lw=1, alpha=0.6)
    ax1.set(xlabel="Per-window SNR (dB)", ylabel="Probability of Detection",
            title=f"Pd vs SNR  (PFA={pfa:.0e}, dotted = min SNR for Pd=0.9)")
    ax1.grid(alpha=0.3); ax1.legend(fontsize=8); ax1.set_ylim(0, 1.02)

    # Min detectable SNR vs N
    n_grid = np.logspace(1, 5, 60).astype(int)
    smin_grid = [theory.min_detectable_snr_db(pfa, 0.9, n) for n in n_grid]
    ax2.semilogx(n_grid, smin_grid, lw=2, color="tab:blue")
    ax2.set(xlabel="Integration samples N", ylabel="Min detectable SNR (dB)",
            title=f"Sensitivity vs integration  (PFA={pfa:.0e}, Pd=0.9)")
    ax2.grid(alpha=0.3, which="both")
    return _save(fig, out_path)


# ════════════════════════════════════════════════════════════════════════════
# PREDICT: per-pass dashboard
# ════════════════════════════════════════════════════════════════════════════

def plot_pass_dashboard(track, lb, risk, sat_name, pass_idx, cfg, out_path):
    t = np.asarray(track["t_s"]); el = np.asarray(track["el_deg"])
    az = np.asarray(track["az_deg"])
    fig = plt.figure(figsize=(16, 11), constrained_layout=True)
    gs = gridspec.GridSpec(3, 3, figure=fig)
    mask = cfg["prediction"]["elevation_mask_deg"]

    ax = fig.add_subplot(gs[0, :2])
    ax.plot(t, el, lw=1.5, color="tab:blue", label="Elevation")
    ax.axhline(mask, color="r", ls="--", lw=1, label=f"mask {mask:.0f}°")
    above = el >= mask
    if above.any():
        ax.axvspan(t[above][0], t[above][-1], color="orange", alpha=0.12)
    rc = {"NONE":"green","LOW":"gold","MEDIUM":"darkorange","HIGH":"red"}.get(risk["risk_level"],"black")
    ax.set_title(f"{sat_name} — Pass {pass_idx}   [Risk: {risk['risk_level']} | "
                 f"peak dev {risk['peak_deviation_db']:.1f} dB | "
                 f"Pd={risk['pd_at_pfa']*100:.0f}% @ PFA={risk['pfa']:.0e}]",
                 color=rc, fontweight="bold")
    ax.set(ylabel="Elevation (deg)", xlabel="Time (s)")
    ax.legend(loc="upper right", fontsize=8); ax.grid(alpha=0.3)

    axs = fig.add_subplot(gs[0, 2], projection="polar")
    axs.set_theta_zero_location("N"); axs.set_theta_direction(-1)
    r = 90 - el
    axs.plot(np.deg2rad(az), r, lw=2, color="tab:blue")
    axs.plot(np.deg2rad(az[0]), r[0], "go", ms=8)
    axs.plot(np.deg2rad(az[-1]), r[-1], "ro", ms=8)
    pk = int(el.argmax()); axs.plot(np.deg2rad(az[pk]), r[pk], "b*", ms=14)
    axs.set_rmax(90); axs.set_rticks([0,30,60,90]); axs.set_yticklabels(["90°","60°","30°","0°"])
    axs.set_title("Sky path", fontsize=9, pad=14)

    ax = fig.add_subplot(gs[1, 0])
    ax.plot(t, lb["rx_power_dbw"], lw=1.4, color="tab:green")
    ax.axhline(float(lb["baseline_dbw"][0]), color="r", ls="--", lw=1, label="baseline")
    ax.set(xlabel="Time (s)", ylabel="RX power (dBW)", title="Received power")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)

    ax = fig.add_subplot(gs[1, 1])
    ax.plot(t, lb["cn0_dbhz"], lw=1.4, color="tab:purple")
    ax.axhline(cfg["prediction"]["cn0_threshold_dbhz"], color="r", ls="--", lw=1)
    ax.set(xlabel="Time (s)", ylabel="C/N0 (dB-Hz)", title="C/N0")
    ax.grid(alpha=0.3)

    ax = fig.add_subplot(gs[1, 2])
    ax.plot(t, np.asarray(track["doppler_hz"])/1e3, lw=1.4, color="tab:orange")
    ax.axhline(0, color="k", lw=0.5)
    ax.set(xlabel="Time (s)", ylabel="Doppler (kHz)", title="Doppler shift")
    ax.grid(alpha=0.3)

    ax = fig.add_subplot(gs[2, :])
    ax.plot(t, lb["snr_db"], lw=1.4, color="tab:blue", label="SNR")
    ax.plot(t, lb["deviation_db"], lw=1.4, color="tab:red", label="Deviation above baseline")
    ax.axhline(cfg["noise_baseline"]["margin_db"], color="r", ls=":", lw=1,
               label=f"interference threshold ({cfg['noise_baseline']['margin_db']} dB)")
    ax.axhline(0, color="k", lw=0.5)
    ax.set(xlabel="Time (s)", ylabel="dB", title="SNR & power deviation above noise baseline")
    ax.legend(loc="upper right", fontsize=8); ax.grid(alpha=0.3)
    return _save(fig, out_path)


def plot_link_budget(track, lb, sat_cfg, cfg, pass_idx, out_path):
    t = np.asarray(track["t_s"])
    fig, ax = plt.subplots(3, 1, figsize=(10, 9), sharex=True)
    ax[0].plot(t, lb["fspl_db"], label="FSPL", color="tab:blue")
    ax[0].plot(t, lb["atmos_db"], label="Atmospheric", color="tab:red")
    ax[0].set(ylabel="Loss (dB)", title=f"Link budget — Pass {pass_idx}")
    ax[0].legend(); ax[0].grid(alpha=0.3)
    ax[1].plot(t, lb["rx_power_dbw"], color="tab:green", lw=1.5, label="RX power")
    ax[1].axhline(float(lb["baseline_dbw"][0]), color="r", ls="--", label="baseline")
    ax[1].set(ylabel="Power (dBW)"); ax[1].legend(); ax[1].grid(alpha=0.3)
    ax[2].plot(t, lb["cn0_dbhz"], color="tab:purple", lw=1.5, label="C/N0")
    ax[2].axhline(cfg["prediction"]["cn0_threshold_dbhz"], color="r", ls="--")
    ax[2].set(xlabel="Time (s)", ylabel="C/N0 (dB-Hz)"); ax[2].legend(); ax[2].grid(alpha=0.3)
    fig.tight_layout()
    return _save(fig, out_path)


def plot_skypath(track, sat_cfg, pass_idx, out_path):
    from matplotlib.collections import LineCollection
    az = np.asarray(track["az_deg"]); el = np.asarray(track["el_deg"])
    r = 90 - el
    fig = plt.figure(figsize=(7, 7))
    ax = fig.add_subplot(111, projection="polar")
    ax.set_theta_zero_location("N"); ax.set_theta_direction(-1)
    pts = np.array([np.deg2rad(az), r]).T.reshape(-1, 1, 2)
    segs = np.concatenate([pts[:-1], pts[1:]], axis=1)
    lc = LineCollection(segs, cmap="RdYlGn_r", linewidth=2.5); lc.set_array(el)
    ax.add_collection(lc)
    ax.plot(np.deg2rad(az[0]), r[0], "go", ms=10, label="rise", zorder=5)
    ax.plot(np.deg2rad(az[-1]), r[-1], "ro", ms=10, label="set", zorder=5)
    pk = int(el.argmax()); ax.plot(np.deg2rad(az[pk]), r[pk], "b*", ms=15,
                                   label=f"peak {el[pk]:.1f}°", zorder=5)
    ax.set_rmax(90); ax.set_rticks([0,30,60,90]); ax.set_yticklabels(["90°","60°","30°","0°"])
    plt.colorbar(lc, ax=ax, label="Elevation (deg)", orientation="horizontal", pad=0.08)
    ax.set_title(f"Sky path — Pass {pass_idx}", pad=18)
    ax.legend(loc="upper right", bbox_to_anchor=(1.3, 1.1), fontsize=9)
    return _save(fig, out_path)


def plot_doppler(track, sat_cfg, pass_idx, out_path):
    t = np.asarray(track["t_s"])
    fig, ax = plt.subplots(2, 1, figsize=(10, 6), sharex=True)
    ax[0].plot(t, np.asarray(track["doppler_hz"])/1e3, lw=1.5, color="tab:orange")
    ax[0].axhline(0, color="k", lw=0.5)
    ax[0].set(ylabel="Doppler (kHz)", title=f"Doppler — Pass {pass_idx} @ {sat_cfg['frequency_hz']/1e6:.3f} MHz")
    ax[0].grid(alpha=0.3)
    ax[1].plot(t, np.asarray(track["range_rate_mps"])/1e3, lw=1.5, color="tab:purple")
    ax[1].axhline(0, color="k", lw=0.5)
    ax[1].set(xlabel="Time (s)", ylabel="Range rate (km/s)"); ax[1].grid(alpha=0.3)
    fig.tight_layout()
    return _save(fig, out_path)


# ════════════════════════════════════════════════════════════════════════════
# DETECT: spectrogram + detection overlays
# ════════════════════════════════════════════════════════════════════════════

def plot_spectrogram_with_detections(iq, fs, center_freq_hz, detections,
                                     out_path, *, title="", nfft=1024):
    hop = nfft // 2
    n_frames = (len(iq) - nfft) // hop + 1
    win = np.hanning(nfft)
    spec = np.empty((n_frames, nfft))
    for i in range(n_frames):
        seg = iq[i*hop:i*hop+nfft] * win
        spec[i] = np.abs(np.fft.fftshift(np.fft.fft(seg)))**2
    spec_db = 10*np.log10(spec + 1e-20)
    times = np.arange(n_frames)*hop/fs
    freqs = (np.fft.fftshift(np.fft.fftfreq(nfft, 1/fs)) + center_freq_hz)/1e6

    fig, ax = plt.subplots(figsize=(13, 7))
    im = ax.pcolormesh(times, freqs, spec_db.T, shading="auto", cmap="viridis")
    fig.colorbar(im, ax=ax, label="Power (dB)")

    # Color + draw-style per detector type. Different detectors localize
    # different things, so they must be drawn differently:
    #   - time-localized (cfar_energy):    vertical span over the detected time
    #   - freq+time (spectral_anomaly):    a box (the detector gives both)
    #   - freq-only (spectral_kurtosis):   a thin horizontal line at the freq
    #     (SK has NO time localization -- drawing a full-width box is misleading)
    #   - wideband (cyclostationary):      a thin marker, not a full-record box
    style = {
        "cfar_energy":       ("#ff3b3b", "vspan"),
        "spectral_anomaly":  ("#ffd400", "box"),
        "spectral_kurtosis": ("#00e5ff", "hline"),
        "cyclostationary":   ("#ff7bff", "skip"),   # not meaningful on this t-f plane
    }
    t_span = times[-1] - times[0] if len(times) > 1 else 1.0
    seen_labels = set()
    for d in detections:
        det = (d.detector or "").split("(")[0]
        color, mode = style.get(det, ("red", "box"))
        label = det if det not in seen_labels else None
        if mode == "skip":
            continue
        if mode == "vspan":
            ax.axvspan(d.t_start_s, max(d.t_end_s, d.t_start_s + 0.01*t_span),
                       facecolor="none", edgecolor=color, lw=1.8, alpha=0.9,
                       label=label)
            seen_labels.add(det)
        elif mode == "hline" and d.freq_hz is not None:
            ax.axhline(d.freq_hz/1e6, color=color, lw=1.2, alpha=0.7, label=label)
            seen_labels.add(det)
        elif mode == "box" and d.freq_hz is not None:
            fc = d.freq_hz/1e6
            bw = (d.bandwidth_hz or fs*0.04)/1e6
            # clamp the time extent to the actual record
            t0 = max(times[0], d.t_start_s)
            t1 = min(times[-1], d.t_end_s)
            if t1 <= t0:
                t1 = t0 + 0.02*t_span
            ax.add_patch(plt.Rectangle((t0, fc - bw/2), t1 - t0, bw,
                                       fill=False, edgecolor=color, lw=2.2,
                                       label=label))
            seen_labels.add(det)

    if seen_labels:
        ax.legend(loc="upper right", fontsize=8, framealpha=0.85)
    ax.set_xlim(times[0], times[-1]); ax.set_ylim(freqs[0], freqs[-1])
    ax.set(xlabel="Time (s)", ylabel="Frequency (MHz)",
           title=title or f"Spectrogram + detections ({len(detections)} found)")
    return _save(fig, out_path)


def plot_detector_comparison(results: dict, out_path, *, title=""):
    """Side-by-side test statistics + thresholds for all detectors."""
    n = len(results)
    fig, axes = plt.subplots(n, 1, figsize=(12, 3*n))
    if n == 1: axes = [axes]
    for ax, (name, r) in zip(axes, results.items()):
        if r.test_statistic is None:
            ax.text(0.5, 0.5, f"{name}: no statistic", ha="center", transform=ax.transAxes)
            ax.set_axis_off(); continue
        x = r.times_s if r.times_s is not None else np.arange(len(r.test_statistic))
        stat = r.test_statistic
        if "kurtosis" in name or "cyclo" in name:
            ax.plot(x/1e3 if "kurtosis" in name else x, stat, lw=0.8, color="tab:blue")
            xlabel = "Frequency (kHz)" if "kurtosis" in name else "Cyclic freq (Hz)"
        else:
            ax.plot(x, 10*np.log10(stat + 1e-20), lw=0.8, color="tab:blue")
            xlabel = "Time (s)"
        if r.threshold is not None:
            thr = r.threshold
            if "kurtosis" not in name and "cyclo" not in name:
                thr = 10*np.log10(np.asarray(thr) + 1e-20)
            ax.plot(x/1e3 if "kurtosis" in name else x, thr, "r--", lw=1, label="threshold")
        ax.set_title(f"{name}  ({len(r.detections)} detections)", fontsize=10)
        ax.set_xlabel(xlabel); ax.grid(alpha=0.3); ax.legend(fontsize=8)
    fig.suptitle(title or "Detector comparison", fontweight="bold")
    fig.tight_layout()
    return _save(fig, out_path)


def plot_psd(iq, fs, center_freq_hz, out_path, *, title="", nfft=8192,
             baseline_psd=None):
    n_chunks = max(1, len(iq) // nfft)
    win = np.hanning(nfft)
    psd = np.zeros(nfft)
    for k in range(n_chunks):
        seg = iq[k*nfft:(k+1)*nfft]
        if len(seg) < nfft: break
        psd += np.abs(np.fft.fftshift(np.fft.fft(seg*win)))**2
    psd /= n_chunks
    psd_db = 10*np.log10(psd + 1e-20)
    freqs = (np.fft.fftshift(np.fft.fftfreq(nfft, 1/fs)) + center_freq_hz)/1e6
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(freqs, psd_db, lw=0.7, color="tab:blue", label="measured PSD")
    if baseline_psd is not None:
        bdb = 10*np.log10(np.asarray(baseline_psd) + 1e-20)
        ax.plot(freqs, bdb, lw=1, color="tab:orange", ls="--", label="baseline PSD")
        ax.legend()
    ax.set(xlabel="Frequency (MHz)", ylabel="Power (dB)", title=title or "Power Spectral Density")
    ax.grid(alpha=0.3)
    return _save(fig, out_path)
