"""twin/io/common.py
====================
Shared helpers: config loading (with scientific-notation casting), risk
scoring, and terminal color helpers used by both predict and detect entry
points.
"""
from __future__ import annotations
from pathlib import Path
import yaml
import numpy as np


def load_config(path: str) -> dict:
    with open(path) as f:
        cfg = yaml.safe_load(f)
    # YAML sometimes reads 1701.3e6 as a string; cast numeric fields.
    for sat in cfg.get("satellites", []):
        for k in ("frequency_hz", "bandwidth_hz", "eirp_dbw"):
            if k in sat:
                sat[k] = float(sat[k])
    for sect, keys in {
        "noise_baseline": ("floor_dbm", "std_db", "measurement_bw_hz",
                           "margin_db", "rain_rate_mm_hr"),
        "antenna_band": ("f_low_hz", "f_high_hz"),
    }.items():
        if sect in cfg:
            for k in keys:
                if k in cfg[sect]:
                    cfg[sect][k] = float(cfg[sect][k])
    if "simulation" in cfg:
        for k in ("sample_rate_hz", "duration_s"):
            if k in cfg["simulation"]:
                cfg["simulation"][k] = float(cfg["simulation"][k])
    return cfg


# ANSI colors for terminal warning summary
COLORS = {"NONE": "\033[92m", "LOW": "\033[93m",
          "MEDIUM": "\033[33m", "HIGH": "\033[91m", "RESET": "\033[0m"}


def risk_level(deviation_db: float, cfg: dict) -> str:
    th = cfg["detection"]["risk_thresholds"]
    margin = cfg["noise_baseline"]["margin_db"]
    if deviation_db < margin:
        return "NONE"
    if deviation_db < margin + th["low_db"]:
        return "LOW"
    if deviation_db < margin + th["medium_db"]:
        return "MEDIUM"
    return "HIGH"
