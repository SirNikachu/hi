"""twin/detectors/algorithms.py
==============================
The detector algorithms (Module 5, the "Advanced!!" part).

Each detector takes IQ samples (real recorded or synthesized) and returns
detections. They are designed to run on REAL field recordings, not just
synthetic data. All share a common Detection result so they're interchangeable
and comparable.

Implemented (from the project notes -- "research all and decide on the best"):
  1. CFAR energy detector       -- constant false-alarm-rate threshold on power
  2. Spectral anomaly detector  -- per-bin excess over a learned/estimated floor
  3. Spectral kurtosis detector -- finds non-Gaussian (structured) emissions
  4. Cyclostationary detector   -- exploits signal periodicity (modulated carriers)

WHICH IS BEST?  (summary -- see compare_detectors())
  - CFAR energy: best general-purpose, no signal knowledge needed, fast, the
    right default for "anything above the noise floor." Optimal for unknown signals.
  - Spectral kurtosis: best for separating man-made (structured) signals from
    natural noise; excellent at catching narrowband carriers in wideband noise.
  - Cyclostationary: most powerful for known modulation types (detects below
    the noise floor) but computationally heavy and needs a cyclic-frequency guess.
  - Spectral anomaly: best when you have a good baseline PSD to compare against
    (the field case -- you measure the quiet antenna, then watch for change).
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np

from . import theory


@dataclass
class Detection:
    """One detected interference event."""
    t_start_s: float
    t_end_s: float
    freq_hz: float | None       # center frequency of the detected energy
    bandwidth_hz: float | None
    snr_db: float               # estimated SNR of the detection
    power_db: float             # measured power
    confidence: float           # detector-specific score in [0, 1]
    detector: str               # which algorithm fired


@dataclass
class DetectorResult:
    detections: list[Detection] = field(default_factory=list)
    # Diagnostic time/freq series for plotting + analysis:
    times_s: np.ndarray | None = None
    test_statistic: np.ndarray | None = None
    threshold: np.ndarray | None = None
    extra: dict = field(default_factory=dict)


# ── 1. CFAR ENERGY DETECTOR ──────────────────────────────────────────────────

def cfar_energy(iq: np.ndarray, fs: float, *, window_n: int = 1024,
                pfa: float = 1e-3, center_freq_hz: float = 0.0,
                cfar_guard: int = 2, cfar_train: int = 8,
                noise_power: float | None = None) -> DetectorResult:
    """Cell-Averaging CFAR energy detector.

    Splits the recording into windows, computes power per window, and applies
    a CFAR threshold: the threshold for each cell is set from the average power
    of neighboring training cells (excluding guard cells), scaled so the
    false-alarm probability is constant regardless of the noise level. This is
    the workhorse interference detector -- it adapts to a drifting noise floor.

    If noise_power is given (e.g. a measured baseline), a fixed-threshold
    energy detector is used instead of cell-averaging -- the right choice when
    you have a trusted measured noise floor.
    """
    iq = np.asarray(iq)
    n_win = len(iq) // window_n
    if n_win < 1:
        return DetectorResult()
    power = np.array([
        np.mean(np.abs(iq[i*window_n:(i+1)*window_n])**2) for i in range(n_win)
    ])
    times = np.arange(n_win) * window_n / fs

    if noise_power is not None:
        # Fixed-threshold CFAR from a known noise power (measured baseline).
        gamma = theory.threshold_for_pfa(pfa, window_n)
        thr = np.full(n_win, gamma * noise_power)
        ref = np.full(n_win, noise_power)
    else:
        # Cell-averaging CFAR: estimate local noise from training cells.
        thr = np.empty(n_win)
        ref = np.empty(n_win)
        alpha = window_n * (pfa ** (-1.0 / max(1, 2 * cfar_train)) - 1.0)
        for i in range(n_win):
            lo1 = max(0, i - cfar_guard - cfar_train)
            lo2 = max(0, i - cfar_guard)
            hi1 = min(n_win, i + cfar_guard + 1)
            hi2 = min(n_win, i + cfar_guard + cfar_train + 1)
            train = np.concatenate([power[lo1:lo2], power[hi1:hi2]])
            noise_est = np.mean(train) if len(train) else power[i]
            ref[i] = noise_est
            thr[i] = noise_est * (1.0 + alpha / window_n)

    # Detections where power exceeds threshold
    hits = power > thr
    dets = _runs_to_detections(hits, times, power, ref, window_n, fs,
                               center_freq_hz, "cfar_energy")
    return DetectorResult(detections=dets, times_s=times,
                          test_statistic=power, threshold=thr,
                          extra={"noise_ref": ref})


# ── 2. SPECTRAL ANOMALY DETECTOR ─────────────────────────────────────────────

def spectral_anomaly(iq: np.ndarray, fs: float, *, nfft: int = 1024,
                     hop: int | None = None, baseline_psd: np.ndarray | None = None,
                     center_freq_hz: float = 0.0, threshold_db: float = 6.0,
                     pfa: float | None = None) -> DetectorResult:
    """Per-frequency-bin anomaly detector.

    Computes a spectrogram, then for each frequency bin compares the live power
    to a baseline. If baseline_psd is provided (a measured quiet-sky PSD), the
    excess over baseline is tested -- this is the field workflow. Otherwise the
    baseline is estimated as the median across time per bin (robust to
    intermittent signals).

    A bin-time cell is flagged when it exceeds baseline by threshold_db (or, if
    pfa is given, by the CFAR threshold derived from the per-bin noise).
    """
    iq = np.asarray(iq)
    hop = hop or nfft // 2
    n_frames = (len(iq) - nfft) // hop + 1
    if n_frames < 1:
        return DetectorResult()
    win = np.hanning(nfft)
    spec = np.empty((n_frames, nfft))
    for i in range(n_frames):
        seg = iq[i*hop:i*hop+nfft] * win
        spec[i] = np.abs(np.fft.fftshift(np.fft.fft(seg)))**2
    spec_db = 10 * np.log10(spec + 1e-20)
    times = np.arange(n_frames) * hop / fs
    freqs = np.fft.fftshift(np.fft.fftfreq(nfft, 1/fs)) + center_freq_hz

    if baseline_psd is not None:
        base_db = 10 * np.log10(np.asarray(baseline_psd) + 1e-20)
    else:
        # No external baseline: estimate the noise floor as the across-frequency
        # median of the time-averaged spectrum. A single always-on carrier does
        # NOT dominate this (unlike a per-bin temporal median, where the carrier
        # becomes its own floor and hides). Robust when there is no quiet-sky ref.
        mean_spec_db = np.mean(spec_db, axis=0)
        base_db = np.full(nfft, float(np.median(mean_spec_db)))

    excess = spec_db - base_db[None, :]              # dB above baseline

    # Notch the DC bin (+/- a few bins): SDRs always have a DC spike/LO leakage
    # there that is an instrument artifact, not interference.
    dc_bin = nfft // 2
    notch = 3
    excess[:, dc_bin-notch:dc_bin+notch+1] = 0.0

    if pfa is not None:
        sigma = np.std(spec_db - base_db[None, :], axis=0)
        thr_db = base_db + theory.Qinv(pfa) * sigma
        flagged = spec_db > thr_db[None, :]
        flagged[:, dc_bin-notch:dc_bin+notch+1] = False
    else:
        flagged = excess > threshold_db

    # A bin is a real signal only if it fires PERSISTENTLY, not in occasional
    # noise frames. Require a bin to be hot in at least `persistence` of frames
    # to count as carrying a signal -- this rejects the scattered single-frame
    # noise hits that would otherwise merge into one giant band.
    persistence = 0.10
    frac_hot = flagged.mean(axis=0)                 # fraction of time each bin is hot
    signal_bins = frac_hot >= persistence
    signal_bins[dc_bin-notch:dc_bin+notch+1] = False

    # Minimum detection duration: a genuine emission persists for more than a
    # couple of FFT frames. Reject detections shorter than min_dwell_s so brief
    # noise spikes and modulation splatter don't register as events.
    min_dwell_s = max(3 * hop / fs, 0.02)

    dets = []
    for (klo, khi) in _bool_runs(signal_bins):
        # Frequency bounds = the contiguous persistent-hot bins (tight).
        kpk = klo + int(np.argmax(excess[:, klo:khi].max(axis=0)))
        # Time bounds = frames where the PEAK bin (and its immediate neighbors)
        # are hot, so the box brackets when this specific signal is on.
        k0 = max(0, kpk - 1); k1 = min(nfft, kpk + 2)
        frame_hot = flagged[:, k0:k1].any(axis=1)
        truns = _bool_runs(frame_hot)
        if not truns:
            continue
        # largest contiguous on-interval for this signal
        ta, tb = max(truns, key=lambda r: r[1] - r[0])
        t_start = float(times[ta]); t_end = float(times[min(tb, n_frames-1)])
        if (t_end - t_start) < min_dwell_s:
            continue                                # too brief -> not a real event
        peak_excess = float(excess[:, klo:khi].max())
        dets.append(Detection(
            t_start_s=t_start, t_end_s=t_end,
            freq_hz=float(freqs[kpk]),
            bandwidth_hz=float(max(1, khi - klo) * fs / nfft),
            snr_db=peak_excess,
            power_db=float(base_db[kpk] + peak_excess),
            confidence=float(min(1.0, peak_excess / 20.0)),
            detector="spectral_anomaly"))
    return DetectorResult(detections=dets, times_s=times,
                          test_statistic=excess.max(axis=1),
                          threshold=np.full(n_frames, threshold_db),
                          extra={"spectrogram_db": spec_db, "freqs_hz": freqs,
                                 "baseline_db": base_db})


# ── 3. SPECTRAL KURTOSIS DETECTOR ────────────────────────────────────────────

def spectral_kurtosis(iq: np.ndarray, fs: float, *, nfft: int = 1024,
                      hop: int | None = None, center_freq_hz: float = 0.0,
                      sk_threshold: float = 2.0) -> DetectorResult:
    """Spectral Kurtosis (SK) detector.

    For each frequency bin, SK measures how 'Gaussian' the power fluctuations
    are over time. Pure thermal noise is Gaussian and has SK ~= 1. Man-made
    signals (carriers, pulses, modulation) are non-Gaussian and push SK away
    from 1. SK is powerful because it separates STRUCTURED emissions from
    natural noise even when their average powers are similar -- it keys on the
    statistics, not the level.

        SK[k] = <|X[k]|^4> / <|X[k]|^2>^2  - 2     (estimator, ~0 for noise here)

    Bins whose |SK| exceeds sk_threshold (after normalization) are flagged.
    """
    iq = np.asarray(iq)
    hop = hop or nfft // 2
    n_frames = (len(iq) - nfft) // hop + 1
    if n_frames < 8:
        return DetectorResult()
    win = np.hanning(nfft)
    psd = np.empty((n_frames, nfft))
    for i in range(n_frames):
        seg = iq[i*hop:i*hop+nfft] * win
        psd[i] = np.abs(np.fft.fftshift(np.fft.fft(seg)))**2
    times = np.arange(n_frames) * hop / fs
    freqs = np.fft.fftshift(np.fft.fftfreq(nfft, 1/fs)) + center_freq_hz

    # Spectral kurtosis estimator per bin
    s2 = np.mean(psd, axis=0)
    s4 = np.mean(psd**2, axis=0)
    M = n_frames
    sk = ((M + 1) / (M - 1)) * (s4 / (s2**2) - 1.0)   # ~1 for complex Gaussian
    # Normalize: Gaussian SK ~ 1; deviation magnitude is the statistic
    sk_dev = np.abs(sk - 1.0)

    # Power gate: a real emission is BOTH non-Gaussian AND carries elevated
    # power. Pure-noise bins occasionally show a high SK estimate from finite-
    # sample fluctuation (worst at band edges) -- gate those out by requiring
    # the bin's mean power to exceed the noise floor by a few dB. This removes
    # the spurious edge-of-band detections.
    mean_pow_db = 10 * np.log10(s2 + 1e-20)
    floor_db = float(np.median(mean_pow_db))
    power_gate = mean_pow_db > (floor_db + 3.0)        # >3 dB above floor
    hot_bins = (sk_dev > sk_threshold) & power_gate

    # Merge adjacent hot bins into single detections (one per signal, not per bin)
    dets = []
    for (a, b) in _bool_runs(hot_bins):
        bin_slice = slice(a, b)
        k_peak = a + int(np.argmax(sk_dev[bin_slice]))
        bin_pow_db = 10*np.log10(psd[:, k_peak] + 1e-20)
        f_lo, f_hi = float(freqs[a]), float(freqs[min(b, len(freqs)-1)])
        dets.append(Detection(
            t_start_s=float(times[0]), t_end_s=float(times[-1]),
            freq_hz=float(freqs[k_peak]), bandwidth_hz=abs(f_hi - f_lo) or float(fs/nfft),
            snr_db=float(np.max(bin_pow_db) - np.median(bin_pow_db)),
            power_db=float(np.max(bin_pow_db)),
            confidence=float(min(1.0, sk_dev[k_peak] / 10.0)),
            detector="spectral_kurtosis"))
    return DetectorResult(detections=dets, times_s=freqs,  # x-axis is freq here
                          test_statistic=sk, threshold=np.full(nfft, 1+sk_threshold),
                          extra={"sk": sk, "freqs_hz": freqs})


# ── 4. CYCLOSTATIONARY DETECTOR ──────────────────────────────────────────────

def cyclostationary(iq: np.ndarray, fs: float, *, center_freq_hz: float = 0.0,
                    alphas_hz=None, nfft: int = 512,
                    detection_threshold: float = 4.0) -> DetectorResult:
    """Cyclostationary feature detector (single-alpha cyclic autocorrelation).

    Modulated signals exhibit periodicity (in their symbol rate, carrier, etc.)
    that pure noise does not. This detector estimates the cyclic autocorrelation
    at candidate cyclic frequencies (alphas) and flags strong cyclic features.
    It can detect signals BELOW the noise floor because noise has no cyclic
    structure -- but it needs candidate alphas and is computationally heavier.

    alphas_hz: candidate cyclic frequencies to test (default: scan a small grid).
    """
    iq = np.asarray(iq)
    N = len(iq)
    if N < nfft * 4:
        return DetectorResult()
    if alphas_hz is None:
        # default: scan a coarse grid of cyclic frequencies
        alphas_hz = np.linspace(fs/100, fs/4, 40)
    alphas_hz = np.asarray(alphas_hz, dtype=float)

    # Cyclic autocorrelation magnitude at lag 0 for each alpha:
    #   R_x^alpha = (1/N) sum_n x[n] x*[n] e^{-j 2 pi alpha n / fs}
    # For a signal with cyclic freq alpha this peaks; for noise it stays low.
    n = np.arange(N)
    x2 = iq * np.conj(iq)            # instantaneous power sequence
    caf = np.empty(len(alphas_hz))
    for i, a in enumerate(alphas_hz):
        caf[i] = np.abs(np.mean(x2 * np.exp(-1j * 2 * np.pi * a * n / fs)))
    # Normalize by the zero-cyclic-frequency value (total power)
    caf_norm = caf / (np.mean(np.abs(x2)) + 1e-20)
    # Robust threshold: median + k*MAD
    med = np.median(caf_norm)
    mad = np.median(np.abs(caf_norm - med)) + 1e-20
    score = (caf_norm - med) / (1.4826 * mad)
    hot = score > detection_threshold

    dets = []
    for i in np.where(hot)[0]:
        dets.append(Detection(
            t_start_s=0.0, t_end_s=float(N / fs),
            freq_hz=center_freq_hz, bandwidth_hz=None,
            snr_db=float(10*np.log10(caf_norm[i] + 1e-20)),
            power_db=float(10*np.log10(caf_norm[i] + 1e-20)),
            confidence=float(min(1.0, score[i] / 20.0)),
            detector=f"cyclostationary(alpha={alphas_hz[i]:.0f}Hz)"))
    return DetectorResult(detections=dets, times_s=alphas_hz,
                          test_statistic=score,
                          threshold=np.full(len(alphas_hz), detection_threshold),
                          extra={"alphas_hz": alphas_hz, "caf_norm": caf_norm})


# ── Detector comparison ──────────────────────────────────────────────────────

def compare_detectors(iq: np.ndarray, fs: float, center_freq_hz: float = 0.0,
                      noise_power: float | None = None,
                      baseline_psd: np.ndarray | None = None) -> dict:
    """Run all detectors on the same IQ and return their results side by side,
    so you can see which fires on a given recording. Returns
    {detector_name: DetectorResult}."""
    out = {}
    out["cfar_energy"] = cfar_energy(iq, fs, center_freq_hz=center_freq_hz,
                                     noise_power=noise_power)
    out["spectral_anomaly"] = spectral_anomaly(iq, fs, center_freq_hz=center_freq_hz,
                                               baseline_psd=baseline_psd)
    out["spectral_kurtosis"] = spectral_kurtosis(iq, fs, center_freq_hz=center_freq_hz)
    out["cyclostationary"] = cyclostationary(iq, fs, center_freq_hz=center_freq_hz)
    return out


# ── helpers ──────────────────────────────────────────────────────────────────

def _bool_runs(mask):
    """Return list of (start, end) index pairs for runs of True."""
    mask = np.asarray(mask)
    if not mask.any():
        return []
    d = np.diff(mask.astype(int))
    starts = list(np.where(d == 1)[0] + 1)
    ends = list(np.where(d == -1)[0] + 1)
    if mask[0]: starts = [0] + starts
    if mask[-1]: ends = ends + [len(mask)]
    return list(zip(starts, ends))


def _runs_to_detections(hits, times, power, ref, window_n, fs,
                        center_freq_hz, name, merge_gap_s=0.05):
    """Convert a boolean hit mask into detections, merging hits separated by
    less than merge_gap_s so a burst of pulses reads as one event interval
    rather than hundreds of single-window hits."""
    runs = _bool_runs(hits)
    if not runs:
        return []
    # Merge runs separated by a small time gap
    dt = (times[1] - times[0]) if len(times) > 1 else window_n / fs
    gap_windows = max(1, int(merge_gap_s / dt))
    merged = [list(runs[0])]
    for a, b in runs[1:]:
        if a - merged[-1][1] <= gap_windows:
            merged[-1][1] = b
        else:
            merged.append([a, b])
    dets = []
    for a, b in merged:
        seg = power[a:b]
        peak = float(np.max(seg))
        noise = float(np.mean(ref[a:b])) if ref is not None else float(np.median(power))
        snr = 10 * np.log10(peak / (noise + 1e-20))
        dets.append(Detection(
            t_start_s=float(times[a]),
            t_end_s=float(times[min(b, len(times)-1)]),
            freq_hz=center_freq_hz, bandwidth_hz=float(fs),
            snr_db=snr, power_db=float(10*np.log10(peak + 1e-20)),
            confidence=float(min(1.0, snr / 20.0)), detector=name))
    return dets
