"""twin/detectors/predictive.py
==============================
Prediction-side interference detectors (the ones that work from the link
budget and pass geometry, not from recorded IQ). These complement the
signal-processing detectors in algorithms.py.

From the project notes:
  - Rule-based overlap model   -- flags when a satellite is above the horizon
                                  AND its band overlaps the antenna's band.
  - Link-budget-based detection -- flags when predicted received power exceeds
                                  the noise baseline + margin (the core method).
  - Hidden Markov Model         -- models the interference state (clean/degraded/
                                  interfered) as a Markov chain over the pass,
                                  smoothing noisy per-sample decisions into
                                  coherent interference intervals.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np


@dataclass
class InterferenceInterval:
    t_start_s: float
    t_end_s: float
    state: str                 # 'clean' | 'degraded' | 'interfered'
    peak_deviation_db: float
    mean_deviation_db: float


# ── Rule-based overlap ───────────────────────────────────────────────────────

def rule_based_overlap(track: dict, sat_cfg: dict, antenna_band_hz: tuple,
                       elevation_mask_deg: float = 10.0) -> dict:
    """Flag interference when (a) the satellite is above the elevation mask and
    (b) its emission band overlaps the antenna's receive band. The simplest,
    most robust predictor -- if both are true, the satellite is a candidate
    interferer regardless of signal level."""
    el = np.asarray(track["el_deg"], float)
    t = np.asarray(track["t_s"], float)
    f_lo = sat_cfg["frequency_hz"] - sat_cfg["bandwidth_hz"] / 2
    f_hi = sat_cfg["frequency_hz"] + sat_cfg["bandwidth_hz"] / 2
    a_lo, a_hi = antenna_band_hz
    band_overlap = (f_lo <= a_hi) and (f_hi >= a_lo)
    above = el >= elevation_mask_deg
    flagged = above & band_overlap
    intervals = _mask_to_intervals(flagged, t, np.zeros_like(el), "interfered")
    return {
        "band_overlap": band_overlap,
        "overlap_hz": max(0.0, min(f_hi, a_hi) - max(f_lo, a_lo)) if band_overlap else 0.0,
        "flagged_intervals": intervals,
        "flagged_seconds": float(np.sum(flagged) * (t[1]-t[0] if len(t) > 1 else 1)),
    }


# ── Link-budget-based detection ──────────────────────────────────────────────

def link_budget_detection(track: dict, lb: dict, noise_cfg: dict,
                          risk_thresholds: dict) -> dict:
    """Flag interference from the predicted power deviation above baseline.
    This is the project's core method: 'baseline noise level + anything over
    this causes interference.' Returns per-second states and intervals."""
    t = np.asarray(track["t_s"], float)
    dev = np.asarray(lb["deviation_db"], float)
    margin = noise_cfg["margin_db"]
    low = margin + risk_thresholds["low_db"]
    med = margin + risk_thresholds["medium_db"]

    state = np.full(len(t), "clean", dtype=object)
    state[dev >= margin] = "degraded"
    state[dev >= med] = "interfered"

    interfered_mask = dev >= margin
    intervals = _mask_to_intervals(interfered_mask, t, dev, "interfered")
    return {
        "peak_deviation_db": float(np.max(dev)),
        "interfered_seconds": float(np.sum(interfered_mask) * (t[1]-t[0] if len(t) > 1 else 1)),
        "states": state,
        "intervals": intervals,
    }


# ── Hidden Markov Model ──────────────────────────────────────────────────────

def hmm_interference(track: dict, lb: dict, noise_cfg: dict, *,
                     n_states: int = 3,
                     trans_stay: float = 0.95) -> dict:
    """Model interference as a hidden Markov chain over the pass and decode the
    most likely state sequence with the Viterbi algorithm.

    States: 0=clean, 1=degraded, 2=interfered, with Gaussian emission models on
    the power-deviation-above-baseline signal. The Markov prior enforces
    temporal coherence -- isolated noisy spikes don't flip the state, but a
    sustained rise does. This converts the noisy per-sample deviation into
    clean interference intervals (better than thresholding alone).
    """
    dev = np.asarray(lb["deviation_db"], float)
    t = np.asarray(track["t_s"], float)
    margin = noise_cfg["margin_db"]
    n = len(dev)
    if n < 2:
        return {"states": np.array(["clean"]*n, dtype=object), "intervals": []}

    # Emission model: state means at {below margin, at margin, well above}
    means = np.array([margin - 8.0, margin + 2.0, margin + 14.0])[:n_states]
    sigma = 5.0
    # Log emission probabilities
    log_emit = -0.5 * ((dev[:, None] - means[None, :]) / sigma) ** 2

    # Transition matrix: sticky (stay with prob trans_stay)
    off = (1 - trans_stay) / (n_states - 1)
    log_trans = np.log(np.full((n_states, n_states), off) +
                       np.eye(n_states) * (trans_stay - off))
    log_pi = np.log(np.array([0.8, 0.15, 0.05])[:n_states])

    # Viterbi
    delta = np.empty((n, n_states))
    psi = np.zeros((n, n_states), dtype=int)
    delta[0] = log_pi + log_emit[0]
    for i in range(1, n):
        for s in range(n_states):
            trans_scores = delta[i-1] + log_trans[:, s]
            psi[i, s] = np.argmax(trans_scores)
            delta[i, s] = np.max(trans_scores) + log_emit[i, s]
    path = np.empty(n, dtype=int)
    path[-1] = np.argmax(delta[-1])
    for i in range(n-2, -1, -1):
        path[i] = psi[i+1, path[i+1]]

    names = np.array(["clean", "degraded", "interfered"])[:n_states]
    state_seq = names[path]
    # intervals where state >= degraded
    interfered_mask = path >= 1
    intervals = _mask_to_intervals(interfered_mask, t, dev, None, state_path=path, names=names)
    return {
        "states": state_seq,
        "intervals": intervals,
        "path": path,
        "fraction_interfered": float(np.mean(path >= 1)),
    }


# ── helpers ──────────────────────────────────────────────────────────────────

def _mask_to_intervals(mask, t, dev, state_label, state_path=None, names=None):
    mask = np.asarray(mask)
    if not mask.any():
        return []
    d = np.diff(mask.astype(int))
    starts = list(np.where(d == 1)[0] + 1)
    ends = list(np.where(d == -1)[0] + 1)
    if mask[0]: starts = [0] + starts
    if mask[-1]: ends = ends + [len(mask)]
    out = []
    for a, b in zip(starts, ends):
        seg = dev[a:b]
        if state_path is not None and names is not None:
            # most severe state in the interval
            lbl = names[int(np.max(state_path[a:b]))]
        else:
            lbl = state_label
        out.append(InterferenceInterval(
            t_start_s=float(t[a]), t_end_s=float(t[min(b, len(t)-1)]),
            state=lbl, peak_deviation_db=float(np.max(seg)) if len(seg) else 0.0,
            mean_deviation_db=float(np.mean(seg)) if len(seg) else 0.0))
    return out
