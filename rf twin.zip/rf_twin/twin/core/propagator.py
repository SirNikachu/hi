"""core/propagator.py
TLE fetching, SGP4 propagation, pass finding, and per-second geometry.

KEY FIX: SGP4 returns positions in TEME (True Equator Mean Equinox), an
inertial frame. Ground-site coordinates are ECEF (Earth-Centered Earth-Fixed),
which rotates with the Earth. We must convert TEME -> ECEF using the Greenwich
Sidereal Time (GMST) rotation before computing az/el. Skipping this conversion
was the bug causing all elevations to be wrong.
"""
from __future__ import annotations
import ssl, math, urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path
import numpy as np

try:
    from sgp4.api import Satrec
    _SGP4_OK = True
except ImportError:
    _SGP4_OK = False

C_LIGHT = 299_792_458.0
CELESTRAK_URL = "https://celestrak.org/NORAD/elements/gp.php?CATNR={nid}&FORMAT=TLE"
_CACHE_DIR = Path(__file__).parent.parent / "cache" / "tle"


# ── TLE ──────────────────────────────────────────────────────────────────────

@dataclass
class TLE:
    name: str
    line1: str
    line2: str

    @property
    def epoch_utc(self) -> datetime:
        yy = int(self.line1[18:20])
        year = 2000 + yy if yy < 57 else 1900 + yy
        doy = float(self.line1[20:32])
        return datetime(year, 1, 1, tzinfo=timezone.utc) + timedelta(days=doy-1)

    @property
    def age_days(self) -> float:
        return (datetime.now(timezone.utc) - self.epoch_utc).total_seconds() / 86400


def _parse_tle(text: str) -> TLE | None:
    parts = []
    for line in text.splitlines():
        for chunk in line.split(","):
            c = chunk.strip()
            if c:
                parts.append(c)
    name, l1, l2 = None, None, None
    for p in parts:
        if p.startswith("1 ") and len(p) >= 69 and l1 is None:
            l1 = p
        elif p.startswith("2 ") and len(p) >= 69 and l2 is None:
            l2 = p
        elif name is None and not p.startswith(("1 ", "2 ")):
            name = p
    return TLE(name or "UNKNOWN", l1, l2) if l1 and l2 else None


def get_tle(norad_id: int, max_age_hours: float = 24.0,
            force: bool = False) -> TLE:
    _CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache = _CACHE_DIR / f"{norad_id}.tle"
    cached = _parse_tle(cache.read_text()) if cache.exists() else None
    age_h = (datetime.now().timestamp() - cache.stat().st_mtime) / 3600 \
        if cache.exists() else 999
    if not force and cached and age_h <= max_age_hours:
        print(f"  [tle] {cached.name} from cache "
              f"(age {age_h:.1f}h, epoch age {cached.age_days:.1f}d)")
        return cached
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(
            CELESTRAK_URL.format(nid=norad_id),
            headers={"User-Agent": "interference-predictor/1.0"})
        with urllib.request.urlopen(req, timeout=10, context=ctx) as r:
            body = r.read().decode("utf-8", errors="replace")
        tle = _parse_tle(body)
        if tle is None:
            raise RuntimeError("No TLE in response")
        cache.write_text(f"{tle.name}\n{tle.line1}\n{tle.line2}\n")
        print(f"  [tle] {tle.name} fetched fresh (epoch age {tle.age_days:.1f}d)")
        return tle
    except Exception as e:
        if cached:
            print(f"  [tle] fetch failed ({e}); "
                  f"using stale cache (epoch age {cached.age_days:.1f}d)")
            return cached
        raise RuntimeError(f"Cannot get TLE for {norad_id}: {e}")


# ── Coordinate transforms ─────────────────────────────────────────────────────

def _gmst(jd_ut1: float) -> float:
    """Greenwich Mean Sidereal Time in radians from Julian date (UT1)."""
    T = (jd_ut1 - 2451545.0) / 36525.0
    gmst_sec = (67310.54841
                + (876600 * 3600 + 8640184.812866) * T
                + 0.093104 * T**2
                - 6.2e-6 * T**3)
    return math.radians(gmst_sec / 240.0) % (2 * math.pi)


def _teme_to_ecef(r_teme: np.ndarray, v_teme: np.ndarray,
                  jd: float) -> tuple[np.ndarray, np.ndarray]:
    """Rotate TEME position/velocity to ECEF using GMST.
    This is the critical step SGP4 outputs need before az/el can be computed."""
    gst = _gmst(jd)
    cos_g, sin_g = math.cos(gst), math.sin(gst)
    # Rotation matrix: ECEF = Rz(-GMST) * TEME
    R = np.array([[ cos_g, sin_g, 0],
                  [-sin_g, cos_g, 0],
                  [     0,     0, 1]])
    r_ecef = R @ r_teme
    # Velocity also needs the Earth-rotation correction
    omega = 7.2921150e-5  # Earth rotation rate rad/s
    v_ecef = R @ v_teme - np.cross(np.array([0, 0, omega]), r_ecef)
    return r_ecef, v_ecef


def _site_ecef(lat_deg: float, lon_deg: float, alt_m: float) -> np.ndarray:
    """Geodetic -> ECEF (WGS84)."""
    a = 6378137.0
    e2 = 0.00669437999014
    lat = math.radians(lat_deg)
    lon = math.radians(lon_deg)
    N = a / math.sqrt(1 - e2 * math.sin(lat)**2)
    return np.array([
        (N + alt_m) * math.cos(lat) * math.cos(lon),
        (N + alt_m) * math.cos(lat) * math.sin(lon),
        (N * (1 - e2) + alt_m) * math.sin(lat),
    ])


def _azel_from_ecef(sat_ecef: np.ndarray, sat_vel_ecef: np.ndarray,
                    site: np.ndarray,
                    lat_deg: float, lon_deg: float
                    ) -> tuple[float, float, float, float]:
    """Az/El/range/range-rate from ECEF satellite + ECEF site."""
    lat = math.radians(lat_deg)
    lon = math.radians(lon_deg)
    diff = sat_ecef - site
    rng = float(np.linalg.norm(diff))
    # ENU unit vectors at site
    e_hat = np.array([-math.sin(lon), math.cos(lon), 0.0])
    n_hat = np.array([-math.sin(lat)*math.cos(lon),
                      -math.sin(lat)*math.sin(lon),
                       math.cos(lat)])
    u_hat = np.array([ math.cos(lat)*math.cos(lon),
                       math.cos(lat)*math.sin(lon),
                       math.sin(lat)])
    e_c = float(np.dot(diff, e_hat))
    n_c = float(np.dot(diff, n_hat))
    u_c = float(np.dot(diff, u_hat))
    el = math.degrees(math.asin(u_c / rng))
    az = math.degrees(math.atan2(e_c, n_c)) % 360.0
    rrate = float(np.dot(sat_vel_ecef, diff / rng))
    return az, el, rng, rrate


# ── Pass finding ──────────────────────────────────────────────────────────────

@dataclass
class PassInfo:
    pass_index: int
    rise_utc: datetime
    set_utc: datetime
    culmination_utc: datetime
    max_elevation_deg: float
    duration_s: float


@dataclass
class PropagatedPass:
    info: PassInfo
    track: dict


def _jd_from_datetime(dt: datetime) -> float:
    """Full Julian date (float) from UTC datetime."""
    return 2440587.5 + dt.timestamp() / 86400.0


def propagate_passes(tle: TLE, site_lat: float, site_lon: float,
                     site_alt: float, start: datetime, end: datetime,
                     mask_deg: float = 10.0,
                     freq_hz: float = 1.5e9) -> list[PropagatedPass]:
    if not _SGP4_OK:
        raise RuntimeError("pip install sgp4")
    sat = Satrec.twoline2rv(tle.line1, tle.line2)
    site = _site_ecef(site_lat, site_lon, site_alt)

    in_pass = False
    pass_segments: list[list] = []
    current: list = []

    t = start
    dt = timedelta(seconds=1)
    while t <= end:
        jd_full = _jd_from_datetime(t)
        jd_i = math.floor(jd_full) + 0.5
        jd_fr = jd_full - jd_i
        err, r_km, v_km = sat.sgp4(jd_i, jd_fr)
        if err == 0:
            # Convert from TEME (km) to ECEF (m)
            r_teme = np.array(r_km) * 1000.0
            v_teme = np.array(v_km) * 1000.0
            r_ecef, v_ecef = _teme_to_ecef(r_teme, v_teme, jd_full)
            az, el, rng, rrate = _azel_from_ecef(
                r_ecef, v_ecef, site, site_lat, site_lon)
            if el >= mask_deg:
                if not in_pass:
                    in_pass = True
                    current = []
                current.append((t, az, el, rng, rrate))
            else:
                if in_pass:
                    in_pass = False
                    if current:
                        pass_segments.append(current)
                    current = []
        t += dt

    if in_pass and current:
        pass_segments.append(current)

    result = []
    for idx, pts in enumerate(pass_segments):
        t0, tN = pts[0][0], pts[-1][0]
        pk_i = max(range(len(pts)), key=lambda i: pts[i][2])
        info = PassInfo(
            pass_index=idx,
            rise_utc=t0,
            set_utc=tN,
            culmination_utc=pts[pk_i][0],
            max_elevation_deg=pts[pk_i][2],
            duration_s=(tN - t0).total_seconds(),
        )
        n = len(pts)
        track = {
            "time_utc":       [p[0] for p in pts],
            "t_s":            np.arange(n, dtype=float),
            "az_deg":         np.array([p[1] for p in pts]),
            "el_deg":         np.array([p[2] for p in pts]),
            "range_m":        np.array([p[3] for p in pts]),
            "range_rate_mps": np.array([p[4] for p in pts]),
            "doppler_hz":     np.array([-(p[4]/C_LIGHT)*freq_hz for p in pts]),
        }
        result.append(PropagatedPass(info, track))
    return result
