"""
Two plot groups:
PREDICT plots -- pass geometry, link budget, Doppler, sky path, the analytic
ROC family, detection-performance prediction, the operational forecast ROC,
and the interference timeline.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

from twin.detectors import theory


def _save(fig, path, dpi=120):
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    return Path(path)


# ════════════════════════════════════════════════════════════════════════════
# ROC FAMILY  (the curve the project actually wanted)
# ════════════════════════════════════════════════════════════════════════════

def plot_roc_family(snr_list, n_samples, out_path, *, operating_pfa=None,
                    title_extra="", log_x=True, monte_carlo_snr=None):
    """Family of ROC curves at multiple SNRs -- the classic detection plot.
    Optionally overlays a Monte Carlo validation at one SNR and marks the
    operator's chosen PFA operating line."""
    fig, ax = plt.subplots(figsize=(9, 7))
    colors = plt.cm.viridis(np.linspace(0, 0.9, len(snr_list)))
    for snr, c in zip(snr_list, colors):
        pfa, pd = theory.roc_curve(snr, n_samples)
        a = theory.auc(pfa, pd)
        ax.plot(pfa, pd, lw=2, color=c, label=f"SNR={snr:+.0f} dB (AUC={a:.3f})")

    if monte_carlo_snr is not None:
        pfa_mc, pd_emp, pd_ana = theory.monte_carlo_roc(monte_carlo_snr, n_samples,
                                                        n_trials=8000)
        ax.plot(pfa_mc, pd_emp, "o", ms=4, color="red", alpha=0.6,
                label=f"Monte Carlo (SNR={monte_carlo_snr:+.0f} dB)")

    if operating_pfa is not None:
        ax.axvline(operating_pfa, color="crimson", ls="--", lw=1.2,
                   label=f"Operating PFA = {operating_pfa:.0e}")

    if log_x:
        ax.set_xscale("log"); ax.set_xlim(1e-6, 1)
    else:
        ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.02)
    ax.set_xlabel("Probability of False Alarm (PFA)")
    ax.set_ylabel("Probability of Detection (Pd)")
    ax.set_title(f"ROC Family — Energy Detector (N={n_samples} samples){title_extra}")
    ax.grid(alpha=0.3, which="both"); ax.legend(loc="lower right", fontsize=8)
    return _save(fig, out_path)


def plot_detection_performance(snr_list, n_list, out_path, *, pfa=1e-3):
    """Detection-performance prediction: Pd vs SNR for several integration
    lengths, plus min-detectable-SNR markers. Answers 'how weak a signal can
    I catch, and how long must I integrate?'"""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
    snr_grid = np.linspace(-15, 15, 200)
    colors = plt.cm.plasma(np.linspace(0, 0.85, len(n_list)))
    for n, c in zip(n_list, colors):
        pd = [theory.pd_for_pfa(pfa, s, n) for s in snr_grid]
        ax1.plot(snr_grid, pd, lw=2, color=c, label=f"N={n}")
        smin = theory.min_detectable_snr_db(pfa, 0.9, n)
        ax1.axvline(smin, color=c, ls=":", lw=1, alpha=0.6)
    ax1.set(xlabel="Per-window SNR (dB)", ylabel="Probability of Detection",
            title=f"Pd vs SNR  (PFA={pfa:.0e}, dotted = min SNR for Pd=0.9)")
    ax1.grid(alpha=0.3); ax1.legend(fontsize=8); ax1.set_ylim(0, 1.02)

    # Min detectable SNR vs N
    n_grid = np.logspace(1, 5, 60).astype(int)
    smin_grid = [theory.min_detectable_snr_db(pfa, 0.9, n) for n in n_grid]
    ax2.semilogx(n_grid, smin_grid, lw=2, color="tab:blue")
    ax2.set(xlabel="Integration samples N", ylabel="Min detectable SNR (dB)",
            title=f"Sensitivity vs integration  (PFA={pfa:.0e}, Pd=0.9)")
    ax2.grid(alpha=0.3, which="both")
    return _save(fig, out_path)


# ════════════════════════════════════════════════════════════════════════════
# PREDICT: per-pass dashboard
# ════════════════════════════════════════════════════════════════════════════

def plot_pass_dashboard(track, lb, risk, sat_name, pass_idx, cfg, out_path):
    t = np.asarray(track["t_s"]); el = np.asarray(track["el_deg"])
    az = np.asarray(track["az_deg"])
    fig = plt.figure(figsize=(16, 11), constrained_layout=True)
    gs = gridspec.GridSpec(3, 3, figure=fig)
    mask = cfg["prediction"]["elevation_mask_deg"]

    ax = fig.add_subplot(gs[0, :2])
    ax.plot(t, el, lw=1.5, color="tab:blue", label="Elevation")
    ax.axhline(mask, color="r", ls="--", lw=1, label=f"mask {mask:.0f}°")
    above = el >= mask
    if above.any():
        ax.axvspan(t[above][0], t[above][-1], color="orange", alpha=0.12)
    rc = {"NONE":"green","LOW":"gold","MEDIUM":"darkorange","HIGH":"red"}.get(risk["risk_level"],"black")
    ax.set_title(f"{sat_name} — Pass {pass_idx}   [Risk: {risk['risk_level']} | "
                 f"peak dev {risk['peak_deviation_db']:.1f} dB | "
                 f"Pd={risk['pd_at_pfa']*100:.0f}% @ PFA={risk['pfa']:.0e}]",
                 color=rc, fontweight="bold")
    ax.set(ylabel="Elevation (deg)", xlabel="Time (s)")
    ax.legend(loc="upper right", fontsize=8); ax.grid(alpha=0.3)

    axs = fig.add_subplot(gs[0, 2], projection="polar")
    axs.set_theta_zero_location("N"); axs.set_theta_direction(-1)
    r = 90 - el
    axs.plot(np.deg2rad(az), r, lw=2, color="tab:blue")
    axs.plot(np.deg2rad(az[0]), r[0], "go", ms=8)
    axs.plot(np.deg2rad(az[-1]), r[-1], "ro", ms=8)
    pk = int(el.argmax()); axs.plot(np.deg2rad(az[pk]), r[pk], "b*", ms=14)
    axs.set_rmax(90); axs.set_rticks([0,30,60,90]); axs.set_yticklabels(["90°","60°","30°","0°"])
    axs.set_title("Sky path", fontsize=9, pad=14)

    ax = fig.add_subplot(gs[1, 0])
    ax.plot(t, lb["rx_power_dbw"], lw=1.4, color="tab:green")
    ax.axhline(float(lb["baseline_dbw"][0]), color="r", ls="--", lw=1, label="baseline")
    ax.set(xlabel="Time (s)", ylabel="RX power (dBW)", title="Received power")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)

    ax = fig.add_subplot(gs[1, 1])
    ax.plot(t, lb["cn0_dbhz"], lw=1.4, color="tab:purple")
    ax.axhline(cfg["prediction"]["cn0_threshold_dbhz"], color="r", ls="--", lw=1)
    ax.set(xlabel="Time (s)", ylabel="C/N0 (dB-Hz)", title="C/N0")
    ax.grid(alpha=0.3)

    ax = fig.add_subplot(gs[1, 2])
    ax.plot(t, np.asarray(track["doppler_hz"])/1e3, lw=1.4, color="tab:orange")
    ax.axhline(0, color="k", lw=0.5)
    ax.set(xlabel="Time (s)", ylabel="Doppler (kHz)", title="Doppler shift")
    ax.grid(alpha=0.3)

    ax = fig.add_subplot(gs[2, :])
    ax.plot(t, lb["snr_db"], lw=1.4, color="tab:blue", label="SNR")
    ax.plot(t, lb["deviation_db"], lw=1.4, color="tab:red", label="Deviation above baseline")
    ax.axhline(cfg["noise_baseline"]["margin_db"], color="r", ls=":", lw=1,
               label=f"interference threshold ({cfg['noise_baseline']['margin_db']} dB)")
    ax.axhline(0, color="k", lw=0.5)
    ax.set(xlabel="Time (s)", ylabel="dB", title="SNR & power deviation above noise baseline")
    ax.legend(loc="upper right", fontsize=8); ax.grid(alpha=0.3)
    return _save(fig, out_path)


def plot_link_budget(track, lb, sat_cfg, cfg, pass_idx, out_path):
    t = np.asarray(track["t_s"])
    fig, ax = plt.subplots(3, 1, figsize=(10, 9), sharex=True)
    ax[0].plot(t, lb["fspl_db"], label="FSPL", color="tab:blue")
    ax[0].plot(t, lb["atmos_db"], label="Atmospheric", color="tab:red")
    ax[0].set(ylabel="Loss (dB)", title=f"Link budget — Pass {pass_idx}")
    ax[0].legend(); ax[0].grid(alpha=0.3)
    ax[1].plot(t, lb["rx_power_dbw"], color="tab:green", lw=1.5, label="RX power")
    ax[1].axhline(float(lb["baseline_dbw"][0]), color="r", ls="--", label="baseline")
    ax[1].set(ylabel="Power (dBW)"); ax[1].legend(); ax[1].grid(alpha=0.3)
    ax[2].plot(t, lb["cn0_dbhz"], color="tab:purple", lw=1.5, label="C/N0")
    ax[2].axhline(cfg["prediction"]["cn0_threshold_dbhz"], color="r", ls="--")
    ax[2].set(xlabel="Time (s)", ylabel="C/N0 (dB-Hz)"); ax[2].legend(); ax[2].grid(alpha=0.3)
    fig.tight_layout()
    return _save(fig, out_path)


def plot_skypath(track, sat_cfg, pass_idx, out_path):
    from matplotlib.collections import LineCollection
    az = np.asarray(track["az_deg"]); el = np.asarray(track["el_deg"])
    r = 90 - el
    fig = plt.figure(figsize=(7, 7))
    ax = fig.add_subplot(111, projection="polar")
    ax.set_theta_zero_location("N"); ax.set_theta_direction(-1)
    pts = np.array([np.deg2rad(az), r]).T.reshape(-1, 1, 2)
    segs = np.concatenate([pts[:-1], pts[1:]], axis=1)
    lc = LineCollection(segs, cmap="RdYlGn_r", linewidth=2.5); lc.set_array(el)
    ax.add_collection(lc)
    ax.plot(np.deg2rad(az[0]), r[0], "go", ms=10, label="rise", zorder=5)
    ax.plot(np.deg2rad(az[-1]), r[-1], "ro", ms=10, label="set", zorder=5)
    pk = int(el.argmax()); ax.plot(np.deg2rad(az[pk]), r[pk], "b*", ms=15,
                                   label=f"peak {el[pk]:.1f}°", zorder=5)
    ax.set_rmax(90); ax.set_rticks([0,30,60,90]); ax.set_yticklabels(["90°","60°","30°","0°"])
    plt.colorbar(lc, ax=ax, label="Elevation (deg)", orientation="horizontal", pad=0.08)
    ax.set_title(f"Sky path — Pass {pass_idx}", pad=18)
    ax.legend(loc="upper right", bbox_to_anchor=(1.3, 1.1), fontsize=9)
    return _save(fig, out_path)


def plot_doppler(track, sat_cfg, pass_idx, out_path):
    t = np.asarray(track["t_s"])
    fig, ax = plt.subplots(2, 1, figsize=(10, 6), sharex=True)
    ax[0].plot(t, np.asarray(track["doppler_hz"])/1e3, lw=1.5, color="tab:orange")
    ax[0].axhline(0, color="k", lw=0.5)
    ax[0].set(ylabel="Doppler (kHz)", title=f"Doppler — Pass {pass_idx} @ {sat_cfg['frequency_hz']/1e6:.3f} MHz")
    ax[0].grid(alpha=0.3)
    ax[1].plot(t, np.asarray(track["range_rate_mps"])/1e3, lw=1.5, color="tab:purple")
    ax[1].axhline(0, color="k", lw=0.5)
    ax[1].set(xlabel="Time (s)", ylabel="Range rate (km/s)"); ax[1].grid(alpha=0.3)
    fig.tight_layout()
    return _save(fig, out_path)


# ════════════════════════════════════════════════════════════════════════════
# Operational forecast ROC (missed vs false interference)
# ════════════════════════════════════════════════════════════════════════════

def plot_forecast_roc(roc, out_path, *, title="Forecast ROC — missed vs false interference"):
    """Plot the predictor's operational ROC from theory.forecast_roc().

    Left: Pd vs PFA with the operating point (decision threshold = margin).
    Right: Pd and PFA vs the decision threshold, so the operator can read off
    the missed/false trade at any warning level.
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.5))
    pfa, pd, tau = roc["pfa"], roc["pd"], roc["thresholds_db"]

    ax1.plot(pfa, pd, lw=2.4, color="tab:blue", label=f"forecast ROC (AUC={roc['auc']:.3f})")
    ax1.plot([0, 1], [0, 1], ls=":", color="grey", lw=1, label="chance")
    op = roc["operating"]
    ax1.scatter([op["pfa"]], [op["pd"]], s=90, color="crimson", zorder=5,
                label=f"operating @ {op['threshold_db']:.0f} dB\n(Pd={op['pd']:.2f}, PFA={op['pfa']:.2f})")
    ax1.set(xlabel="P(false interference)  =  PFA", ylabel="P(detect interference)  =  Pd",
            title=title, xlim=(0, 1), ylim=(0, 1.02))
    ax1.grid(alpha=0.3); ax1.legend(loc="lower right", fontsize=9)

    ax2.plot(tau, pd, lw=2, color="tab:green", label="Pd  (1 − missed)")
    ax2.plot(tau, pfa, lw=2, color="tab:red", label="PFA (false interference)")
    ax2.axvline(op["threshold_db"], ls="--", color="crimson", lw=1.2,
                label=f"operating margin = {op['threshold_db']:.0f} dB")
    ax2.set(xlabel="Decision threshold above baseline (dB)", ylabel="Probability",
            title=f"Trade vs warning threshold  (baseline σ={roc['std_db']:.1f} dB, "
                  f"{roc['n_interfered']}+/{roc['n_clean']}− samples)", ylim=(0, 1.02))
    ax2.grid(alpha=0.3); ax2.legend(fontsize=9)
    return _save(fig, out_path)
