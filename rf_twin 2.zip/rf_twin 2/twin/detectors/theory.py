from __future__ import annotations
import math
import numpy as np

try:
    from scipy import special, stats
    _SCIPY = True
except ImportError:
    _SCIPY = False


# ── Gaussian Q-function and inverse ──────────────────────────────────────────

def Q(x):
    """Complementary Gaussian CDF Q(x) = P(N(0,1) > x)."""
    x = np.asarray(x, dtype=float)
    if _SCIPY:
        return 0.5 * special.erfc(x / np.sqrt(2))
    return 0.5 * np.vectorize(math.erfc)(x / math.sqrt(2))


def Qinv(p):
    """Inverse Q-function: x such that Q(x) = p."""
    p = np.asarray(p, dtype=float)
    if _SCIPY:
        return np.sqrt(2) * special.erfcinv(2 * p)
    # Fallback bisection (vectorized)
    def _s(pp):
        if pp <= 0: return 8.0
        if pp >= 1: return -8.0
        lo, hi = -8.0, 8.0
        for _ in range(64):
            m = (lo + hi) / 2
            if 0.5 * math.erfc(m / math.sqrt(2)) > pp: lo = m
            else: hi = m
        return (lo + hi) / 2
    return np.vectorize(_s)(p)


# ── Energy detector: threshold / PFA / Pd ────────────────────────────────────

def threshold_for_pfa(pfa: float, n: int, exact: bool = True) -> float:
    """Normalized energy threshold (multiples of noise power/sample) achieving
    a target PFA. This is the CFAR threshold: it depends only on PFA and N, not
    on the unknown signal, so the false-alarm rate stays constant."""
    n = int(n)
    if exact and _SCIPY:
        return float(stats.chi2.isf(pfa, df=2 * n) / (2 * n))
    return float(1.0 + Qinv(pfa) / math.sqrt(n))


def pfa_for_threshold(gamma: float, n: int, exact: bool = True) -> float:
    n = int(n)
    if exact and _SCIPY:
        return float(stats.chi2.sf(gamma * 2 * n, df=2 * n))
    return float(Q((gamma - 1.0) * math.sqrt(n)))


def pd_for_threshold(gamma: float, snr_db: float, n: int,
                     exact: bool = True) -> float:
    n = int(n)
    snr = 10 ** (snr_db / 10.0)
    if exact and _SCIPY:
        return float(stats.ncx2.sf(gamma * 2 * n, df=2 * n, nc=2 * n * snr))
    num = gamma - (1.0 + snr)
    den = math.sqrt((1.0 + 2.0 * snr) / n)
    return float(Q(num / den))


def pd_for_pfa(pfa: float, snr_db: float, n: int, exact: bool = True) -> float:
    return pd_for_threshold(threshold_for_pfa(pfa, n, exact), snr_db, n, exact)


# ── ROC curves and families ──────────────────────────────────────────────────

def roc_curve(snr_db: float, n: int, n_points: int = 300, exact: bool = True):
    """(pfa, pd) tracing the ROC for one SNR. PFA swept log-uniformly so the
    informative small-PFA region is dense."""
    pfa = np.logspace(-6, 0, n_points)
    pfa[-1] = 1.0
    pd = np.array([pd_for_pfa(p, snr_db, n, exact) for p in pfa])
    return pfa, pd


def roc_family(snr_list, n: int, n_points: int = 300, exact: bool = True):
    """{snr_db: (pfa, pd)} for several SNRs -- the family of curves."""
    return {s: roc_curve(s, n, n_points, exact) for s in snr_list}


def auc(pfa, pd) -> float:
    """Area under ROC (linear PFA axis). 1.0 perfect, 0.5 chance."""
    o = np.argsort(pfa)
    _trap = getattr(np, "trapezoid", None) or np.trapz
    return float(_trap(np.asarray(pd)[o], np.asarray(pfa)[o]))


# ── Sensitivity relations ────────────────────────────────────────────────────

def min_detectable_snr_db(pfa: float, pd_target: float, n: int,
                          exact: bool = True) -> float:
    """Smallest per-window SNR (dB) detectable at the target Pd & PFA."""
    lo, hi = -50.0, 60.0
    for _ in range(100):
        m = (lo + hi) / 2
        if pd_for_pfa(pfa, m, n, exact) < pd_target: lo = m
        else: hi = m
    return (lo + hi) / 2


def required_samples(snr_db: float, pfa: float, pd_target: float,
                     max_n: int = 50_000_000) -> int:
    """Integration samples N needed to hit target Pd/PFA at a given SNR."""
    if pd_for_pfa(pfa, snr_db, max_n) < pd_target:
        return max_n
    lo, hi = 1, max_n
    while lo < hi:
        m = (lo + hi) // 2
        if pd_for_pfa(pfa, snr_db, m) < pd_target: lo = m + 1
        else: hi = m
    return lo


def integration_gain_db(n: int) -> float:
    """Radiometer (square-law) integration gain ~ 5*log10(N) dB."""
    return 5.0 * math.log10(max(n, 1))


# ── Monte Carlo ROC validation ───────────────────────────────────────────────

def monte_carlo_roc(snr_db: float, n: int, n_trials: int = 20000,
                    seed: int = 0):
    """Empirically estimate the ROC by simulating the energy detector on
    random complex-Gaussian draws. Validates the analytic ROC -- the two should
    overlay. Returns (pfa_grid, pd_empirical, pd_analytic)."""
    rng = np.random.default_rng(seed)
    snr = 10 ** (snr_db / 10.0)
    # Noise-only and signal+noise energy statistics (normalized by noise power)
    # Each complex sample: real+imag ~ N(0, 1/2) so |x|^2 has unit mean.
    h0 = np.empty(n_trials)
    h1 = np.empty(n_trials)
    for i in range(n_trials):
        noise = (rng.standard_normal(n) + 1j * rng.standard_normal(n)) / math.sqrt(2)
        h0[i] = np.sum(np.abs(noise) ** 2) / n
        # signal: deterministic amplitude sqrt(snr) plus noise
        sig = math.sqrt(snr) * np.exp(1j * rng.uniform(0, 2 * np.pi, n))
        h1[i] = np.sum(np.abs(sig + noise) ** 2) / n
    pfa_grid = np.logspace(-4, 0, 50); pfa_grid[-1] = 1.0
    pd_emp, pd_ana = [], []
    for p in pfa_grid:
        gamma = np.quantile(h0, 1 - p)         # empirical threshold for this PFA
        pd_emp.append(np.mean(h1 > gamma))
        pd_ana.append(pd_for_pfa(p, snr_db, n))
    return pfa_grid, np.array(pd_emp), np.array(pd_ana)


# ── Operational forecast ROC (missed vs false interference) ──────────────────

def forecast_roc(deviation_db, margin_db: float, std_db: float,
                 n_points: int = 400):
    """ROC for the *predictor*, not the energy detector.

    The forecast declares "interference" when the predicted power-deviation
    above baseline crosses a decision threshold tau. Ground truth is the
    physics value crossing the operating margin. The observation is noisy:
    the day-to-day baseline fluctuation (noise_baseline.std_db) means the
    realised deviation is N(true, std). Sweeping tau traces the trade between
    probability of detection (1 - missed interference) and probability of
    false alarm (false interference) -- the curve the project actually wants.

    Parameters
    ----------
    deviation_db : array of predicted per-sample deviations above baseline (dB)
    margin_db    : interference threshold above baseline (truth boundary)
    std_db       : baseline fluctuation (observation noise, dB)

    Returns dict with pfa, pd, thresholds_db, auc, operating point, and counts.
    """
    d = np.asarray(deviation_db, float)
    d = d[np.isfinite(d)]
    std = max(float(std_db), 1e-6)
    truth = d >= margin_db
    pos, neg = d[truth], d[~truth]
    taus = np.linspace(d.min() - 4 * std, d.max() + 4 * std, n_points)

    def _rate(samples, tau):                       # P(observed >= tau | samples)
        if samples.size == 0:
            return np.zeros_like(tau)
        return Q((tau[:, None] - samples[None, :]) / std).mean(axis=1)

    pd = _rate(pos, taus)
    pfa = _rate(neg, taus)
    op_tau = np.array([margin_db])
    op_pd = float(_rate(pos, op_tau)[0]) if pos.size else float("nan")
    op_pfa = float(_rate(neg, op_tau)[0]) if neg.size else float("nan")

    order = np.argsort(pfa)
    _trap = getattr(np, "trapezoid", None) or np.trapz
    if neg.size and pos.size:
        area = float(_trap(pd[order], pfa[order]))
    elif pos.size and not neg.size:
        area = 1.0      # every sample interferes → perfect discrimination
    else:
        area = float("nan")

    return {
        "pfa": pfa, "pd": pd, "thresholds_db": taus, "auc": area,
        "operating": {"threshold_db": float(margin_db), "pfa": op_pfa, "pd": op_pd},
        "n_interfered": int(pos.size), "n_clean": int(neg.size),
        "margin_db": float(margin_db), "std_db": std,
    }
