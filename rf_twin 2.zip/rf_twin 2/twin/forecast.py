"""
twin/forecast.py — the prediction function.

`predict()` is the single entry point: give it a config, get back a structured
forecast (passes, per-pass risk / Pd / throughput, interference intervals) plus
an operational **forecast ROC** pooled across the window. It does no printing or
plotting, so it is reusable from a notebook, a service, or the CLI in predict.py.

    from twin.io.common import load_config
    from twin.forecast import predict
    result = predict(load_config("configs/config.yaml"))
    print(result["forecast_roc"]["auc"])
"""
from __future__ import annotations
from datetime import datetime, timezone, timedelta
import numpy as np

from .io.common import risk_level
from .core.propagator import get_tle, propagate_passes
from .core.link_budget import compute_link_budget, estimate_outages_throughput
from .detectors import theory
from .detectors.predictive import (rule_based_overlap, link_budget_detection,
                                    hmm_interference)


def pass_risk(lb: dict, cfg: dict) -> dict:
    """Risk + detection summary for one pass from its link budget."""
    dev = np.asarray(lb["deviation_db"], float)
    snr = np.asarray(lb["snr_db"], float)
    peak_dev, peak_snr = float(np.max(dev)), float(np.max(snr))
    pfa = cfg["detection"]["default_pfa"]
    n = cfg["detection"]["n_samples"]
    return {
        "peak_deviation_db": peak_dev,
        "peak_snr_db": peak_snr,
        "risk_level": risk_level(peak_dev, cfg),
        "pfa": pfa,
        "pd_at_pfa": theory.pd_for_pfa(pfa, peak_snr, n),
        "min_detectable_snr_db": theory.min_detectable_snr_db(pfa, 0.9, n),
    }


def compute_pass(pp, sat_cfg: dict, cfg: dict) -> dict:
    """Run the full physics + predictive layer for a single pass.

    Returns a serializable summary; the raw per-sample `track` and link budget
    `lb` are attached under underscore keys for plotting and are dropped on
    JSON save.
    """
    track, info, idx = pp.track, pp.info, pp.info.pass_index
    lb = compute_link_budget(
        track, sat_cfg, cfg["receiver"], cfg["noise_baseline"],
        pointing_error_deg=cfg["receiver"].get("pointing_error_deg", 0.0),
        polarization_loss_db=cfg["receiver"].get("polarization_loss_db", 0.5))

    risk = pass_risk(lb, cfg)
    tput = estimate_outages_throughput(track, lb, sat_cfg,
                                       cfg["prediction"]["cn0_threshold_dbhz"])
    band = (cfg["antenna_band"]["f_low_hz"], cfg["antenna_band"]["f_high_hz"])
    overlap = rule_based_overlap(track, sat_cfg, band,
                                 cfg["prediction"]["elevation_mask_deg"])
    link_budget_detection(track, lb, cfg["noise_baseline"],
                          cfg["detection"]["risk_thresholds"])
    hmm = hmm_interference(track, lb, cfg["noise_baseline"])

    return {
        "pass_index": idx, "satellite": sat_cfg["name"],
        "frequency_mhz": sat_cfg["frequency_hz"] / 1e6,
        "rise_utc": info.rise_utc.isoformat(),
        "culmination_utc": info.culmination_utc.isoformat(),
        "set_utc": info.set_utc.isoformat(),
        "max_elevation_deg": info.max_elevation_deg,
        "duration_s": info.duration_s,
        "risk": risk, "throughput": tput,
        "band_overlap": overlap["band_overlap"],
        "hmm_fraction_interfered": hmm["fraction_interfered"],
        "interference_intervals": [
            {"start_s": iv.t_start_s, "end_s": iv.t_end_s, "state": iv.state,
             "peak_dev_db": iv.peak_deviation_db} for iv in hmm["intervals"]],
        # raw arrays for plotting / ROC (stripped on JSON save)
        "_track": track, "_lb": lb, "_risk": risk, "_sat_cfg": sat_cfg,
    }


def predict(cfg: dict, *, now: datetime | None = None,
            window_hours: float | None = None, sat_filter: str | None = None,
            refresh_tle: bool = False) -> dict:
    """Forecast satellite interference over a time window.

    Returns
    -------
    dict with keys: run_utc, mode, window_hours, site, noise_baseline,
    detection_config, passes (serializable summaries), and forecast_roc.
    Internal raw arrays live under each pass's "_track"/"_lb" for plotting.
    """
    now = now or datetime.now(timezone.utc)
    window_h = window_hours or cfg["prediction"]["window_hours"]
    end = now + timedelta(hours=window_h)
    site = cfg["site"]

    sats = cfg["satellites"]
    if sat_filter:
        q = sat_filter.strip().lower()
        sats = [s for s in sats if q in s["name"].lower() or str(s["norad_id"]) == q]
        if not sats:
            raise ValueError(f"no satellite matches '{sat_filter}'")

    passes_out, errors = [], []
    for sat_cfg in sats:
        try:
            tle = get_tle(sat_cfg["norad_id"],
                          max_age_hours=cfg["prediction"]["tle_max_age_hours"],
                          force=refresh_tle)
            passes = propagate_passes(
                tle, site["lat_deg"], site["lon_deg"], site["alt_m"], now, end,
                mask_deg=cfg["prediction"]["elevation_mask_deg"],
                freq_hz=sat_cfg["frequency_hz"])
            for pp in passes:
                passes_out.append(compute_pass(pp, sat_cfg, cfg))
        except Exception as e:                       # noqa: BLE001 (report, continue)
            errors.append({"satellite": sat_cfg["name"], "error": str(e)})

    # ── operational forecast ROC, pooled over every in-pass sample ──
    # Also include quiet-sky samples (between passes, deviation ≈ 0 ± std_db)
    # so the ROC is defined even when every in-pass sample exceeds the margin.
    dev_pool = np.concatenate([p["_lb"]["deviation_db"] for p in passes_out]) \
        if passes_out else np.array([])
    if dev_pool.size:
        std = cfg["noise_baseline"]["std_db"]
        rng = np.random.default_rng(0)
        n_quiet = max(dev_pool.size, 200)            # represent the quiet fraction
        quiet_sky = rng.normal(0.0, std, n_quiet)    # deviation when no satellite visible
        dev_pool = np.concatenate([dev_pool, quiet_sky])
    roc = theory.forecast_roc(dev_pool,
                              margin_db=cfg["noise_baseline"]["margin_db"],
                              std_db=cfg["noise_baseline"]["std_db"]) \
        if dev_pool.size else None

    return {
        "run_utc": now.isoformat(), "mode": "predict", "window_hours": window_h,
        "site": site, "noise_baseline": cfg["noise_baseline"],
        "detection_config": cfg["detection"],
        "passes": sorted(passes_out, key=lambda r: r["rise_utc"]),
        "forecast_roc": _roc_summary(roc), "_forecast_roc_full": roc,
        "errors": errors,
    }


def _roc_summary(roc):
    """JSON-friendly summary (downsampled curve + scalars)."""
    if roc is None:
        return None
    step = max(1, len(roc["pfa"]) // 60)
    return {
        "auc": roc["auc"], "operating": roc["operating"],
        "n_interfered": roc["n_interfered"], "n_clean": roc["n_clean"],
        "margin_db": roc["margin_db"], "std_db": roc["std_db"],
        "pfa": [float(x) for x in roc["pfa"][::step]],
        "pd": [float(x) for x in roc["pd"][::step]],
        "thresholds_db": [float(x) for x in roc["thresholds_db"][::step]],
    }
