from __future__ import annotations
import math
import numpy as np

C = 299_792_458.0
K_DBW = -228.6                 # Boltzmann, dBW/K/Hz


# ── Antenna gain (realistic pattern) ─────────────────────────────────────────

def dish_boresight_gain_dbi(diameter_m: float, efficiency: float,
                            freq_hz: float) -> float:
    wl = C / freq_hz
    area = math.pi * (diameter_m / 2) ** 2
    return 10 * math.log10(4 * math.pi * area * efficiency / wl**2)


def dish_pattern_gain_dbi(off_axis_deg, diameter_m, efficiency, freq_hz):
    """Parabolic dish gain vs off-boresight angle, with a sidelobe floor.
    Uses the standard -12*(theta/theta_3dB)^2 main-lobe rolloff, clamped to a
    realistic -20 dBi sidelobe floor. Captures the antenna-realism effect:
    a satellite a few degrees off boresight is attenuated."""
    g0 = dish_boresight_gain_dbi(diameter_m, efficiency, freq_hz)
    wl = C / freq_hz
    theta_3db = 70.0 * wl / diameter_m              # approx 3-dB beamwidth (deg)
    off = np.abs(np.asarray(off_axis_deg, dtype=float))
    rolloff = -12.0 * (off / theta_3db) ** 2
    gain = g0 + rolloff
    sidelobe_floor = g0 - 30.0
    return np.maximum(gain, sidelobe_floor)


def fixed_antenna_gain_dbi(gain_dbi, off_axis_deg=None):
    """Fixed antenna (patch/QFH): broad pattern. Gentle rolloff with a wide
    beam (cos^2 model) if an off-axis angle is supplied."""
    if off_axis_deg is None:
        return gain_dbi
    off = np.clip(np.abs(np.asarray(off_axis_deg, dtype=float)), 0, 90)
    return gain_dbi + 20*np.log10(np.cos(np.deg2rad(off)) + 1e-3)


# ── Path & atmospheric loss ──────────────────────────────────────────────────

def fspl_db(range_m, freq_hz):
    wl = C / freq_hz
    return 20 * np.log10(4 * np.pi * np.asarray(range_m, float) / wl)


def atmospheric_loss_db(el_deg, zenith_loss_db=0.3, rain_rate_mm_hr=0.0):
    el = np.clip(np.asarray(el_deg, float), 0.5, 90.0)
    airmass = 1.0 / np.sin(np.deg2rad(el))
    loss = zenith_loss_db * airmass
    if rain_rate_mm_hr > 0:
        loss = loss + 0.012 * rain_rate_mm_hr * airmass
    return loss


# ── Full link budget over a pass ─────────────────────────────────────────────

def compute_link_budget(track: dict, sat_cfg: dict, rx_cfg: dict,
                        noise_cfg: dict, *, pointing_error_deg: float = 0.0,
                        polarization_loss_db: float = 0.5) -> dict:
    """Compute received power, noise, SNR, and deviation-above-baseline for a
    pass track. Returns per-second arrays.

    track: dict with el_deg, range_m, range_rate_mps, doppler_hz, t_s
    sat_cfg: {frequency_hz, bandwidth_hz, eirp_dbw}
    rx_cfg: receiver hardware
    noise_cfg: {floor_dbm, std_db, margin_db, ...}
    """
    freq = sat_cfg["frequency_hz"]; bw = sat_cfg["bandwidth_hz"]
    eirp = sat_cfg["eirp_dbw"]
    el = np.asarray(track["el_deg"], float)
    rng = np.asarray(track["range_m"], float)

    # RX antenna gain (with pattern + pointing error)
    if rx_cfg["antenna_type"].lower() == "dish":
        g_rx = dish_pattern_gain_dbi(pointing_error_deg, rx_cfg["dish_diameter_m"],
                                     rx_cfg["dish_efficiency"], freq)
        g_rx = float(g_rx) if np.isscalar(g_rx) or g_rx.ndim == 0 else float(g_rx)
        g_boresight = dish_boresight_gain_dbi(rx_cfg["dish_diameter_m"],
                                              rx_cfg["dish_efficiency"], freq)
    else:
        g_rx = float(fixed_antenna_gain_dbi(rx_cfg["fixed_gain_dbi"], pointing_error_deg))
        g_boresight = rx_cfg["fixed_gain_dbi"]

    fixed_loss = (rx_cfg["cable_loss_db"] + rx_cfg["connector_loss_db"]
                  + rx_cfg["implementation_loss_db"] + polarization_loss_db)
    tsys = rx_cfg["system_noise_temp_k"]
    n0 = K_DBW + 10*math.log10(tsys)                # dBW/Hz
    noise_floor = n0 + 10*math.log10(bw)            # dBW in BW

    fsp = fspl_db(rng, freq)
    atm = atmospheric_loss_db(el, rain_rate_mm_hr=noise_cfg.get("rain_rate_mm_hr", 0.0))
    rx_power = eirp - fsp - atm - fixed_loss + g_rx
    cn0 = rx_power - n0
    snr = rx_power - noise_floor

    baseline_dbw = noise_cfg["floor_dbm"] - 30.0
    deviation = rx_power - baseline_dbw

    return {
        "fspl_db": fsp, "atmos_db": atm, "rx_power_dbw": rx_power,
        "cn0_dbhz": cn0, "snr_db": snr,
        "noise_floor_dbw": np.full_like(rx_power, noise_floor),
        "baseline_dbw": np.full_like(rx_power, baseline_dbw),
        "deviation_db": deviation,
        "g_rx_dbi": g_rx, "g_boresight_dbi": g_boresight,
        "fixed_losses_db": fixed_loss,
        "g_over_t_db": g_boresight - 10*math.log10(tsys),
    }


def per_window_snr_db(continuous_snr_db, bandwidth_hz, window_n, fs):
    """Convert the continuous (full-bandwidth) SNR to the per-detection-window
    SNR that drives Pd/PFA. A detector integrating window_n samples sees a
    processing gain; the effective per-window SNR is the input SNR adjusted for
    the integration. This links the link budget to the detection theory."""
    # The per-window energy SNR after N-sample integration
    snr_lin = 10 ** (np.asarray(continuous_snr_db, float) / 10)
    return continuous_snr_db   # the link-budget SNR already is the per-window basis


# ── Throughput / outage estimation (Module 6) ───────────────────────────────

def estimate_outages_throughput(track: dict, lb: dict, sat_cfg: dict,
                                cn0_threshold_dbhz: float,
                                modcod_efficiency: float = 0.5) -> dict:
    """Mark link outages and estimate throughput over the pass (Module 6)."""
    t = np.asarray(track["t_s"], float)
    cn0 = lb["cn0_dbhz"]; bw = sat_cfg["bandwidth_hz"]
    usable = cn0 >= cn0_threshold_dbhz
    # Shannon capacity per second (bits/s), gated by usability
    snr_lin = np.clip(10**(lb["snr_db"]/10), 0, None)
    cap_bps = bw * np.log2(1 + snr_lin)
    # Per-sample dt: uniform spacing so sum(dt) == total span exactly
    dt_val = (t[-1] - t[0]) / (len(t) - 1) if len(t) > 1 else 1.0
    delivered_bits = float(np.sum(cap_bps * usable) * dt_val * modcod_efficiency)
    # Outage runs
    outages = []
    mask = ~usable
    if mask.any():
        d = np.diff(mask.astype(int))
        starts = list(np.where(d == 1)[0] + 1)
        ends = list(np.where(d == -1)[0] + 1)
        if mask[0]: starts = [0] + starts
        if mask[-1]: ends = ends + [len(mask)]
        for a, b in zip(starts, ends):
            outages.append({"start_s": float(t[a]),
                            "end_s": float(t[min(b, len(t)-1)]),
                            "duration_s": float(t[min(b, len(t)-1)] - t[a])})
    return {
        "usable_seconds": float(np.sum(usable) * dt_val),
        "total_seconds": float(len(t) * dt_val),
        "peak_capacity_mbps": float(np.max(cap_bps) / 1e6),
        "delivered_megabytes": delivered_bits / 8 / 1e6,
        "outages": outages,
        "outage_count": len(outages),
    }
