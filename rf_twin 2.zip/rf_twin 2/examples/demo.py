"""
demo.py — minimal end-to-end PREDICT + ROC demonstration.

Shows the two deliverables in ~20 lines of real use:
  1. predict()         — the prediction function (forecast over a window)
  2. forecast_roc plot — the operational missed-vs-false-interference ROC
"""
from __future__ import annotations
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from twin.io.common import load_config
from twin.forecast import predict
from twin.plots import figures as figs

HERE = Path(__file__).parent
OUT = HERE / "demo_output"; OUT.mkdir(exist_ok=True)

cfg = load_config(HERE.parent / "configs" / "config.yaml")

# 1) PREDICTION FUNCTION — one call returns the structured forecast
result = predict(cfg, sat_filter="metop", window_hours=24)

print(f"Forecast window: {result['window_hours']:.0f} h   passes: {len(result['passes'])}")
for p in result["passes"]:
    r = p["risk"]
    print(f"  {p['satellite']:<14} rise {p['rise_utc'][11:19]}  max el {p['max_elevation_deg']:4.1f}deg  "
          f"[{r['risk_level']}]  peak dev {r['peak_deviation_db']:+.1f} dB  Pd={r['pd_at_pfa']*100:.0f}%")

# 2) ROC CURVE — operational forecast ROC (missed vs false interference)
roc = result["forecast_roc"]
op = roc["operating"]
print(f"\nForecast ROC  AUC={roc['auc']:.3f}   operating @ {op['threshold_db']:.0f} dB: "
      f"Pd={op['pd']*100:.0f}%  PFA={op['pfa']*100:.0f}%")
if result["_forecast_roc_full"]:
    png = figs.plot_forecast_roc(result["_forecast_roc_full"], OUT / "forecast_roc.png")
    print(f"[saved] {png}")

# the analytic energy-detector ROC family is still available too:
figs.plot_roc_family(cfg["detection"]["roc_snr_list_db"], cfg["detection"]["roc_n_for_family"],
                     OUT / "roc_family.png", operating_pfa=cfg["detection"]["default_pfa"])
print(f"[saved] {OUT/'roc_family.png'}")
