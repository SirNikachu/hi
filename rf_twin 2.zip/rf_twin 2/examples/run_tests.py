from __future__ import annotations
import sys, traceback
from pathlib import Path
from datetime import datetime, timezone
import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

PASS = "\033[92mPASS\033[0m"
FAIL = "\033[91mFAIL\033[0m"
results = []


def check(name, fn):
    try:
        fn()
        results.append((name, True, ""))
        print(f"  [{PASS}] {name}")
    except Exception as e:
        results.append((name, False, str(e)))
        print(f"  [{FAIL}] {name}: {e}")
        traceback.print_exc()


# ── Module 5: detection theory ───────────────────────────────────────────────
def test_theory():
    from twin.detectors import theory as t
    # PFA round-trip
    g = t.threshold_for_pfa(0.01, 1024)
    assert abs(t.pfa_for_threshold(g, 1024) - 0.01) < 1e-3, "PFA round-trip"
    # Pd increases with SNR
    pds = [t.pd_for_pfa(0.01, s, 32) for s in [-10, -5, 0, 5]]
    assert all(pds[i] <= pds[i+1] for i in range(len(pds)-1)), "Pd monotonic in SNR"
    # ROC family
    fam = t.roc_family([-6, 0, 6], 32)
    assert len(fam) == 3, "ROC family count"
    # AUC sane
    pfa, pd = t.roc_curve(6, 32)
    assert 0.9 < t.auc(pfa, pd) <= 1.0, "AUC in range"
    # min detectable SNR decreases with N
    s1 = t.min_detectable_snr_db(1e-3, 0.9, 64)
    s2 = t.min_detectable_snr_db(1e-3, 0.9, 4096)
    assert s2 < s1, "min SNR improves with integration"


def test_monte_carlo():
    from twin.detectors import theory as t
    pfa, emp, ana = t.monte_carlo_roc(3.0, 256, n_trials=3000)
    # empirical and analytic should be close
    err = np.mean(np.abs(emp - ana))
    assert err < 0.1, f"MC vs analytic mean err {err:.3f}"


# ── Detectors on IQ ──────────────────────────────────────────────────────────
def test_predictive():
    from twin.detectors import predictive as p
    n = 300
    t = np.arange(n, dtype=float)
    el = 15 + 35*np.sin(np.pi*t/n)
    dev = -5 + 25*np.sin(np.pi*t/n)
    track = {"t_s": t, "el_deg": el}
    lb = {"deviation_db": dev}
    nc = {"margin_db": 6.0}
    rt = {"low_db": 3, "medium_db": 10, "high_db": 20}
    # rule-based
    sc = {"frequency_hz": 1701.3e6, "bandwidth_hz": 3e6}
    r = p.rule_based_overlap(track, sc, (1700e6, 1702e6))
    assert r["band_overlap"], "band overlap detected"
    # link-budget
    r = p.link_budget_detection(track, lb, nc, rt)
    assert r["peak_deviation_db"] > 15, "peak deviation"
    # HMM
    r = p.hmm_interference(track, lb, nc)
    assert len(r["intervals"]) >= 1, "HMM finds interval"
    assert r["fraction_interfered"] > 0, "HMM fraction"


# ── Module 1-2: propagation ──────────────────────────────────────────────────
def test_propagation():
    from twin.core.propagator import _parse_tle, propagate_passes
    tle_text = ("METOP-C\n"
                "1 43689U 18087A   25109.19020060  .00000246  00000+0  13219-3 0  9999\n"
                "2 43689  98.6777 170.1931 0000320  15.7345 344.3842 14.21515771334594")
    tle = _parse_tle(tle_text)
    assert tle is not None, "TLE parse"
    start = datetime(2025, 4, 19, 0, 0, tzinfo=timezone.utc)
    end = datetime(2025, 4, 20, 0, 0, tzinfo=timezone.utc)
    passes = propagate_passes(tle, 42.50518, -71.23530, 68.0, start, end,
                              mask_deg=10.0, freq_hz=1701.3e6)
    assert len(passes) == 4, f"expected 4 passes, got {len(passes)}"
    # peak elevation of best pass
    max_el = max(p.info.max_elevation_deg for p in passes)
    assert 55 < max_el < 65, f"peak elevation {max_el}"
    # Doppler sane (~36 kHz)
    best = max(passes, key=lambda p: p.info.max_elevation_deg)
    dopp = np.max(np.abs(best.track["doppler_hz"]))
    assert 30e3 < dopp < 42e3, f"Doppler {dopp/1e3:.1f} kHz"


# ── Module 3-4: link budget ──────────────────────────────────────────────────
def test_link_budget():
    from twin.core.propagator import _parse_tle, propagate_passes
    from twin.core.link_budget import compute_link_budget
    from twin.io.common import load_config
    cfg = load_config(str(Path(__file__).parent.parent/"configs"/"config.yaml"))
    tle_text = ("METOP-C\n"
                "1 43689U 18087A   25109.19020060  .00000246  00000+0  13219-3 0  9999\n"
                "2 43689  98.6777 170.1931 0000320  15.7345 344.3842 14.21515771334594")
    tle = _parse_tle(tle_text)
    start = datetime(2025, 4, 19, 0, 0, tzinfo=timezone.utc)
    end = datetime(2025, 4, 20, 0, 0, tzinfo=timezone.utc)
    passes = propagate_passes(tle, 42.50518, -71.23530, 68.0, start, end,
                              mask_deg=10.0, freq_hz=1701.3e6)
    best = max(passes, key=lambda p: p.info.max_elevation_deg)
    lb = compute_link_budget(best.track, cfg["satellites"][0], cfg["receiver"],
                             cfg["noise_baseline"])
    # Validated: G/T = 8.27, peak C/N0 ~88-90
    assert abs(lb["g_over_t_db"] - 8.27) < 0.2, f"G/T {lb['g_over_t_db']}"
    assert 86 < lb["cn0_dbhz"].max() < 91, f"peak C/N0 {lb['cn0_dbhz'].max()}"


# ── Module 6: throughput ─────────────────────────────────────────────────────
def test_throughput():
    from twin.core.link_budget import estimate_outages_throughput
    n = 300
    t = np.arange(n, dtype=float)
    track = {"t_s": t}
    lb = {"cn0_dbhz": 40 + 20*np.sin(np.pi*t/n), "snr_db": 5 + 15*np.sin(np.pi*t/n)}
    sc = {"bandwidth_hz": 3e6}
    r = estimate_outages_throughput(track, lb, sc, 35.0)
    assert r["delivered_megabytes"] > 0, "throughput positive"
    assert r["usable_seconds"] <= r["total_seconds"], "usable <= total"


# ── SDR realism ──────────────────────────────────────────────────────────────
def test_plots():
    from twin.plots import figures as f
    import tempfile
    d = Path(tempfile.mkdtemp())
    p = f.plot_roc_family([-6, 0, 6], 32, d/"roc.png", operating_pfa=0.01)
    assert p.exists() and p.stat().st_size > 1000, "ROC family plot"
    p = f.plot_detection_performance([-6, 0, 6], [16, 256], d/"perf.png")
    assert p.exists(), "detection performance plot"
    import numpy as np
    from twin.detectors import theory as th
    roc = th.forecast_roc(np.concatenate([np.linspace(-12,4,150), np.linspace(4,16,90)]), 6.0, 2.0)
    p = f.plot_forecast_roc(roc, d/"forecast_roc.png")
    assert p.exists(), "forecast ROC plot"


def test_forecast_roc():
    import numpy as np
    from twin.detectors import theory
    from twin.forecast import predict
    from twin.io.common import load_config
    d = np.concatenate([np.linspace(-12, 4, 200), np.linspace(4, 16, 120)])
    r = theory.forecast_roc(d, margin_db=6.0, std_db=2.0)
    assert 0.5 < r["auc"] <= 1.0 and r["n_interfered"] > 0 and r["n_clean"] > 0
    assert 0.0 <= r["operating"]["pd"] <= 1.0 and 0.0 <= r["operating"]["pfa"] <= 1.0


if __name__ == "__main__":
    print("=" * 60)
    print("RF DIGITAL TWIN — SELF TEST")
    print("=" * 60)
    print("\nModule 5 — Detection theory")
    check("threshold/PFA/Pd math", test_theory)
    check("Monte Carlo validates analytic ROC", test_monte_carlo)
    print("\nPredictive detectors")
    check("Rule-based / link-budget / HMM", test_predictive)
    print("\nModules 1-2 — Orbit & geometry")
    check("SGP4 propagation + TEME->ECEF", test_propagation)
    print("\nModules 3-4 — Link budget & interference")
    check("Link budget (validated numbers)", test_link_budget)
    print("\nModule 6 — Throughput & outage")
    check("Throughput estimation", test_throughput)
    print("\nForecast ROC")
    check("Forecast ROC (missed vs false)", test_forecast_roc)
    print("\nModule 7 — Visualization")
    check("Plot generation", test_plots)

    n_pass = sum(1 for _, ok, _ in results if ok)
    n_total = len(results)
    print("\n" + "=" * 60)
    color = "\033[92m" if n_pass == n_total else "\033[91m"
    print(f"{color}{n_pass}/{n_total} tests passed\033[0m")
    print("=" * 60)
    sys.exit(0 if n_pass == n_total else 1)
