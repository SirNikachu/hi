"""
predict.py — PREDICT mode CLI.

    python predict.py                      # HCRO default, 24h
    python predict.py --site bedford       # switch to Bedford
    python predict.py --site hcro --next 48 --sat metop
    python predict.py --no-plots
"""
from __future__ import annotations
import argparse, json, sys, csv
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from twin.io.common import load_config, resolve_site, COLORS
from twin.forecast import predict
from twin.plots import figures as figs


def _write_csv(path, track, lb):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["t_s","az_deg","el_deg","range_km","range_rate_mps",
                    "doppler_hz","fspl_db","atmos_db","rx_power_dbw",
                    "cn0_dbhz","snr_db","deviation_db"])
        t = track["t_s"]
        for i in range(len(t)):
            w.writerow([f"{t[i]:.1f}", f"{track['az_deg'][i]:.3f}",
                        f"{track['el_deg'][i]:.3f}", f"{track['range_m'][i]/1000:.2f}",
                        f"{track['range_rate_mps'][i]:.2f}", f"{track['doppler_hz'][i]:.1f}",
                        f"{lb['fspl_db'][i]:.3f}", f"{lb['atmos_db'][i]:.4f}",
                        f"{lb['rx_power_dbw'][i]:.3f}", f"{lb['cn0_dbhz'][i]:.3f}",
                        f"{lb['snr_db'][i]:.3f}", f"{lb['deviation_db'][i]:.3f}"])


def _strip(result):
    out = {k: v for k, v in result.items() if not k.startswith("_")}
    out["passes"] = [{k: v for k, v in p.items() if not k.startswith("_")}
                     for p in result["passes"]]
    return out


def main():
    ap = argparse.ArgumentParser(description="PREDICT mode — forecast interference.")
    ap.add_argument("--config", default=str(Path(__file__).parent/"configs"/"config.yaml"))
    ap.add_argument("--site", default=None,
                    help="named site profile from config (e.g. hcro, bedford)")
    ap.add_argument("--next", dest="next_hours", type=float, default=None)
    ap.add_argument("--sat", default=None)
    ap.add_argument("--pfa", type=float, default=None)
    ap.add_argument("--baseline", type=float, default=None)
    ap.add_argument("--mask", type=float, default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--no-plots", action="store_true")
    ap.add_argument("--refresh-tle", action="store_true")
    args = ap.parse_args()

    cfg = load_config(args.config)
    cfg = resolve_site(cfg, args.site)          # merge site profile if given

    # CLI overrides (applied after site merge)
    if args.pfa is not None:      cfg["detection"]["default_pfa"] = args.pfa
    if args.baseline is not None:
        cfg["noise_baseline"]["floor_dbm"] = args.baseline
        cfg["noise_baseline"]["source"] = "cli_override"
    if args.mask is not None:     cfg["prediction"]["elevation_mask_deg"] = args.mask
    if args.out is not None:      cfg["output"]["dir"] = args.out

    out_dir = Path(cfg["output"]["dir"]); out_dir.mkdir(parents=True, exist_ok=True)
    site = cfg["site"]

    result = predict(cfg, window_hours=args.next_hours, sat_filter=args.sat,
                     refresh_tle=args.refresh_tle)
    window_h = result["window_hours"]

    print("=" * 70)
    print("RF INTERFERENCE DIGITAL TWIN  —  PREDICT MODE")
    print("=" * 70)
    print(f"Site:     {site['name']} ({site['lat_deg']:.4f}, {site['lon_deg']:.4f}, {site['alt_m']:.0f}m)")
    print(f"Window:   {result['run_utc'][:16].replace('T',' ')} UTC  +{window_h:.0f}h")
    print(f"Baseline: {cfg['noise_baseline']['floor_dbm']:.1f} dBm [{cfg['noise_baseline']['source']}]  "
          f"margin {cfg['noise_baseline']['margin_db']:.0f} dB  sigma {cfg['noise_baseline']['std_db']:.1f} dB")
    print(f"Receiver: {cfg['receiver']['dish_diameter_m']:.1f} m dish  "
          f"T_sys {cfg['receiver']['system_noise_temp_k']:.0f} K")
    print(f"PFA:      {cfg['detection']['default_pfa']:.0e}   "
          f"N={cfg['detection']['n_samples']}   "
          f"mask {cfg['prediction']['elevation_mask_deg']:.0f}\u00b0")
    print("=" * 70)

    for err in result["errors"]:
        print(f"  [ERROR] {err['satellite']}: {err['error']}")
    if not result["passes"]:
        print("  no passes in window")
    for p in result["passes"]:
        r = p["risk"]; rc = COLORS.get(r["risk_level"], ""); rst = COLORS["RESET"]
        print(f"\n  {p['satellite']}  pass {p['pass_index']}: "
              f"rise {p['rise_utc'][11:19]}  set {p['set_utc'][11:19]}  "
              f"max el {p['max_elevation_deg']:.1f}\u00b0  dur {p['duration_s']:.0f}s")
        print(f"    {rc}[{r['risk_level']} RISK]{rst}  peak dev {r['peak_deviation_db']:+.1f} dB  |  "
              f"peak SNR {r['peak_snr_db']:.1f} dB  |  "
              f"Pd={r['pd_at_pfa']*100:.0f}% @ PFA={r['pfa']:.0e}")
        t = p["throughput"]
        print(f"    usable {t['usable_seconds']:.0f}/{t['total_seconds']:.0f}s  "
              f"peak {t['peak_capacity_mbps']:.1f} Mbps  "
              f"delivered {t['delivered_megabytes']:.0f} MB  outages {t['outage_count']}")
        if cfg["output"]["save_csv"]:
            sat_dir = out_dir / p["satellite"].replace("/","_").replace(" ","_")
            sat_dir.mkdir(exist_ok=True)
            _write_csv(sat_dir / f"pass_{p['pass_index']}_track.csv", p["_track"], p["_lb"])

    if not args.no_plots and cfg["output"]["save_plots"] and result["passes"]:
        print("\n  plots...", end=" ", flush=True)
        for p in result["passes"]:
            sat_dir = out_dir / p["satellite"].replace("/","_").replace(" ","_")
            sat_dir.mkdir(exist_ok=True); idx = p["pass_index"]
            figs.plot_pass_dashboard(p["_track"], p["_lb"], p["_risk"], p["satellite"],
                                     idx, cfg, sat_dir / f"pass_{idx}_dashboard.png")
            figs.plot_link_budget(p["_track"], p["_lb"], p["_sat_cfg"], cfg, idx,
                                  sat_dir / f"pass_{idx}_link_budget.png")
            figs.plot_skypath(p["_track"], p["_sat_cfg"], idx, sat_dir / f"pass_{idx}_skypath.png")
            figs.plot_doppler(p["_track"], p["_sat_cfg"], idx, sat_dir / f"pass_{idx}_doppler.png")
        figs.plot_roc_family(cfg["detection"]["roc_snr_list_db"],
                             cfg["detection"]["roc_n_for_family"],
                             out_dir / "roc_family.png",
                             operating_pfa=cfg["detection"]["default_pfa"],
                             monte_carlo_snr=0.0,
                             title_extra=f"  [N={cfg['detection']['roc_n_for_family']} window]")
        figs.plot_detection_performance(cfg["detection"]["roc_snr_list_db"], [8, 32, 128, 512],
                                        out_dir / "detection_performance.png",
                                        pfa=cfg["detection"]["default_pfa"])
        if result["_forecast_roc_full"]:
            figs.plot_forecast_roc(result["_forecast_roc_full"], out_dir / "forecast_roc.png")
        print("done")

    print(f"\n{'='*70}\nINTERFERENCE WARNING SUMMARY  [{site['name']}]\n{'='*70}")
    risky = [r for r in result["passes"] if r["risk"]["risk_level"] != "NONE"]
    if not risky:
        print("  no interference-risk passes in this window")
    for r in risky:
        rl = r["risk"]["risk_level"]; rc = COLORS.get(rl, ""); rst = COLORS["RESET"]
        print(f"  {rc}[{rl:6s}]{rst}  {r['satellite']:<16}  rise {r['rise_utc'][11:19]} UTC  "
              f"max el {r['max_elevation_deg']:5.1f}\u00b0  "
              f"peak dev {r['risk']['peak_deviation_db']:+5.1f} dB  "
              f"Pd={r['risk']['pd_at_pfa']*100:.0f}%")
    roc = result["forecast_roc"]
    if roc:
        op = roc["operating"]
        print(f"\nFORECAST ROC:  AUC={roc['auc']:.3f}")
        print(f"  operating @ {op['threshold_db']:.0f} dB -> "
              f"Pd={op['pd']*100:.0f}%  PFA={op['pfa']*100:.0f}%  "
              f"[{roc['n_interfered']}+/{roc['n_clean']}- samples]")

    if cfg["output"]["save_json"]:
        (out_dir / "predict_summary.json").write_text(
            json.dumps(_strip(result), indent=2, default=str))
        print(f"\n[saved] {out_dir/'predict_summary.json'}")
    print(f"\n[done] {len(result['passes'])} pass(es) -> {out_dir.resolve()}")


if __name__ == "__main__":
    main()
