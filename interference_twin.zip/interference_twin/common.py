"""io/common.py — config loading, site profiles, risk levels."""
from __future__ import annotations
import copy
import yaml

COLORS = {"NONE": "\033[92m", "LOW": "\033[93m",
          "MEDIUM": "\033[33m", "HIGH": "\033[91m", "RESET": "\033[0m"}


def load_config(path: str) -> dict:
    with open(path) as f:
        cfg = yaml.safe_load(f)
    # YAML can read 1701.3e6 as a string; cast numeric fields.
    for sat in cfg.get("satellites", []):
        for k in ("downlink_hz", "bandwidth_hz", "eirp_dbw", "transmit_duty"):
            if k in sat:
                sat[k] = float(sat[k])
    for k in ("f_low_hz", "f_high_hz"):
        if k in cfg.get("observed_band", {}):
            cfg["observed_band"][k] = float(cfg["observed_band"][k])
    for k, v in cfg.get("severity", {}).items():
        cfg["severity"][k] = float(v)
    return cfg


def resolve_site(cfg: dict, site_key: str | None) -> dict:
    """Merge a named site profile into cfg. A profile overrides the site
    geometry and may override the severity reference (which stands in for
    that site's receiver sensitivity / RF environment)."""
    cfg = copy.deepcopy(cfg)
    if site_key is None:
        return cfg
    profiles = cfg.get("sites", {})
    key = site_key.strip().lower()
    if key not in profiles:
        raise ValueError(f"unknown site '{site_key}'. Available: {list(profiles)}")
    p = profiles[key]
    cfg["site"] = {k: v for k, v in p.items() if k not in ("severity",)}
    if "severity" in p:
        for k, v in p["severity"].items():
            cfg["severity"][k] = float(v)
    return cfg


def severity_risk(sev_db: float, sev_cfg: dict) -> str:
    """Map a relative severity (dB above the PFD reference) to a risk label."""
    if sev_db < 0:
        return "NONE"
    if sev_db < sev_cfg["low_db"]:
        return "LOW"
    if sev_db < sev_cfg["medium_db"]:
        return "MEDIUM"
    return "HIGH"
