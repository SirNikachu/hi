"""
predict.py — Interference-Opportunity Digital Twin (Layer 1).

Predicts WHERE and WHEN satellites are likely to create interference, in
relative / calibration-free units. No SDR data and no receiver model.

    python predict.py
    python predict.py --site bedford
    python predict.py --site hcro --next 48 --sat metop
    python predict.py --no-plots
"""
from __future__ import annotations
import argparse, json, sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))

from common import load_config, resolve_site, severity_risk, COLORS
from core.propagator import get_tle, propagate_passes
from core.geometry import severity as compute_severity
from core.doppler_map import prediction_map
from inference.prior import prior_interference
from inference.bayesian import posterior, decision_roc
from output.calendar import opportunity_windows
from output.severity import pass_summary
from output import visualize as viz


def build(cfg, *, now=None, window_hours=None, sat_filter=None, refresh_tle=False):
    """Run the twin. Returns a JSON-able result dict plus raw arrays for plots."""
    now = now or datetime.now(timezone.utc)
    window_h = window_hours or cfg["prediction"]["window_hours"]
    end = now + timedelta(hours=window_h)
    site, band = cfg["site"], cfg["observed_band"]
    mask = cfg["prediction"]["elevation_mask_deg"]

    sats = cfg["satellites"]
    if sat_filter:
        q = sat_filter.strip().lower()
        sats = [s for s in sats if q in s["name"].lower() or str(s["norad_id"]) == q]
        if not sats:
            raise ValueError(f"no satellite matches '{sat_filter}'")

    rng = np.random.default_rng(7)
    summaries, windows, errors = [], [], []
    raw_passes, maps = [], []
    roc_scores, roc_truth = [], []

    for sat in sats:
        try:
            tle = get_tle(sat["norad_id"],
                          max_age_hours=cfg["prediction"]["tle_max_age_hours"],
                          force=refresh_tle)
            passes = propagate_passes(tle, site["lat_deg"], site["lon_deg"],
                                      site["alt_m"], now, end, mask_deg=mask,
                                      freq_hz=sat["downlink_hz"])
        except Exception as e:                       # noqa: BLE001
            errors.append({"satellite": sat["name"], "error": str(e)})
            continue

        first = True
        for pp in passes:
            sev, pfd_inb, frac = compute_severity(pp.track, sat, band, cfg["severity"])
            prior = prior_interference(pp.track, sev, frac, sat, cfg)
            post = posterior(prior)                  # == prior (no SDR yet)

            summaries.append(pass_summary(pp, sat, sev, post, frac, cfg))
            windows.extend(opportunity_windows(pp, sat, post, sev, cfg))
            maps.append((sat["name"], pp.info.pass_index,
                         prediction_map(pp.track, sat, sev)))
            raw_passes.append({"sat": sat["name"], "first": first,
                               "time_utc": pp.track["time_utc"], "prob": post,
                               "sev": sev, "track": pp.track, "idx": pp.info.pass_index})
            first = False

            # ground truth for the decision ROC: this pass transmits with prob
            # = duty (sampled once per pass); interference is real where it is
            # transmitting, above mask, and the arriving flux beats the reference.
            tx = rng.random() < float(sat.get("transmit_duty", 1.0))
            truth = tx & (np.asarray(pp.track["el_deg"]) >= mask) & (sev >= 0.0)
            roc_scores.append(np.asarray(post)); roc_truth.append(truth)

    roc = None
    if roc_scores:
        roc = decision_roc(np.concatenate(roc_scores), np.concatenate(roc_truth),
                           operating_threshold=cfg["decision"]["threshold"])

    windows.sort(key=lambda w: w["start_utc"])
    summaries.sort(key=lambda s: s["rise_utc"])
    result = {
        "run_utc": now.isoformat(), "window_hours": window_h,
        "site": site, "observed_band_mhz": [band["f_low_hz"]/1e6, band["f_high_hz"]/1e6],
        "severity_reference_dbw_m2": cfg["severity"]["pfd_reference_dbw_m2"],
        "decision_threshold": cfg["decision"]["threshold"],
        "passes": summaries, "opportunity_windows": windows,
        "decision_roc": _roc_json(roc), "errors": errors,
    }
    return result, {"raw_passes": raw_passes, "maps": maps, "roc": roc}


def _roc_json(roc):
    if roc is None:
        return None
    step = max(1, len(roc["pfa"]) // 50)
    return {"auc": roc["auc"], "operating": roc["operating"],
            "n_interfering": roc["n_interfering"], "n_clean": roc["n_clean"],
            "pfa": [float(x) for x in roc["pfa"][::step]],
            "pd": [float(x) for x in roc["pd"][::step]]}


def main():
    ap = argparse.ArgumentParser(description="Interference-opportunity twin")
    ap.add_argument("--config", default=str(Path(__file__).parent/"configs"/"config.yaml"))
    ap.add_argument("--site", default=None)
    ap.add_argument("--next", dest="next_hours", type=float, default=None)
    ap.add_argument("--sat", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--no-plots", action="store_true")
    ap.add_argument("--refresh-tle", action="store_true")
    args = ap.parse_args()

    cfg = resolve_site(load_config(args.config), args.site)
    if args.out:
        cfg["output"]["dir"] = args.out
    out_dir = Path(cfg["output"]["dir"]); out_dir.mkdir(parents=True, exist_ok=True)
    site = cfg["site"]

    result, raw = build(cfg, window_hours=args.next_hours, sat_filter=args.sat,
                        refresh_tle=args.refresh_tle)

    print("=" * 70)
    print("INTERFERENCE-OPPORTUNITY DIGITAL TWIN")
    print("=" * 70)
    print(f"Site:      {site['name']} ({site['lat_deg']:.4f}, {site['lon_deg']:.4f})")
    print(f"Window:    {result['run_utc'][:16].replace('T',' ')} UTC  +{result['window_hours']:.0f}h")
    print(f"Band:      {result['observed_band_mhz'][0]:.0f}-{result['observed_band_mhz'][1]:.0f} MHz monitored")
    print(f"Reference: PFD {result['severity_reference_dbw_m2']:.0f} dBW/m^2  "
          f"(severity = 0)   decision P >= {result['decision_threshold']:.2f}")
    print("=" * 70)
    for e in result["errors"]:
        print(f"  [ERROR] {e['satellite']}: {e['error']}")
    if not result["passes"]:
        print("  no passes in window")
    for s in result["passes"]:
        rc = COLORS.get(s["risk"], ""); rst = COLORS["RESET"]
        band_txt = "in-band" if s["in_band"] else "OUT-of-band"
        print(f"\n  {s['satellite']}  pass {s['pass_index']}: "
              f"rise {s['rise_utc'][11:19]}  max el {s['max_elevation_deg']:.1f}\u00b0  "
              f"min range {s['min_range_km']:.0f} km  [{band_txt}]")
        print(f"    {rc}[{s['risk']}]{rst}  peak severity {s['peak_severity_db']:+.1f} dB  |  "
              f"P(interference) peak {s['peak_prob']:.2f}  |  "
              f"{s['seconds_above_reference']}s above reference")

    if not args.no_plots and cfg["output"]["save_plots"] and result["passes"]:
        print("\n  plots...", end=" ", flush=True)
        dpi = cfg["output"]["plot_dpi"]
        for (nm, idx, pmap) in raw["maps"]:
            sat_dir = out_dir / nm.replace("/", "_").replace(" ", "_")
            sat_dir.mkdir(exist_ok=True)
            viz.plot_prediction_map(pmap, nm, idx, sat_dir/f"pass_{idx}_map.png", dpi)
        for rp in raw["raw_passes"]:
            sat_dir = out_dir / rp["sat"].replace("/", "_").replace(" ", "_")
            viz.plot_severity(rp["track"], rp["sev"], rp["prob"], rp["sat"], rp["idx"],
                              cfg["severity"], sat_dir/f"pass_{rp['idx']}_severity.png", dpi)
        viz.plot_probability_timeline(raw["raw_passes"], out_dir/"probability_timeline.png", dpi)
        if result["opportunity_windows"]:
            viz.plot_calendar(result["opportunity_windows"], result["run_utc"],
                              result["window_hours"], out_dir/"opportunity_calendar.png", dpi)
        if raw["roc"]:
            viz.plot_decision_roc(raw["roc"], cfg["decision"]["threshold"],
                                  out_dir/"decision_roc.png", dpi)
        print("done")

    print(f"\n{'='*70}\nOPPORTUNITY CALENDAR  [{site['name']}]\n{'='*70}")
    if not result["opportunity_windows"]:
        print("  no interference opportunities in this window")
    for w in result["opportunity_windows"]:
        rc = COLORS.get(w["risk"], ""); rst = COLORS["RESET"]
        warn = "WARN" if w["warn"] else "    "
        print(f"  {rc}[{w['risk']:6s}]{rst} {warn}  {w['satellite']:<14}  "
              f"{w['start_utc'][11:19]}-{w['end_utc'][11:19]} UTC  "
              f"peak sev {w['peak_severity_db']:+5.1f} dB  confidence {w['confidence']:.2f}")
    roc = result["decision_roc"]
    if roc and roc["n_interfering"] == 0:
        print(f"\nDECISION ROC:  no interference opportunities in this window "
              f"(nothing to detect at this reference)")
    elif roc:
        op = roc["operating"]
        print(f"\nDECISION ROC:  AUC={roc['auc']:.3f}  "
              f"(operating @ P>={op['threshold']:.2f}: Pd={op['pd']*100:.0f}%, PFA={op['pfa']*100:.0f}%)")
        print(f"  {roc['n_interfering']} interfering / {roc['n_clean']} clean samples")

    if cfg["output"]["save_json"]:
        (out_dir/"opportunities.json").write_text(json.dumps(result, indent=2, default=str))
        print(f"\n[saved] {out_dir/'opportunities.json'}")
    print(f"[done] {len(result['passes'])} pass(es), "
          f"{len(result['opportunity_windows'])} opportunity window(s) -> {out_dir.resolve()}")


if __name__ == "__main__":
    main()
