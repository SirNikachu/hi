"""output/severity.py — per-pass severity summary."""
from __future__ import annotations
import numpy as np
from common import severity_risk


def pass_summary(pass_obj, sat, severity_db, prob, overlap_fraction, cfg):
    info, track = pass_obj.info, pass_obj.track
    sev = np.asarray(severity_db, float)
    prob = np.asarray(prob, float)
    frac = np.asarray(overlap_fraction, float)
    dt = cfg["prediction"]["time_step_s"]
    pk = int(np.argmax(sev))

    return {
        "satellite": sat["name"],
        "norad_id": sat["norad_id"],
        "pass_index": info.pass_index,
        "rise_utc": info.rise_utc.isoformat(),
        "set_utc": info.set_utc.isoformat(),
        "culmination_utc": info.culmination_utc.isoformat(),
        "max_elevation_deg": round(info.max_elevation_deg, 1),
        "min_range_km": round(float(np.min(track["range_m"]) / 1000.0), 1),
        "duration_s": round(info.duration_s, 0),
        "in_band": bool(np.any(frac > 0)),
        "overlap_fraction": round(float(np.max(frac)), 3),
        "peak_severity_db": round(float(sev[pk]), 2),
        "mean_severity_db": round(float(sev.mean()), 2),
        "seconds_above_reference": int(np.sum(sev >= 0) * dt),
        "peak_prob": round(float(prob.max()), 3),
        "risk": severity_risk(float(sev[pk]), cfg["severity"]),
    }
