"""output/visualize.py — plots for the interference-opportunity twin."""
from __future__ import annotations
from datetime import datetime
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

_RISK_COLOR = {"NONE": "#22C55E", "LOW": "#84CC16",
               "MEDIUM": "#F59E0B", "HIGH": "#EF4444"}


def _save(fig, path, dpi):
    fig.savefig(path, dpi=dpi, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return str(path)


def plot_prediction_map(pmap, sat_name, idx, path, dpi=120):
    """Time-frequency prediction map: the Doppler track coloured by severity."""
    fig, ax = plt.subplots(figsize=(9, 4.5))
    t = pmap["t_s"]
    f_mhz = pmap["freqs_hz"] / 1e6
    Z = np.ma.masked_invalid(pmap["intensity_db"].T)   # (freq, time)
    pc = ax.pcolormesh(t, f_mhz, Z, shading="auto", cmap="inferno")
    cb = fig.colorbar(pc, ax=ax); cb.set_label("Severity (dB above reference)")
    ax.plot(t, pmap["center_hz"] / 1e6, color="#00C2D4", lw=1.5, ls="--",
            label="Predicted Doppler track")
    ax.set_xlabel("Time since AOS (s)")
    ax.set_ylabel("Frequency (MHz)")
    ax.set_title(f"{sat_name} — pass {idx}: time-frequency prediction map")
    ax.legend(loc="upper right", fontsize=8)
    return _save(fig, path, dpi)


def plot_severity(track, severity_db, prob, sat_name, idx, sev_cfg, path, dpi=120):
    """Severity and interference probability over the pass."""
    t = np.asarray(track["t_s"], float)
    sev = np.asarray(severity_db, float)
    fig, ax1 = plt.subplots(figsize=(9, 4.0))
    ax1.plot(t, sev, color="#EF4444", lw=2, label="Severity (dB above ref)")
    ax1.axhline(0, color="#64748B", ls=":", lw=1, label="Reference (severity = 0)")
    ax1.axhline(sev_cfg["low_db"], color="#84CC16", ls=":", lw=0.8)
    ax1.axhline(sev_cfg["medium_db"], color="#F59E0B", ls=":", lw=0.8)
    ax1.set_xlabel("Time since AOS (s)")
    ax1.set_ylabel("Severity (dB)", color="#EF4444")
    ax1.tick_params(axis="y", labelcolor="#EF4444")

    ax2 = ax1.twinx()
    ax2.plot(t, np.asarray(prob, float), color="#2563EB", lw=2, label="P(interference)")
    ax2.set_ylabel("P(interference)", color="#2563EB")
    ax2.set_ylim(0, 1.02)
    ax2.tick_params(axis="y", labelcolor="#2563EB")

    ax1.set_title(f"{sat_name} — pass {idx}: severity & interference probability")
    l1, b1 = ax1.get_legend_handles_labels()
    l2, b2 = ax2.get_legend_handles_labels()
    ax1.legend(l1 + l2, b1 + b2, loc="upper right", fontsize=8)
    return _save(fig, path, dpi)


def plot_probability_timeline(passes, path, dpi=120):
    """P(interference) vs absolute UTC for every pass in the window."""
    fig, ax = plt.subplots(figsize=(11, 3.6))
    for p in passes:
        times = [mdates.date2num(tt) for tt in p["time_utc"]]
        ax.plot(times, p["prob"], lw=1.6,
                color="#5AA9FF" if p["sat"] == "METOP-C" else "#C08BFF",
                label=p["sat"] if p["first"] else None)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    ax.set_ylim(0, 1.02)
    ax.set_xlabel("UTC")
    ax.set_ylabel("P(interference)")
    ax.set_title("Interference probability over the forecast window")
    ax.legend(loc="upper right", fontsize=8)
    ax.grid(alpha=0.3)
    return _save(fig, path, dpi)


def plot_decision_roc(roc, decision_threshold, path, dpi=120):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.8))
    pfa, pd, tau = roc["pfa"], roc["pd"], roc["thresholds"]
    op = roc["operating"]

    ax1.plot(pfa, pd, color="#2563EB", lw=2.4,
             label=f"decision ROC (AUC={roc['auc']:.3f})")
    ax1.plot([0, 1], [0, 1], ls=":", color="grey", lw=1, label="chance")
    ax1.scatter([op["pfa"]], [op["pd"]], s=90, color="#EF4444", zorder=5,
                label=f"operating @ P={op['threshold']:.2f}\n(Pd={op['pd']:.2f}, PFA={op['pfa']:.2f})")
    ax1.set(xlabel="P(false warning) = PFA", ylabel="P(detect interference) = Pd",
            xlim=(0, 1), ylim=(0, 1.02), title="Warning decision ROC")
    ax1.grid(alpha=0.3); ax1.legend(loc="lower right", fontsize=8)

    ax2.plot(tau, pd, color="#22C55E", lw=2, label="Pd (1 - missed)")
    ax2.plot(tau, pfa, color="#EF4444", lw=2, label="PFA (false warning)")
    ax2.axvline(decision_threshold, color="#EF4444", ls="--", lw=1.2,
                label=f"decision threshold = {decision_threshold:.2f}")
    ax2.set(xlabel="Decision threshold on P(interference)", ylabel="Probability",
            ylim=(0, 1.02),
            title=f"Trade vs threshold  ({roc['n_interfering']}+/{roc['n_clean']}- samples)")
    ax2.grid(alpha=0.3); ax2.legend(fontsize=8)
    return _save(fig, path, dpi)


def plot_calendar(windows, start, hours, path, dpi=120):
    """Gantt-style timeline of opportunity windows, coloured by risk."""
    fig, ax = plt.subplots(figsize=(11, 3.4))
    sats = sorted({w["satellite"] for w in windows})
    ypos = {s: i for i, s in enumerate(sats)}
    for w in windows:
        x0 = mdates.date2num(datetime.fromisoformat(w["start_utc"]))
        x1 = mdates.date2num(datetime.fromisoformat(w["end_utc"]))
        ax.barh(ypos[w["satellite"]], max(x1 - x0, 1e-4), left=x0, height=0.5,
                color=_RISK_COLOR.get(w["risk"], "#888"), edgecolor="black", lw=0.4)
    ax.set_yticks(range(len(sats)))
    ax.set_yticklabels(sats)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    ax.set_xlabel("UTC")
    ax.set_title(f"Interference-opportunity calendar — next {hours:.0f} h")
    handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in _RISK_COLOR.values()]
    ax.legend(handles, list(_RISK_COLOR), loc="upper right", fontsize=8, ncol=4)
    ax.grid(alpha=0.3, axis="x")
    return _save(fig, path, dpi)
