"""
output/calendar.py — the interference-opportunity calendar.

Collapses the per-second probability into discrete windows an operator can
act on: start, end, peak severity, peak probability, and a risk label.
"""
from __future__ import annotations
from datetime import timedelta
import numpy as np
from common import severity_risk


def opportunity_windows(pass_obj, sat, prob, severity_db, cfg):
    """Return interference-opportunity windows for one pass.

    An *opportunity* is when interference is geometrically possible: the
    arriving in-band flux exceeds the reference (severity >= 0) while the
    satellite is up. The duty-cycle-aware probability is reported as a
    confidence on each window, and `warn` marks windows whose confidence
    clears the decision threshold — but a strong-geometry pass is never
    hidden just because the emitter is duty-limited.
    """
    thr = cfg["decision"]["threshold"]
    sev_cfg = cfg["severity"]
    times = pass_obj.track["time_utc"]
    prob = np.asarray(prob, float)
    sev = np.asarray(severity_db, float)
    flag = sev >= 0.0                                # opportunity = flux beats reference

    windows, i, n = [], 0, len(flag)
    while i < n:
        if not flag[i]:
            i += 1
            continue
        j = i
        while j + 1 < n and flag[j + 1]:
            j += 1
        seg = slice(i, j + 1)
        pk = i + int(np.argmax(sev[seg]))
        peak_prob = float(prob[seg].max())
        windows.append({
            "satellite": sat["name"],
            "norad_id": sat["norad_id"],
            "start_utc": times[i].isoformat(),
            "end_utc": times[j].isoformat(),
            "duration_s": (times[j] - times[i]).total_seconds(),
            "peak_severity_db": round(float(sev[pk]), 2),
            "confidence": round(peak_prob, 3),
            "warn": bool(peak_prob >= thr),
            "peak_time_utc": times[pk].isoformat(),
            "risk": severity_risk(float(sev[pk]), sev_cfg),
        })
        i = j + 1
    return windows
