"""
core/geometry.py — relative, calibration-free interference severity.

The twin does NOT model the observatory receiver. It predicts how much
satellite power *arrives* at the site (power-flux-density, a satellite-side
quantity) and how much of that lands in the observed band. Severity is that
in-band PFD expressed relative to a single tunable reference that stands in
for the site's sensitivity. No absolute receiver calibration is required.
"""
from __future__ import annotations
import numpy as np

C_LIGHT = 299_792_458.0
_4PI_DB = 10.0 * np.log10(4.0 * np.pi)   # 10.99 dB


def pfd_dbw_m2(eirp_dbw: float, range_m: np.ndarray) -> np.ndarray:
    """Power-flux-density (dBW/m^2) arriving at the site from an isotropic-
    equivalent EIRP at the given slant range. Pure free-space spreading:
        PFD = EIRP - 10*log10(4*pi*R^2)
    Independent of the receiver — exactly what the twin should predict."""
    return eirp_dbw - (20.0 * np.log10(range_m) + _4PI_DB)


def spectral_overlap_fraction(f_center_hz, occ_bw_hz, band_lo_hz, band_hi_hz):
    """Fraction of the satellite's occupied bandwidth that falls inside the
    observed band (uniform-PSD approximation)."""
    lo = f_center_hz - occ_bw_hz / 2.0
    hi = f_center_hz + occ_bw_hz / 2.0
    ov = np.maximum(0.0, np.minimum(hi, band_hi_hz) - np.maximum(lo, band_lo_hz))
    return ov / occ_bw_hz


def _overlap_db(frac, oob_floor_db):
    frac = np.atleast_1d(np.asarray(frac, float))
    out = np.where(frac > 0, 10.0 * np.log10(np.clip(frac, 1e-6, 1.0)), oob_floor_db)
    return out if out.size > 1 else float(out[0])


def severity(track: dict, sat: dict, band: dict, sev_cfg: dict):
    """Per-time-step relative severity.

    Returns (severity_db, pfd_inband_db, overlap_fraction), each length-T.
      severity_db = in-band PFD (dBW/m^2) - pfd_reference_dbw_m2
    severity_db > 0  => arriving in-band flux exceeds the reference.
    """
    rng = np.asarray(track["range_m"], float)
    f_center = sat["downlink_hz"] + np.asarray(track["doppler_hz"], float)
    frac = spectral_overlap_fraction(f_center, sat["bandwidth_hz"],
                                     band["f_low_hz"], band["f_high_hz"])
    pfd = pfd_dbw_m2(sat["eirp_dbw"], rng)
    pfd_inband = pfd + _overlap_db(frac, sev_cfg["oob_floor_db"])
    sev = pfd_inband - sev_cfg["pfd_reference_dbw_m2"]
    return sev, pfd_inband, np.atleast_1d(frac)
