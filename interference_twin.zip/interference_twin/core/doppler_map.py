"""
core/doppler_map.py — the time-frequency prediction map.

For a pass, the satellite signal sits at  f_downlink + Doppler(t)  and is
occ_bw wide. This builds the 2-D (time x frequency) map of exactly which
bins are expected to contain satellite energy, coloured by severity. It is
the artifact you overlay on the real Air-T spectrogram once data arrives:
the Doppler track is a per-pass fingerprint no terrestrial source can fake.
"""
from __future__ import annotations
import numpy as np


def prediction_map(track: dict, sat: dict, severity_db: np.ndarray,
                   n_freq: int = 160, pad_factor: float = 1.6) -> dict:
    dopp = np.asarray(track["doppler_hz"], float)
    occ = sat["bandwidth_hz"]
    f0 = sat["downlink_hz"]
    f_center = f0 + dopp
    f_lo = f_center.min() - occ * pad_factor
    f_hi = f_center.max() + occ * pad_factor
    freqs = np.linspace(f_lo, f_hi, n_freq)

    T = len(track["t_s"])
    sev = np.asarray(severity_db, float)
    intensity = np.full((T, n_freq), np.nan)     # NaN where no signal expected
    for ti in range(T):
        lo, hi = f_center[ti] - occ / 2, f_center[ti] + occ / 2
        inb = (freqs >= lo) & (freqs <= hi)
        intensity[ti, inb] = sev[ti]

    return {
        "freqs_hz": freqs,
        "t_s": np.asarray(track["t_s"], float),
        "intensity_db": intensity,         # severity inside the signal footprint
        "center_hz": f_center,             # the Doppler track itself
        "downlink_hz": f0,
        "occ_bw_hz": occ,
    }
