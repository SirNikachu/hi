"""
inference/prior.py — geometry + satellite basics -> prior P(interference).

The TLE is a very strong prior: it tells you almost exactly where the
satellite is. We fold four independent factors into a per-second prior
probability that interference is occurring, WITHOUT any SDR data:

    P(interference) = P(above mask) x P(transmitting) x P(in band) x P(flux high)

  - P(above mask)   : softened horizon mask (sigmoid) to absorb TLE timing error
  - P(transmitting) : the satellite's duty cycle (a basic, known property)
  - P(in band)      : 1 if the emission overlaps the observed band, else residual
  - P(flux high)    : sigmoid of severity -> prob arriving flux beats the reference
"""
from __future__ import annotations
import numpy as np


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -50, 50)))


def visibility_factor(el_deg, mask_deg, sigma_el_deg):
    """Soft horizon gate. ~0 well below the mask, ~1 well above it; the
    transition width sigma_el represents along-track TLE timing uncertainty."""
    return sigmoid((np.asarray(el_deg, float) - mask_deg) / max(sigma_el_deg, 1e-6))


def prior_interference(track, severity_db, overlap_fraction, sat, cfg):
    """Per-second prior probability of interference for one pass."""
    sev_cfg, pr = cfg["severity"], cfg["prior"]
    el = np.asarray(track["el_deg"], float)

    p_visible = visibility_factor(el, cfg["prediction"]["elevation_mask_deg"],
                                  pr["sigma_elevation_deg"])
    p_tx = float(sat.get("transmit_duty", 1.0))
    frac = np.asarray(overlap_fraction, float)
    p_inband = np.where(frac > 0, 1.0, pr["oob_overlap_prob"])
    p_flux = sigmoid(np.asarray(severity_db, float) / sev_cfg["sigma_pfd_db"])

    return np.clip(p_visible * p_tx * p_inband * p_flux, 0.0, 1.0)
