"""
inference/bayesian.py — decision layer.

Right now there is no SDR data, so the posterior equals the prior. The
update function already accepts a likelihood ratio so that, when Air-T data
arrives, the spectrogram evidence drops straight in with no other changes:

    posterior = prior * LR / (prior * LR + (1 - prior))

where LR = P(observation | interference) / P(observation | no interference)
comes from comparing the measured in-band power to its quiet-sky baseline.

`decision_roc` characterises the warning policy: sweeping the decision
threshold traces probability-of-detection against probability-of-false-
warning, against a geometry-defined ground truth. The duty cycle of a
scheduled emitter is what makes this trade non-trivial — you must decide to
warn *before* knowing whether the satellite will actually key its downlink.
"""
from __future__ import annotations
import numpy as np


def posterior(prior, likelihood_ratio=None):
    """Bayesian update. With no observation (likelihood_ratio=None) the
    posterior is just the prior — the current, data-free regime."""
    prior = np.asarray(prior, float)
    if likelihood_ratio is None:
        return prior
    lr = np.asarray(likelihood_ratio, float)
    return (prior * lr) / (prior * lr + (1.0 - prior))


def decide(post, threshold):
    return np.asarray(post, float) >= threshold


def decision_roc(scores, truth, operating_threshold=0.5, n_points=80):
    """ROC for the warn/no-warn decision. scores = predicted P(interference);
    truth = boolean ground-truth interference per sample."""
    scores = np.asarray(scores, float)
    truth = np.asarray(truth, bool)
    P, N = int(truth.sum()), int((~truth).sum())
    taus = np.linspace(0.0, 1.0, n_points)
    pd = np.array([(scores[truth] >= t).mean() if P else np.nan for t in taus])
    pfa = np.array([(scores[~truth] >= t).mean() if N else np.nan for t in taus])

    flag = scores >= operating_threshold
    op_pd = float(flag[truth].mean()) if P else float("nan")
    op_pfa = float(flag[~truth].mean()) if N else float("nan")

    if P and N:
        order = np.argsort(pfa)
        _trap = getattr(np, "trapezoid", None) or np.trapz
        auc = float(_trap(pd[order], pfa[order]))
    elif P and not N:
        auc = 1.0          # every sample truly interferes -> perfect discrimination
    else:
        auc = float("nan")

    return {
        "pfa": pfa, "pd": pd, "thresholds": taus, "auc": auc,
        "operating": {"threshold": float(operating_threshold),
                      "pd": op_pd, "pfa": op_pfa},
        "n_interfering": P, "n_clean": N,
    }
